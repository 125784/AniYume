const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require('express-session');
const app = express();
const PORT = 8081;
const bcrypt = require('bcrypt');
const nodemailer = require('nodemailer');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const { Parser } = require('json2csv');
const crypto = require('crypto');
const path = require('path');
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const router = express.Router();
const { google } = require('googleapis');
const { PDFDocument, rgb, StandardFonts } = require('pdf-lib');
const XLSX = require('xlsx');

const CartItem = require('./public/models/CartItem');
const { syncCartWithDatabase, loadCartFromDatabase } = require('./public/middleware/cartSync');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'some-secret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

mongoose.connect('mongodb://localhost:27017/AniYume');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

const ProductSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    description: { type: String, required: true },
    price: { type: Number, required: true },
    discount_price: { type: Number, default: null },
    category: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        required: true
    },
    images: [{
        type: String,
        required: true,
        validate: {
            validator: (value) => /\.(jpg|jpeg|png|webp)$/i.test(value),
            message: 'Недопустимый формат изображения'
        }
    }],
    sku: { type: String, required: true, unique: true },
    stock_quantity: { type: Number, required: true },
    status: { type: String, enum: ['Активен', 'Неактивен'], default: 'Активен' },
    age_restriction: { type: Number, default: null },
    attributes: [{
        name: String,
        value: String,
        affectsPrice: Boolean
    }],
    rating: { type: Number, default: 0 },
    seller_name: { type: String, required: true },
    category_name: { type: String, required: true },
    isSale: { type: Boolean, default: false },
    saleEndTime: { type: Date, default: null }
});

const Product = mongoose.model('Product', ProductSchema);

app.get('/api/promotional-products', async (req, res) => {
    try {
        const promotionalProducts = await Product.find({
            status: 'Активен',
            isSale: true,
            saleEndTime: { $gt: new Date() }
        });
        res.json(promotionalProducts);
    } catch (err) {
        console.error('Ошибка при получении акционных товаров:', err);
        res.status(500).json({ message: 'Не удалось получить список акционных товаров.' });
    }
});

app.get('/api/random-products', async (req, res) => {
    try {
        const allActiveProducts = await Product.find({ status: 'Активен' });
        const shuffledProducts = allActiveProducts.sort(() => 0.5 - Math.random());
        const randomProducts = shuffledProducts.slice(0, 20);
        res.json(randomProducts);
    } catch (err) {
        console.error('Ошибка при получении случайных товаров:', err);
        res.status(500).json({ message: 'Не удалось получить список товаров.' });
    }
});

app.get('/product/:id', async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).send('Invalid product ID');
        }

        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).send('Product not found');
        }

        const reviews = await Review.find({ product_id: req.params.id }).populate('user_id');

        res.render('product', { product, reviews });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/api/popular-products', async (req, res) => {
    try {
        const popularProducts = await Product.find({ status: 'Активен' })
                                            .sort({ rating: -1 });
        const topProducts = popularProducts.slice(0, 8);
        res.json(topProducts);
    } catch (err) {
        console.error('Ошибка при получении популярных товаров:', err);
        res.status(500).json({ message: 'Не удалось получить список популярных товаров.' });
    }
});

const CategorySchema = new mongoose.Schema({
    name: { type: String, required: true },
    parent: { type: mongoose.Schema.Types.ObjectId, ref: 'Category', default: null },
    description: { type: String, required: true },
    keywords: [{ type: String }],
    products: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }]
});

const Category = mongoose.model('Category', CategorySchema);

app.get('/admin/categories/create', isAdmin, (req, res) => {
    res.render('createCategory');
});

app.post('/admin/categories', isAdmin, async (req, res) => {
    try {
        const { name, description, keywords } = req.body;
        const category = new Category({ category_name, description, keywords });
        await category.save();
        res.redirect('/admin/profile');
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка при создании категории');
    }
});

app.post('/admin/products/bulk-update', isAdmin, async (req, res) => {
    const { productIds, updates } = req.body;

    try {
        await Product.updateMany(
            { _id: { $in: productIds } },
            { $set: updates }
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

let upload = multer({ storage });

app.post('/upload', upload.array('images'), async (req, res) => {
    try {
        const imagePaths = req.files.map(file => `/uploads/${file.filename}`);
        res.json({ success: true, images: imagePaths });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

upload = multer({ dest: 'uploads/' });

app.post('/admin/products/import', isAdmin, upload.single('file'), async (req, res) => {
    const results = [];
    fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', async () => {
            try {
                await Product.insertMany(results.map(row => ({
                    ...row,
                    price: parseFloat(row.price),
                    discount_price: row.discount_price ? parseFloat(row.discount_price) : null,
                    stock_quantity: parseInt(row.stock_quantity),
                    images: row.images.split(',').map(img => img.trim()),
                    attributes: JSON.parse(row.attributes || '[]')
                })));
                res.json({ success: true });
            } catch (err) {
                res.status(500).json({ message: err.message });
            } finally {
                fs.unlinkSync(req.file.path);
            }
        });
});

app.post('/admin/products/export', isAdmin, async (req, res) => {
    try {
        const { reason, exclude_categories, format } = req.body;

        console.log(`--- ОТЧЕТ О ВЫГРУЗКЕ БАЗЫ ---`);
        console.log(`Дата: ${new Date().toLocaleString()}`);
        console.log(`Причина: ${reason || 'Не указана'}`);
        console.log(`Исключенные категории: ${exclude_categories || 'Нет'}`);
        console.log(`----------------------------`);

        let query = {};
        if (exclude_categories) {
            const excludeIds = Array.isArray(exclude_categories) ? exclude_categories : [exclude_categories];
            query.category = { $nin: excludeIds };
        }

        const products = await Product.find(query).lean();

        if (format === 'json') {
            res.setHeader('Content-disposition', 'attachment; filename=products_export.json');
            res.set('Content-Type', 'application/json');
            return res.status(200).send(JSON.stringify(products, null, 2));
        }

        const json2csvParser = new Parser();
        const csvData = json2csvParser.parse(products.map(product => ({
            ...product,
            images: Array.isArray(product.images) ? product.images.join(', ') : '',
            attributes: JSON.stringify(product.attributes || [])
        })));

        res.attachment('products_export.csv').send(csvData);
    } catch (err) {
        console.error("Ошибка при экспорте:", err);
        res.status(500).json({ message: "Ошибка при формировании файла: " + err.message });
    }
});

const SaleProductSchema = new mongoose.Schema({
    name: String,
    category_name: String,
    description: String,
    price: Number,
    discount_price: Number,
    seller_name: String,
    rating: {
        type: Number,
        min: 0,
        max: 5,
        required: true
    },
    stock_quantity: Number,
    images: [String],
    timer_seconds: Number,
    attributes: [{
        name: String,
        value: String,
        affectsPrice: Boolean
    }]
});

const SaleProducts = mongoose.model('SaleProducts', SaleProductSchema);

app.get('/products/:id', async (req, res) => {
    try {
        const product = await SaleProducts.findById(req.params.id);
        console.log(product);
        if (product) {
            res.render('product_sale', { product });
        } else {
            res.status(404).send('Product not found');
        }
    } catch (err) {
        console.error(err);
        res.status(500).send('Server error');
    }
});

const CartSchema = new mongoose.Schema({
    product_id: mongoose.Schema.Types.ObjectId,
    quantity: Number
});

const Cart = mongoose.model('Cart', CartSchema);

const adminSchema = new mongoose.Schema({
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { type: String, default: ['Администратор', 'Главный администратор'] },
    first_name: { type: String },
    last_name: { type: String },
    middle_name: { type: String },
    phone_number: { type: String },
    address: { type: String },
    hire_date: { type: Date },
    marital_status: { type: String },
    responsibilities: { type: String },
    salary: { type: Number }
});

const Admin = mongoose.model('Admin', adminSchema);

function renderAdminProfile(res, additionalData = {}) {
    Promise.all([
        Order.find().lean(),
        Product.find().lean(),
        Category.find().lean(),
        User.find().lean()
    ]).then(([orders, products, categories, users]) => {
        res.render('adminProfile', {
            orders: orders || [],
            products: products || [],
            categories: categories || [],
            users: users || [],
            ...additionalData
        });
    }).catch(error => {
        console.error('Ошибка при загрузке данных:', error);
        res.status(500).send('Ошибка сервера');
    });
}

app.get('/admin/profile', async (req, res) => {
    try {
        const [orders, products, categories, users] = await Promise.all([
            Order.find().lean(),
            Product.find().lean(),
            Category.find().lean(),
            User.find().lean()
        ]);

        res.render('adminProfile', {
            orders: orders || [],
            products: products || [],
            categories: categories || [],
            users: users || []
        });
    } catch (error) {
        console.error('Ошибка при загрузке данных профиля администратора:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/admin/profile/edit', isAdmin, async (req, res) => {
    const { first_name, last_name, middle_name, phone_number, address, marital_status, responsibilities, salary } = req.body;
    try {
        await Admin.findByIdAndUpdate(req.session.userId, {
            first_name,
            last_name,
            middle_name,
            phone_number,
            address,
            marital_status,
            responsibilities,
            salary
        });
        res.redirect('/adminProfile/profile');
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/cart', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.redirect('/login.html');
        }

        const cartItems = await CartItem.find({ user: req.session.userId })
                                        .populate('product_id');

        let total = 0;
        cartItems.forEach(item => {
            if (item.product_id) {
                total += item.product_id.price * item.quantity;
            }
        });

        res.render('cart', {
            cartItems: cartItems,
            total: total
        });
    } catch (err) {
        console.error("Ошибка при загрузке корзины:", err);
        res.status(500).send("Произошла ошибка при загрузке корзины");
    }
});

app.post('/cart/add', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ success: false, message: 'Не авторизован' });
        }

        const { productId, quantity } = req.body;
        const userId = req.session.userId;

        let item = await CartItem.findOne({ user: userId, product_id: productId });

        if (item) {
            item.quantity += parseInt(quantity);
            await item.save();
        } else {
            item = new CartItem({
                user: userId,
                product_id: productId,
                quantity: parseInt(quantity)
            });
            await item.save();
        }

        const totalCount = await CartItem.getCartCount(userId);

        res.json({
            success: true,
            message: 'Добавлено в базу',
            cartCount: totalCount
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/cart/update/:productId', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).send("Авторизуйтесь");
        }

        const productId = req.params.productId;
        const newQuantity = parseInt(req.body.quantity);

        if (newQuantity > 0) {
            await CartItem.findOneAndUpdate(
                { user: req.session.userId, product_id: productId },
                { quantity: newQuantity }
            );
        } else {
            await CartItem.findOneAndDelete({
                user: req.session.userId,
                product_id: productId
            });
        }

        res.redirect('/cart');
    } catch (err) {
        console.error("Ошибка при обновлении корзины:", err);
        res.status(500).send("Ошибка сервера");
    }
});

const UserSchema = new mongoose.Schema({
    first_name: { type: String, required: true },
    last_name: { type: String, required: true },
    middle_name: String,
    email: { type: String, unique: true, required: true },
    phone_number: String,
    address: [{ type: String, default: [] }],
    date_of_birth: Date,
    password: { type: String, required: true },
    orders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }],
    registration_date: { type: Date, default: Date.now },
    bout: { type: String, default: '' },
    last_ip: String,
    bonus_points: { type: Number, default: 0 },
    role: {
        type: String,
        enum: ['Пользователь', 'Главный администратор', 'Модератор', 'Контент-менеджер'],
        default: 'Пользователь'
    },
    blocked_ips: [{ type: String }]
});

const User = mongoose.model('User', UserSchema);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

function checkRole(role) {
    return (req, res, next) => {
        console.log('Session user:', req.session.user);
        console.log('Required role:', role);

        if (!req.session.user) {
            console.error('User not authenticated');
            return res.status(403).send('Доступ запрещен');
        }

        if (req.session.user.role !== role) {
            console.error(`User role (${req.session.user.role}) does not match required role (${role})`);
            return res.status(403).send('Доступ запрещен');
        }
        next();
    };
}

app.get('/admin/users', checkRole('Главный администратор'), async (req, res) => {
    try {
        const users = await User.find();
        res.render('adminUserList', { users: users });
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка сервера при получении списка пользователей');
    }
});

app.get('/admin/users/select', checkRole('Главный администратор'), (req, res) => {
    const userId = req.query.userId;
    if (userId) {
        res.redirect(`/admin/users/${userId}`);
    } else {
        res.redirect('/admin/users');
    }
});

app.get('/admin/users/:userId', checkRole('Главный администратор'), async (req, res) => {
    try {
        const user = await User.findById(req.params.userId).populate('orders');
        if (!user) return res.status(404).send('Пользователь не найден');

        if (!user.address) {
            user.address = [];
        }

        res.render('adminProfile', { user: user });
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка сервера при получении профиля пользователя');
    }
});

app.post('/admin/users/:userId/role', checkRole('Главный администратор'), async (req, res) => {
    try {
        const { role } = req.body;
        const user = await User.findById(req.params.userId);
        if (!user) return res.status(404).send('Пользователь не найден');
        user.role = role;
        await user.save();
        res.send('Роль обновлена');
    } catch (error) {
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/forgot-password', async (req, res) => {
    const { userId } = req.body;

    try {
        const user = await User.findById(userId);
        if (!user) return res.status(404).send('Пользователь не найден');

        const token = crypto.randomBytes(20).toString('hex');
        user.resetPasswordToken = token;
        user.resetPasswordExpires = Date.now() + 3600000;
        await user.save();

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'your-email@gmail.com',
                pass: 'your-password'
            }
        });

        const mailOptions = {
            from: 'your-email@gmail.com',
            to: user.email,
            subject: 'Восстановление пароля',
            text: `Перейдите по ссылке для сброса пароля: http://localhost:3000/reset-password?token=${token}`
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Ошибка отправки email:', error);
                return res.status(500).send('Ошибка отправки email');
            }
            res.send('Инструкции по восстановлению пароля отправлены на ваш email');
        });
    } catch (error) {
        console.error('Ошибка при обработке запроса:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/admin/block-ip', checkRole('Главный администратор'), async (req, res) => {
    const { userId, ip } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).send('Пользователь не найден');

    user.blocked_ips.push(ip);
    await user.save();
    res.send('IP заблокирован');
});

function checkRole(role) {
    return (req, res, next) => {
        console.log('Session user:', req.session.user);
        console.log('Required role:', role);

        if (!req.session.user) {
            console.error('User not authenticated');
            return res.status(403).send('Доступ запрещен');
        }

        if (req.session.user.role !== role) {
            console.error(`User role (${req.session.user.role}) does not match required role (${role})`);
            return res.status(403).send('Доступ запрещен');
        }
        next();
    };
}

app.post('/admin/users/:userId/update', checkRole('Главный администратор'), async (req, res) => {
    try {
        const userId = req.params.userId;
        const updates = req.body;

        console.log('Updating user with ID:', userId);
        console.log('Updates:', updates);

        if (updates.address) {
            updates.address = updates.address.split('\n').filter(addr => addr.trim() !== '');
        }

        if (updates.date_of_birth) {
            updates.date_of_birth = new Date(updates.date_of_birth);
        }

        const updatedUser = await User.findByIdAndUpdate(
            userId,
            { $set: updates },
            { new: true }
        );

        if (!updatedUser) {
            console.error('User not found for ID:', userId);
            return res.status(404).send('Пользователь не найден');
        }

        console.log('User updated successfully:', updatedUser);

        res.redirect(`/admin/users/${userId}`);
    } catch (error) {
        console.error('Error updating user:', error);
        res.status(500).send('Ошибка сервера при обновлении данных пользователя');
    }
});

const SalesStatisticsSchema = new mongoose.Schema({
    date_range: String,
    metrics: {
        sales_count: { daily: [{}], weekly: [{}], monthly: [{}] },
        total_revenue: { daily: [{}], weekly: [{}], monthly: [{}] },
        average_check: { daily: [{}], weekly: [{}], monthly: [{}] },
        popular_products: { by_sales_count: [{}], by_revenue: [{}] },
        traffic_sources: { google_analytics: [{}] },
        conversion_rate: { overall: Number, by_source: [{}] },
        cancelled_orders: { count: Number, total_amount: Number },
        returns: { count: Number, total_amount: Number },
        profit: { monthly: [{}] }
    },
    period_comparison: {
        sales_count: { october: Number, november: Number, percentage_change: Number },
        total_revenue: { october: Number, november: Number, percentage_change: Number }
    }
});

const SalesStatistics = mongoose.model('SalesStatistics', SalesStatisticsSchema);

async function getSalesStatistics(period, productFilter, startDate, endDate) {
    try {
        const start = startDate ? new Date(startDate) : null;
        const end = endDate ? new Date(endDate) : null;

        const metricsToFetch = {
            sales_count: { [period]: 1 },
            total_revenue: { [period]: 1 },
            average_check: { [period]: 1 },
            popular_products: 1,
            cancelled_orders: 1,
            returns: 1,
            profit: { monthly: 1 }
        };

        const query = {};
        if (start && end) {
            query['metrics.sales_count.daily.date'] = { $gte: start.toISOString().split('T')[0], $lte: end.toISOString().split('T')[0] };
        }

        const statistics = await SalesStatistics.find(query, metricsToFetch);

        const filteredData = statistics.map(stat => {
            const result = {
                date_range: stat.date_range,
                metrics: {}
            };

            if (productFilter) {
                result.metrics.popular_products = {
                    by_sales_count: stat.metrics.popular_products.by_sales_count.filter(item =>
                        item.product_id === productFilter || item.product_name === productFilter
                    ),
                    by_revenue: stat.metrics.popular_products.by_revenue.filter(item =>
                        item.product_id === productFilter || item.product_name === productFilter
                    )
                };
            } else {
                result.metrics.popular_products = stat.metrics.popular_products;
            }

            result.metrics.sales_count = stat.metrics.sales_count[period];
            result.metrics.total_revenue = stat.metrics.total_revenue[period];
            result.metrics.average_check = stat.metrics.average_check[period];
            result.metrics.cancelled_orders = stat.metrics.cancelled_orders;
            result.metrics.returns = stat.metrics.returns;
            result.metrics.profit = stat.metrics.profit.monthly;

            return result;
        });

        return filteredData;
    } catch (error) {
        console.error("Ошибка при получении статистики:", error);
        throw error;
    }
}

router.get('/statistics', async (req, res) => {
    const { period, productFilter, startDate, endDate } = req.query;

    try {
        const statistics = await getSalesStatistics(period, productFilter, startDate, endDate);
        res.json(statistics);
    } catch (error) {
        console.error("Ошибка при получении статистики:", error);
        res.status(500).send("Ошибка при получении статистики");
    }
});

router.get('/api/sales-statistics', async (req, res) => {
    try {
        const statistics = await SalesStatistics.find({});
        res.json(statistics);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка при получении статистики' });
    }
});

router.get('/api/sales-statistics/:period', async (req, res) => {
    const { period } = req.params;

    try {
        const statistics = await SalesStatistics.find({}, { [`metrics.${period}`]: 1 });
        res.json(statistics);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка при получении статистики' });
    }
});

router.get('/export/excel', async (req, res) => {
    try {
        const data = await SalesStatistics.find({});
        const flattenedData = data.map(stat => ({
            date_range: stat.date_range,
            sales_count_daily: JSON.stringify(stat.metrics.sales_count.daily),
            total_revenue_daily: JSON.stringify(stat.metrics.total_revenue.daily),
        }));

        const csvData = new json2csv().parse(flattenedData);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=sales-statistics.csv');
        res.send(csvData);
    } catch (error) {
        res.status(500).json({ error: 'Ошибка при экспорте данных' });
    }
});

module.exports = router;

const ReviewSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    product_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    review_date: { type: Date, default: Date.now },
    review_text: String,
    rating: Number
});

const Review = mongoose.model('Review', ReviewSchema);

const OrderSchema = new mongoose.Schema({
    order_number: { type: String, required: true, unique: true },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: false
    },
    first_name: {
        type: String,
        required: true
    },
    last_name: {
        type: String,
        required: true
    },
    items: [{
        product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
        name: { type: String, required: true },
        quantity: { type: Number, required: true },
        price: { type: Number, required: true }
    }],
    total_amount: { type: Number, required: true },
    payment_method: String,
    delivery_method: { type: String, default: '' },
    delivery_address: { type: String, default: '' },
    status: {
        type: String,
        enum: [
            'Новый', 'В обработке', 'Подтвержден', 'В сборке',
            'Отправлен', 'Доставлен', 'Отменен', 'Возврат (запрошен)',
            'Возврат (одобрен)', 'Возврат (получен)', 'Возврат (завершен)'
        ],
        default: 'Новый'
    },
    comments: [{
        text: String,
        isPublic: Boolean,
        createdAt: { type: Date, default: Date.now }
    }],
    history: [{
        status: String,
        updatedAt: { type: Date, default: Date.now }
    }],
    ip_address: String
});

const Order = mongoose.model('Order', OrderSchema);

app.get('/cart/count', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.json({ count: 0 });
        }

        const items = await CartItem.find({ user: req.session.userId });
        const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);

        res.json({ count: totalItems });
    } catch (err) {
        res.status(500).json({ count: 0 });
    }
});

app.delete('/cart/remove/:itemId', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ success: false, message: 'Не авторизован' });
        }

        const itemId = req.params.itemId;

        const item = await CartItem.findOne({ _id: itemId, user: req.session.userId });

        if (!item) {
            return res.status(404).json({ success: false, message: 'Товар не найден' });
        }

        await CartItem.deleteOne({ _id: itemId });

        const cartCount = await CartItem.countDocuments({ user: req.session.userId });
        res.json({ success: true, cartCount: cartCount });
    } catch (err) {
        console.error('Ошибка удаления:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

app.get('/admin/orders', isAdmin, async (req, res) => {
    try {
        const [orders, products, categories, users] = await Promise.all([
            Order.find().populate('user', 'first_name last_name email phone_number').lean() || [],
            Product.find().lean() || [],
            Category.find().lean() || [],
            User.find().lean() || []
        ]);

        res.render('adminProfile', {
            orders: orders || [],
            products: products || [],
            categories: categories || [],
            users: users || []
        });
    } catch (error) {
        console.error('Ошибка при загрузке заказов:', error);
        res.render('adminProfile', {
            orders: [],
            products: [],
            categories: [],
            users: [],
            error: 'Ошибка при загрузке данных'
        });
    }
});

app.post('/admin/orders/:id/status', isAdmin, async (req, res) => {
    const { status, comment, isPublic } = req.body;

    try {
        const order = await Order.findById(req.params.id);

        if (!order) {
            return res.status(404).json({ message: 'Заказ не найден' });
        }

        order.status = status;
        order.history.push({ status });

        if (comment) {
            order.comments.push({ text: comment, isPublic: isPublic === 'true' });
        }

        await order.save();

        const user = await User.findById(order.user);
        if (user) {
            sendOrderStatusNotification(user.email, status, comment);
        }

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

async function sendOrderStatusNotification(email, status, comment) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'your-email@gmail.com',
            pass: 'your-password'
        }
    });

    const mailOptions = {
        from: 'your-email@gmail.com',
        to: email,
        subject: `Статус вашего заказа изменен на "${status}"`,
        text: `Ваш заказ теперь имеет статус "${status}". ${comment ? `\nКомментарий: ${comment}` : ''}`
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log(`Уведомление отправлено на ${email}`);
    } catch (error) {
        console.error('Ошибка при отправке уведомления:', error);
    }
}

app.post('/admin/orders/:id/cancel-items', isAdmin, async (req, res) => {
    const { itemIds } = req.body;

    try {
        const order = await Order.findById(req.params.id);

        if (!order) {
            return res.status(404).json({ message: 'Заказ не найден' });
        }

        order.items = order.items.filter(item => !itemIds.includes(item._id.toString()));

        order.total_amount = order.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

        await order.save();

        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

app.get('/admin/orders/:id/print', isAdmin, async (req, res) => {
    try {
        const order = await Order.findById(req.params.id)
            .populate('items.product', 'name price');

        if (!order) {
            return res.status(404).send('Заказ не найден');
        }

        const htmlContent = `
            <h1>Товарная накладная</h1>
            <p><strong>Номер заказа:</strong> ${order.order_number}</p>
            <p><strong>Дата оформления:</strong> ${new Date(order.createdAt).toLocaleString()}</p>
            <h2>Список товаров:</h2>
            <ul>
                ${order.items.map(item => `
                    <li>${item.product.name} - ${item.quantity} шт. x ${item.price} руб. = ${item.quantity * item.price} руб.</li>
                `).join('')}
            </ul>
            <p><strong>Итого:</strong> ${order.total_amount} руб.</p>
        `;

        res.setHeader('Content-Type', 'text/html');
        res.send(htmlContent);
    } catch (error) {
        console.error('Ошибка при генерации документа:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/adminProfile', isAdmin, async (req, res) => {
    try {
        const orders = await Order.find()
            .populate('user', 'first_name last_name email phone_number')
            .populate('items.product', 'name price')
            .lean();

        res.render('adminProfile', {
            orders: orders || [],
            error: null
        });
    } catch (error) {
        console.error('Ошибка при загрузке данных профиля:', error);
        res.render('adminProfile', {
            orders: [],
            error: 'Ошибка при загрузке данных'
        });
    }
});

app.get('/admin/orders/select', isAdmin, async (req, res) => {
    try {
        const orders = await Order.find()
            .populate('user', 'first_name last_name email phone_number')
            .lean();

        res.render('selectOrder', {
            orders: orders || []
        });
    } catch (error) {
        console.error('Ошибка при загрузке заказов:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/admin/orders/edit', isAdmin, async (req, res) => {
    const { orderId } = req.query;

    if (!orderId || !mongoose.Types.ObjectId.isValid(orderId)) {
        return res.status(400).send('Некорректный ID заказа');
    }

    try {
        const order = await Order.findById(orderId)
            .populate('user', 'first_name last_name email phone_number')
            .populate('items.product', 'name price')
            .lean();

        if (!order) {
            return res.status(404).send('Заказ не найден');
        }

        res.render('editOrder', { order });
    } catch (error) {
        console.error('Ошибка при загрузке заказа:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/admin/orders/:id/update', isAdmin, async (req, res) => {
    const {
        first_name,
        last_name,
        email,
        phone_number,
        status,
        items,
        comment,
        isPublic,
        delivery_method,
        delivery_address
    } = req.body;

    try {
        const order = await Order.findById(req.params.id);

        if (!order) {
            return res.status(404).json({ message: 'Заказ не найден' });
        }

        order.first_name = first_name;
        order.last_name = last_name;
        order.email = email;
        order.phone_number = phone_number;
        order.status = status;

        order.delivery_method = delivery_method;
        order.delivery_address = delivery_address;

        if (Array.isArray(items)) {
            order.items = items.map(item => ({
                name: item.name,
                quantity: parseInt(item.quantity),
                price: parseFloat(item.price)
            }));
        }

        order.total_amount = order.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

        if (comment) {
            order.comments.push({ text: comment, isPublic: isPublic === 'on' });
        }

        order.history.push({ status });

        await order.save();

        const user = await User.findById(order.user);
        if (user) {
            sendOrderStatusNotification(user.email, status, comment);
        }

        res.redirect('/admin/orders/select');
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

app.post('/admin/users/create', isAdmin, async (req, res) => {
    const { email, password, role } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = new User({ email, password: hashedPassword, role });
        await user.save();
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/admin/statistics', isAdmin, async (req, res) => {
    try {
        const { period = 'month', productFilter = 'quantity', startDate, endDate } = req.query;

        let dateFilter = {};
        const now = new Date();
        let start = new Date();

        switch (period) {
            case 'day':
                start.setHours(0, 0, 0, 0);
                break;
            case 'week':
                start.setDate(now.getDate() - 7);
                break;
            case 'month':
                start.setMonth(now.getMonth() - 1);
                break;
            case 'year':
                start.setFullYear(now.getFullYear() - 1);
                break;
            case 'custom':
                if (startDate && endDate) {
                    start = new Date(startDate);
                    const end = new Date(endDate);
                    dateFilter = { order_date: { $gte: start, $lte: end } };
                }
                break;
            default:
                start.setMonth(now.getMonth() - 1);
        }

        if (period !== 'custom') {
            dateFilter = { order_date: { $gte: start, $lte: now } };
        }

        const orders = await Order.find(dateFilter).lean();

        const totalOrders = orders.length;
        const totalRevenue = orders.reduce((sum, order) => sum + (order.total_amount || 0), 0);
        const averageCheck = totalOrders > 0 ? totalRevenue / totalOrders : 0;

        const cancelledOrders = orders.filter(order => order.status === 'Отменен');
        const cancelledCount = cancelledOrders.length;
        const cancelledSum = cancelledOrders.reduce((sum, order) => sum + (order.total_amount || 0), 0);

        const returns = orders.filter(order => order.status && order.status.includes('Возврат'));
        const returnsCount = returns.length;
        const returnsSum = returns.reduce((sum, order) => sum + (order.total_amount || 0), 0);

        const profit = totalRevenue - cancelledSum;

        const salesByDate = [];
        const revenueByDate = [];
        const averageCheckByDate = [];

        const ordersByDate = {};
        orders.forEach(order => {
            const date = order.order_date ? new Date(order.order_date).toISOString().split('T')[0] :
                (order._id ? order._id.getTimestamp().toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);

            if (!ordersByDate[date]) {
                ordersByDate[date] = { count: 0, revenue: 0, orders: [] };
            }
            ordersByDate[date].count++;
            ordersByDate[date].revenue += order.total_amount || 0;
            ordersByDate[date].orders.push(order);
        });

        const sortedDates = Object.keys(ordersByDate).sort();
        for (const date of sortedDates) {
            salesByDate.push({ date, count: ordersByDate[date].count });
            revenueByDate.push({ date, revenue: ordersByDate[date].revenue });
            averageCheckByDate.push({
                date,
                averageCheck: ordersByDate[date].revenue / ordersByDate[date].count
            });
        }

        const productSales = {};
        orders.forEach(order => {
            if (order.items && order.items.length) {
                order.items.forEach(item => {
                    const productName = item.name;
                    if (!productSales[productName]) {
                        productSales[productName] = { quantity: 0, revenue: 0 };
                    }
                    productSales[productName].quantity += item.quantity;
                    productSales[productName].revenue += (item.price * item.quantity);
                });
            }
        });

        let popularProducts = Object.entries(productSales).map(([name, data]) => ({
            name,
            quantity: data.quantity,
            revenue: data.revenue
        }));

        if (productFilter === 'quantity') {
            popularProducts.sort((a, b) => b.quantity - a.quantity);
        } else {
            popularProducts.sort((a, b) => b.revenue - a.revenue);
        }
        popularProducts = popularProducts.slice(0, 10);

        const totalUsers = await User.countDocuments();
        const newUsersThisMonth = await User.countDocuments({
            registration_date: { $gte: start, $lte: now }
        });

        const totalProducts = await Product.countDocuments();
        const lowStockProducts = await Product.countDocuments({ stock_quantity: { $lt: 10 } });
        const outOfStockProducts = await Product.countDocuments({ stock_quantity: 0 });

        const statistics = {
            sales: {
                salesCount: totalOrders,
                totalRevenue: totalRevenue,
                averageCheck: averageCheck,
                cancelledOrdersCount: cancelledCount,
                cancelledOrdersSum: cancelledSum,
                returnsCount: returnsCount,
                returnsSum: returnsSum,
                profit: profit,
                salesByDate: salesByDate,
                revenueByDate: revenueByDate,
                averageCheckByDate: averageCheckByDate
            },
            popularProducts: popularProducts,
            users: {
                total: totalUsers,
                newThisMonth: newUsersThisMonth
            },
            products: {
                total: totalProducts,
                lowStock: lowStockProducts,
                outOfStock: outOfStockProducts
            },
            conversionRate: totalOrders > 0 ? ((totalOrders / totalUsers) * 100).toFixed(2) : 0
        };

        res.json(statistics);
    } catch (error) {
        console.error('Ошибка при получении статистики:', error);
        res.status(500).json({ error: error.message });
    }
});

app.get('/admin/stats/summary', isAdmin, async (req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const [totalUsers, totalProducts, totalOrders, todayOrders, lowStock] = await Promise.all([
            User.countDocuments(),
            Product.countDocuments(),
            Order.countDocuments(),
            Order.countDocuments({ order_date: { $gte: today } }),
            Product.countDocuments({ stock_quantity: { $lt: 10 } })
        ]);

        const todayRevenue = await Order.aggregate([
            { $match: { order_date: { $gte: today } } },
            { $group: { _id: null, total: { $sum: "$total_amount" } } }
        ]);

        res.json({
            users: totalUsers,
            products: totalProducts,
            orders: totalOrders,
            todayOrders: todayOrders,
            todayRevenue: todayRevenue[0]?.total || 0,
            lowStock: lowStock
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/random-anime', async (req, res) => {
    try {
        const allAnime = await Product.find({ status: 'Активен' });
        const shuffled = allAnime.sort(() => 0.5 - Math.random());
        const randomAnime = shuffled.slice(0, 4);
        res.json({ success: true, anime: randomAnime });
    } catch (err) {
        console.error('Ошибка при получении рандомных аниме:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/register', async (req, res) => {
    const { first_name, last_name, middle_name, phone_number, email, address, date_of_birth, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        const user = new User({
            first_name,
            last_name,
            middle_name,
            phone_number,
            address,
            date_of_birth,
            email,
            password: hashedPassword,
        });

        await user.save();
        req.session.userId = user._id;
        res.redirect('/');
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/register', (req, res) => {
    if (req.session.userId) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        let user = await User.findOne({ email });

        if (!user) {
            user = await Admin.findOne({ email });
        }

        if (user && await bcrypt.compare(password, user.password)) {
            req.session.userId = user._id;
            req.session.role = user.role;
            req.session.user = {
                id: user._id,
                email: user.email,
                role: user.role
            };

            console.log('User logged in:', req.session.userId);

            await syncCartWithDatabase(req, res, () => {});

            if (user.role === "Главный администратор") {
                return res.redirect('/admin');
            } else {
                return res.redirect('/');
            }
        } else {
            res.status(400).send('Invalid credentials');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/login', (req, res) => {
    if (req.session.userId) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.use('/profile', loadCartFromDatabase);
app.use('/cart', loadCartFromDatabase);
app.use('/checkout', loadCartFromDatabase);

app.get('/user-info', (req, res) => {
    if (req.session.userId && req.session.user) {
        res.json({
            userId: req.session.userId,
            email: req.session.user.email,
            role: req.session.user.role
        });
    } else {
        res.status(401).json({ message: 'Unauthorized' });
    }
});

function isAdmin(req, res, next) {
    if (req.session.role && req.session.role === "Главный администратор" || req.session.role === "Администратор") {
        return next();
    }
    res.status(403).send('Access denied');
}

app.get('/admin', isAdmin, async (req, res) => {
    try {
        const products = await Product.find({}).sort({ createdAt: -1 });
        const categories = await Category.find({});

        const stats = await SalesStatistics.findOne().sort({ _id: -1 });

        res.render('adminProfile', {
            user: req.session.user,
            products: products,
            categories: categories,
            stats: stats || {}
        });
    } catch (err) {
        console.error(err);
        res.status(500).send("Ошибка загрузки данных админ-панели");
    }
});

app.post('/admin/products/update-stock', isAdmin, async (req, res) => {
    try {
        const { productId, stock_quantity } = req.body;
        await Product.findByIdAndUpdate(productId, { stock_quantity });
        res.redirect('/admin');
    } catch (err) {
        res.status(500).send(err.message);
    }
});

app.post('/admin/products/delete/:id', isAdmin, async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.redirect('/admin');
    } catch (err) {
        res.status(500).send("Ошибка при удалении");
    }
});

app.get('/auth-status', (req, res) => {
    if (req.session.userId) {
        res.json({ loggedIn: true });
    } else {
        res.json({ loggedIn: false });
    }
});

app.get('/userAccount', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        const user = await User.findById(req.session.userId);
        if (!user) {
            return res.status(404).send('User not found');
        }

        const orders = await Order.find({ user: user._id }).sort({ _id: -1 });

        res.render('userAccount', { user, orders });
    } catch (err) {
        console.error("Ошибка при получении заказов:", err);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/edit-user-details', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/login');
    }

    try {
        const { first_name, middle_name, last_name, email, phone_number } = req.body;
        await User.findByIdAndUpdate(req.session.userId, {
            first_name,
            middle_name,
            last_name,
            email,
            phone_number,
            about
        });

        res.redirect('/userAccount');
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/change-password', async (req, res) => {
    const { currentPassword, newPassword } = req.body;

    try {
        const user = await User.findById(req.session.userId);
        if (!user || !(await bcrypt.compare(currentPassword, user.password))) {
            return res.status(400).send('Current password is incorrect');
        }

        const hashedNewPassword = await bcrypt.hash(newPassword, 10);
        user.password = hashedNewPassword;
        await user.save();

        res.send('Password changed successfully');
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).send('Ошибка при выходе из аккаунта');
        }
        res.redirect('/index');
    });
});

app.post('/delete-account', async (req, res) => {
    if (!req.session.userId) {
        return res.redirect('/index');
    }

    try {
        const userId = req.session.userId;

        await Order.deleteMany({ user_id: userId });

        await User.findByIdAndDelete(userId);

        req.session.destroy(err => {
            if (err) {
                return res.status(500).send('Ошибка при удалении аккаунта');
            }
            res.redirect('/index');
        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/index', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/checkout', async (req, res) => {

    console.log('req.body:', req.body);
    console.log('selectedItems raw:', req.body.selectedItems);
    console.log('typeof selectedItems:', typeof req.body.selectedItems);
    try {
        console.log('Checkout session userId:', req.session.userId);

        if (!req.session.userId) {
            return res.status(401).send('Вы должны быть зарегистрированы или войти в аккаунт');
        }

        let selectedIds = req.body.selectedItems;

        if (typeof selectedIds === 'string') {
            selectedIds = selectedIds.includes(',') ? selectedIds.split(',') : [selectedIds];
        }

        if (Array.isArray(selectedIds)) {
            selectedIds = selectedIds
                .map(id => id.trim())
                .filter(id => id && id.length > 0);
        }

        if (!selectedIds || selectedIds.length === 0) {
            return res.status(400).send('Выбранные товары не найдены (пустой выбор)');
        }

        const cartItemsInDb = await CartItem.find({
            _id: { $in: selectedIds },
            user: req.session.userId
        }).populate('product_id');

        if (!cartItemsInDb || cartItemsInDb.length === 0) {
            return res.status(400).send('Выбранные товары не найдены в вашей корзине');
        }

        const totalAmount = cartItemsInDb.reduce((acc, item) => {
            const price = item.product_id ? item.product_id.price : 0;
            return acc + (price * item.quantity);
        }, 0);

        const { name, first_name, address, payment, shipping } = req.body;
        const trackingNumber = 'TR' + Math.floor(10000000000000 + Math.random() * 90000000000000);

        let paymentStatus = (payment === 'card') ? 'Оплачен' : 'Ожидание оплаты';
        let paymentMessage = (payment === 'card') ? 'заказ успешно оплачен' : 'наличными при получении';

        const orderItems = cartItemsInDb.map(item => ({
            product: item.product_id._id,
            name: item.product_id.name,
            quantity: item.quantity,
            price: item.product_id.price
        }));

        const newOrder = new Order({
            order_number: trackingNumber,
            user: req.session.userId,
            first_name: name || first_name,
            last_name: req.body.last_name || "",
            items: orderItems,
            total_amount: totalAmount,
            payment_method: paymentStatus,
            delivery_method: shipping,
            delivery_address: address,
            status: 'Новый',
            ip_address: req.ip
        });

        await newOrder.save();

        await CartItem.deleteMany({ _id: { $in: selectedIds } });

        if (req.session.cart) {
            req.session.cart = req.session.cart.filter(item => !selectedIds.includes(item._id.toString()));
        }

        res.render('checkout-success', {
            name: `${name || ''} ${first_name || ''}`.trim(),
            address,
            payment: paymentMessage,
            trackingNumber,
            shipping
        });
    } catch (err) {
        console.error('Order Error:', err);
        res.status(500).json({ message: "Ошибка при оформлении заказа: " + err.message });
    }
});

app.get('/products', async (req, res) => {
    try {
        const products = await Product.find({});
        const reviews = await Review.find({});

        const productsWithReviews = products.map(product => {
            const productReviews = reviews.filter(review => review.product_id.equals(product._id));
            return { ...product.toObject(), reviews: productReviews };
        });

        res.render('index', { products: productsWithReviews });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/search', async (req, res) => {
    try {
        const query = req.query.q;

        if (!query) {
            return res.status(400).send('Search query is required');
        }

        const regex = new RegExp(query, 'i');

        const products = await Product.find({
            $or: [
                { name: regex },
                { description: regex }
            ]
        });

        res.render('search-results', { query, products });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/product/:id/review', async (req, res) => {
    try {
        const { review_text, rating } = req.body;
        const userId = req.session.userId;

        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).send('Invalid product ID');
        }

        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).send('Product not found');
        }

        const review = new Review({
            user_id: userId,
            product_id: req.params.id,
            review_text,
            rating
        });

        await review.save();

        res.status(201).json({ message: 'Ваш отзыв отправлен и ожидает одобрения.' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.get('/api/products/recommendations/:productId', async (req, res) => {
    try {
        const productId = req.params.productId;

        const currentProduct = await Product.findById(productId);
        if (!currentProduct) {
            return res.status(404).json({ success: false, message: 'Товар не найден' });
        }

        const nameWords = currentProduct.name
            .toLowerCase()
            .replace(/[^\w\s]/g, '')
            .split(/\s+/)
            .filter(word => word.length > 2);

        const searchConditions = [];

        searchConditions.push({
            category_name: currentProduct.category_name,
            _id: { $ne: productId },
            status: 'Активен'
        });

        if (nameWords.length > 0) {
            searchConditions.push({
                _id: { $ne: productId },
                status: 'Активен',
                $or: nameWords.map(word => ({
                    name: { $regex: word, $options: 'i' }
                }))
            });
        }

        searchConditions.push({
            seller_name: currentProduct.seller_name,
            _id: { $ne: productId },
            status: 'Активен'
        });

        let recommendations = [];
        const seenIds = new Set();

        for (const condition of searchConditions) {
            const products = await Product.find(condition).limit(8);
            for (const product of products) {
                if (!seenIds.has(product._id.toString())) {
                    seenIds.add(product._id.toString());

                    let matchType = 'other';
                    if (product.category_name === currentProduct.category_name) {
                        matchType = 'category';
                    } else if (nameWords.some(word => product.name.toLowerCase().includes(word))) {
                        matchType = 'name';
                    } else if (product.seller_name === currentProduct.seller_name) {
                        matchType = 'seller';
                    }

                    recommendations.push({
                        _id: product._id,
                        name: product.name,
                        price: product.price,
                        images: product.images,
                        category_name: product.category_name,
                        seller_name: product.seller_name,
                        rating: product.rating,
                        matchType: matchType
                    });
                }
            }
            if (recommendations.length >= 12) break;
        }

        if (recommendations.length < 4) {
            const randomProducts = await Product.aggregate([
                {
                    $match: {
                        _id: { $ne: currentProduct._id },
                        status: 'Активен',
                        category_name: currentProduct.category_name
                    }
                },
                { $sample: { size: 8 } }
            ]);

            for (const product of randomProducts) {
                if (!seenIds.has(product._id.toString())) {
                    seenIds.add(product._id.toString());
                    recommendations.push({
                        _id: product._id,
                        name: product.name,
                        price: product.price,
                        images: product.images,
                        category_name: product.category_name,
                        seller_name: product.seller_name,
                        rating: product.rating,
                        matchType: 'random'
                    });
                }
                if (recommendations.length >= 12) break;
            }
        }

        recommendations = recommendations.slice(0, 12);

        res.json({ success: true, recommendations: recommendations });
    } catch (error) {
        console.error('Ошибка при получении рекомендаций:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

app.get('/api/categories', async (req, res) => {
    try {
        const categories = await Product.distinct('category_name', { status: 'Активен' });

        const categoryList = categories.map(name => ({
            name: name,
            description: `Товары категории ${name}`,
            slug: encodeURIComponent(name)
        }));

        res.json(categoryList);
    } catch (err) {
        console.error('Ошибка получения категорий:', err);
        res.status(500).json({ message: err.message });
    }
});

app.get('/api/products/category/:categoryName', async (req, res) => {
    try {
        const categoryName = decodeURIComponent(req.params.categoryName);
        const products = await Product.find({
            category_name: categoryName,
            status: 'Активен'
        });
        res.json({ success: true, products: products, categoryName: categoryName });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.get('/catalog/:category', async (req, res) => {
    try {
        const categoryName = decodeURIComponent(req.params.category);

        const products = await Product.find({
            category_name: categoryName,
            status: 'Активен'
        });

        const categories = await Product.distinct('category_name', { status: 'Активен' });

        res.render('category', {
            products: products,
            categoryName: categoryName,
            categories: categories
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка загрузки категории');
    }
});

app.get('/catalog', async (req, res) => {
    try {
        const categories = await Product.distinct('category_name', { status: 'Активен' });

        const allProducts = await Product.find({ status: 'Активен' });

        res.render('catalog', {
            categories: categories,
            products: allProducts
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка загрузки каталога');
    }
});

const SellerSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    storeName: { type: String, required: true },
    storeDescription: { type: String, default: '' },
    storeLogo: { type: String, default: '' },
    contactPhone: { type: String, default: '' },
    contactEmail: { type: String, default: '' },
    isActive: { type: Boolean, default: true },
    registrationDate: { type: Date, default: Date.now },
    rating: { type: Number, default: 0 },
    totalSales: { type: Number, default: 0 },
    totalRevenue: { type: Number, default: 0 }
});

const Seller = mongoose.model('Seller', SellerSchema);

app.post('/api/become-seller', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ success: false, message: 'Не авторизован' });
        }

        const { storeName, storeDescription, contactPhone } = req.body;

        if (!storeName) {
            return res.status(400).json({ success: false, message: 'Название магазина обязательно' });
        }

        const existingSeller = await Seller.findOne({ userId: req.session.userId });
        if (existingSeller) {
            return res.status(400).json({ success: false, message: 'Вы уже являетесь продавцом' });
        }

        const seller = new Seller({
            userId: req.session.userId,
            storeName: storeName,
            storeDescription: storeDescription || '',
            contactPhone: contactPhone || '',
            contactEmail: req.session.user.email
        });

        await seller.save();

        await User.findByIdAndUpdate(req.session.userId, { role: 'Продавец' });

        res.json({ success: true, message: 'Поздравляем! Вы теперь продавец!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: err.message });
    }
});

app.get('/api/seller/info', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ success: false, message: 'Не авторизован' });
        }

        const seller = await Seller.findOne({ userId: req.session.userId });
        if (!seller) {
            return res.json({ success: true, isSeller: false });
        }

        res.json({ success: true, isSeller: true, seller: seller });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.get('/seller/dashboard', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.redirect('/login');
        }

        const user = await User.findById(req.session.userId);
        const seller = await Seller.findOne({ userId: req.session.userId });

        if (!seller) {
            return res.redirect('/userAccount?error=not_seller');
        }

        const products = await Product.find({ seller_name: user.first_name + ' ' + user.last_name });

        const allOrders = await Order.find().sort({ createdAt: -1 });
        const sellerOrders = [];

        for (const order of allOrders) {
            const sellerItems = order.items.filter(item =>
                products.some(p => p.name === item.name)
            );
            if (sellerItems.length > 0) {
                sellerOrders.push({
                    ...order.toObject(),
                    sellerItems: sellerItems,
                    sellerTotal: sellerItems.reduce((sum, item) => sum + (item.price * item.quantity), 0)
                });
            }
        }

        const totalOrders = sellerOrders.length;
        const totalRevenue = sellerOrders.reduce((sum, order) => sum + order.sellerTotal, 0);
        const totalProducts = products.length;
        const lowStockProducts = products.filter(p => p.stock_quantity < 10);

        res.render('sellerDashboard', {
            user: user,
            seller: seller,
            products: products,
            orders: sellerOrders,
            stats: {
                totalOrders: totalOrders,
                totalRevenue: totalRevenue,
                totalProducts: totalProducts,
                lowStockCount: lowStockProducts.length
            }
        });
    } catch (err) {
        console.error(err);
        res.status(500).send('Ошибка загрузки панели продавца');
    }
});

app.post('/seller/products/add', isAuthenticated, async (req, res) => {
    try {
        const { name, description, price, stock_quantity, category_name, images } = req.body;
        const user = await User.findById(req.session.userId);

        if (!user) {
            return res.status(404).json({ success: false, message: 'Пользователь не найден' });
        }

        if (!name || !price) {
            return res.status(400).json({ success: false, message: 'Название и цена обязательны' });
        }

        let category = await Category.findOne({ name: category_name || 'Общая' });
        if (!category) {
            category = new Category({
                name: category_name || 'Общая',
                description: `Товары категории ${category_name || 'Общая'}`,
                keywords: [(category_name || 'общая').toLowerCase()]
            });
            await category.save();
            console.log(`✅ Создана новая категория: ${category.name}`);
        }

        let imageArray = ['/images/no-image.png'];
        if (images) {
            if (Array.isArray(images)) {
                imageArray = images;
            } else if (typeof images === 'string' && images.trim()) {
                imageArray = [images];
            }
        }

        const product = new Product({
            name: name.trim(),
            description: description || '',
            price: parseFloat(price),
            stock_quantity: parseInt(stock_quantity) || 0,
            category: category._id,
            category_name: category.name,
            seller_name: user.first_name + ' ' + user.last_name,
            images: imageArray,
            sku: 'SKU_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
            status: 'Активен',
            rating: 0,
            attributes: []
        });

        await product.save();
        console.log(`✅ Товар добавлен: ${product.name} (продавец: ${product.seller_name})`);

        res.json({ success: true, message: 'Товар успешно добавлен', product: product });
    } catch (err) {
        console.error('Ошибка при добавлении товара:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

app.put('/seller/products/:id', isAuthenticated, async (req, res) => {
    try {
        const { name, description, price, stock_quantity, category_name, status } = req.body;

        await Product.findByIdAndUpdate(req.params.id, {
            name, description, price: parseFloat(price),
            stock_quantity: parseInt(stock_quantity), category_name, status
        });

        res.json({ success: true, message: 'Товар обновлён' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.delete('/seller/products/:id', isAuthenticated, async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.json({ success: true, message: 'Товар удалён' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/seller/orders/:orderId/status', isAuthenticated, async (req, res) => {
    try {
        const { status } = req.body;
        await Order.findByIdAndUpdate(req.params.orderId, { status: status });
        res.json({ success: true, message: 'Статус заказа обновлён' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

function isAuthenticated(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ success: false, message: 'Не авторизован' });
    }
    next();
}

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.set('views', __dirname + '/views');

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/admin_account.html');
    res.sendFile(__dirname + '/public/user-account.html');
    res.sendFile(__dirname + '/public/admin_account.html');
    res.sendFile(__dirname + '/public/shopping_cart.html');
    res.sendFile(__dirname + '/public/register.html');
    res.sendFile(__dirname + '/public/login.html');
    res.sendFile(__dirname + '/public/user-account-script.js');
    res.sendFile(__dirname + '/public/admin_account_script.js');
    res.sendFile(__dirname + '/public/script.js');
    res.sendFile(__dirname + '/public/shopping_cart_script.js');
    res.sendFile(__dirname + '/public/shopping_cart_styles.css');
    res.sendFile(__dirname + '/public/styles_product.css');
    res.sendFile(__dirname + '/public/styles.css');
    res.sendFile(__dirname + '/public/admin_account_style.css');
    res.sendFile(__dirname + '/public/user-account-styles.css');
});

app.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});