const CartItem = require('../models/CartItem');

// Middleware для синхронизации корзины сессии с БД при входе
const syncCartWithDatabase = async (req, res, next) => {
    if (req.session.userId && req.session.cart && req.session.cart.length > 0) {
        try {
            await CartItem.migrateFromSession(req.session.userId, req.session.cart);

            req.session.cart = [];

            console.log('Корзина успешно синхронизирована с базой данных');
        } catch (error) {
            console.error('Ошибка синхронизации корзины:', error);
        }
    }
    next();
};

// Middleware для загрузки корзины из БД
const loadCartFromDatabase = async (req, res, next) => {
    if (req.session.userId) {
        try {
            const dbCart = await CartItem.getUserCart(req.session.userId);

            req.session.cart = dbCart.map(item => ({
                _id: item._id,
                product_id: item.product_id,
                quantity: item.quantity,
                size: item.size,
                color: item.color,
                selected: item.selected
            }));

            res.locals.cart = dbCart;
            res.locals.cartCount = dbCart.reduce((sum, item) => sum + item.quantity, 0);
        } catch (error) {
            console.error('Ошибка загрузки корзины:', error);
        }
    }
    next();
};

module.exports = {
    syncCartWithDatabase,
    loadCartFromDatabase
};