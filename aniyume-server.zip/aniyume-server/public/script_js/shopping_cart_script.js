document.addEventListener('DOMContentLoaded', function() {
    updateCartCount(); 
    
    if (document.getElementById('cartList')) {
        loadCart();
    }
});

function loadCart() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartList = document.getElementById('cartList');
    if (!cartList) return;

    cartList.innerHTML = '';
    let totalQty = 0;
    let totalSum = 0;

    cart.forEach((item, index) => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        const imageUrl = Array.isArray(item.images) && item.images.length > 0 ? item.images[0] : '';

        cartItem.innerHTML = `
            <input type="checkbox" name="selectedItems" value="${item.id}">
            <img src="${imageUrl}" alt="${item.name}" width="100">
            <div class="cart-item-details">
                <h3>${item.name}</h3>
                <p>Цена: ${item.price} руб.</p>
                <div class="quantity-controls">
                    <button type="button" onclick="changeQuantityServer('${item.id}', -1)">-</button>
                    <input type="number" id="qty-${item.id}" value="${item.quantity}" min="1" readonly>
                    <button type="button" onclick="changeQuantityServer('${item.id}', 1)">+</button>
                </div>
                <button onclick="removeItem('${item.id}')">Удалить</button>
            </div>
        `;
        cartList.appendChild(cartItem);
        totalQty += parseInt(item.quantity);
        totalSum += item.price * item.quantity;
    });

    const totalQtyElem = document.getElementById('totalQuantity');
    const totalPriceElem = document.getElementById('totalPrice');
    if (totalQtyElem) totalQtyElem.textContent = totalQty;
    if (totalPriceElem) totalPriceElem.textContent = totalSum;
}

async function changeQuantityServer(productId, delta) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const item = cart.find(i => i.id === productId);
    if (!item) return;

    const newQuantity = item.quantity + delta;
    if (newQuantity < 1) return;

    try {
        const response = await fetch(`/cart/update/${productId}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ quantity: newQuantity })
        });

        if (response.ok) {
            item.quantity = newQuantity;
            localStorage.setItem('cart', JSON.stringify(cart));
            loadCart();
            updateCartCount();
        }
    } catch (error) {
        console.error('Ошибка:', error);
    }
}

function updateQuantity(index, quantity) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart[index].quantity = quantity;
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCart();
    updateCartCount();
}

function removeItem(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.filter(item => item.id !== productId && item._id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCart();
    updateCartCount();
}

// Обновление счётчика корзины
async function updateCartCount() {
    try {
        const response = await fetch('/cart/count');
        const data = await response.json();
        const countElement = document.getElementById('cartCount');
        if (countElement) {
            countElement.textContent = data.count || 0;
        }
    } catch (err) {
        // Фоллбек на localStorage, если сервер не ответил
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const countElement = document.getElementById('cartCount');
        if (countElement) {
            countElement.textContent = cart.length;
        }
    }
}

// Функция добавления в корзину 
async function addToCartServer(productId) {
    const quantityInput = document.getElementById('quantity');
    const quantity = quantityInput ? parseInt(quantityInput.value) : 1;

    const btn = document.querySelector('#addToCartForm button');
    const originalText = btn ? btn.textContent : 'Добавить';
    
    if (btn) {
        btn.textContent = '⏳ Добавление...';
        btn.disabled = true;
    }

    try {
        const response = await fetch('/cart/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                productId: productId,
                quantity: quantity
            })
        });

        if (response.status === 401) {
            alert('Пожалуйста, войдите в систему, чтобы добавить товар в корзину');
            window.location.href = '/login';
            return;
        }

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Ошибка сети или сервера');
        }

        const data = await response.json();
        
        if (data && data.success) {
            showNotification('✅ Товар добавлен в корзину!');
            await updateCartCount();
        } else {
            showNotification(data.message || '❌ Ошибка при добавлении в корзину', 'error');
        }
    } catch (error) {
        console.error('Ошибка:', error);
        const countElement = document.getElementById('cartCount');
        const currentCount = countElement ? parseInt(countElement.textContent) : 0;
        
        if (currentCount === 0) {
            await updateCartCount();
            const newCount = countElement ? parseInt(countElement.textContent) : 0;
            if (newCount > 0) {
                showNotification('✅ Товар добавлен в корзину!');
            } else {
                showNotification('❌ Ошибка соединения с сервером', 'error');
            }
        } else {
            showNotification('✅ Товар добавлен в корзину!');
        }
    } finally {
        if (btn) {
            btn.textContent = originalText;
            btn.disabled = false;
        }
    }
}

// Функция для красивого уведомления
function showNotification(message, type = 'success') {
    const oldNotif = document.querySelector('.custom-notification');
    if (oldNotif) oldNotif.remove();

    const notif = document.createElement('div');
    notif.className = 'custom-notification';
    notif.innerHTML = message;
    notif.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: ${type === 'success' ? 'linear-gradient(135deg, #ff6b6b, #ff4757)' : 'linear-gradient(135deg, #e74c3c, #c0392b)'};
        color: white;
        padding: 12px 24px;
        border-radius: 40px;
        z-index: 10000;
        font-weight: 600;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        animation: slideInRight 0.3s ease;
        font-family: 'Inter', sans-serif;
    `;
    document.body.appendChild(notif);
    
    setTimeout(() => {
        notif.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

if (!document.querySelector('#notification-styles')) {
    const style = document.createElement('style');
    style.id = 'notification-styles';
    style.textContent = `
        @keyframes slideInRight {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
}

function applyPromo() {
    const promo = document.getElementById('promo')?.value;
    if (promo) {
        showNotification(`Промокод "${promo}" применён!`, 'success');
    } else {
        showNotification('Введите промокод', 'error');
    }
}

let currentSlide = 0;

function showSlide(index) {
    const slides = document.querySelectorAll('.carousel-item');
    if (!slides.length) return;
    if (index >= slides.length) {
        currentSlide = 0;
    } else if (index < 0) {
        currentSlide = slides.length - 1;
    } else {
        currentSlide = index;
    }
    slides.forEach((slide, idx) => {
        slide.classList.remove('active');
        if (idx === currentSlide) slide.classList.add('active');
    });
}

function nextSlide() { showSlide(currentSlide + 1); }
function prevSlide() { showSlide(currentSlide - 1); }
function nextSlideInModal() { nextSlide(); updateModalImage(); }
function prevSlideInModal() { prevSlide(); updateModalImage(); }

function updateModalImage() {
    const activeSlide = document.querySelector('.carousel-item.active img');
    const modalImg = document.getElementById("img01");
    if (activeSlide && modalImg) modalImg.src = activeSlide.src;
}

function openFullscreen(imageUrl) {
    const modal = document.getElementById("myModal");
    const modalImg = document.getElementById("img01");
    if (modal && modalImg) {
        modal.style.display = "block";
        modalImg.src = imageUrl;
    }
}

function closeFullscreen() {
    const modal = document.getElementById("myModal");
    if (modal) modal.style.display = "none";
}

// Обработка формы оформления заказ
const checkoutForm = document.getElementById('checkoutForm');
if (checkoutForm) {
    checkoutForm.addEventListener('submit', function(e) {
        const selectedCheckboxes = this.querySelectorAll('input[name="selectedItems"]:checked');
        if (selectedCheckboxes.length === 0) {
            alert('Пожалуйста, выберите хотя бы один товар для оформления заказа.');
            e.preventDefault();
            return;
        }
        const selectedIds = Array.from(selectedCheckboxes).map(cb => cb.value);
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        const updatedCart = cart.filter(item => !selectedIds.includes(String(item.id || item._id)));
        localStorage.setItem('cart', JSON.stringify(updatedCart));
    });
}

window.addToCartServer = addToCartServer;
window.updateCartCount = updateCartCount;
window.showNotification = showNotification;
window.removeItem = removeItem;
window.changeQuantityServer = changeQuantityServer;