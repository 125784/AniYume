document.addEventListener('DOMContentLoaded', () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    if (productId) {
        fetchProduct(productId);
    } else {
        console.error('Product ID is missing in URL');
    }

    // Обновляем счетчик корзины после загрузки
    updateCartCount();
});

async function fetchProduct(productId) {
    try {
        const response = await fetch(`/products/${productId}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const product = await response.json();
        displayProduct(product);
    } catch (error) {
        console.error('Failed to fetch the product:', error);
    }
}

function displayProduct(product) {
    document.getElementById('product-image').src = product.image_url;
    document.getElementById('product-name').textContent = product.name;
    document.getElementById('product-description').textContent = product.description;
    document.getElementById('product-price').textContent = `Цена: ${product.price} руб.`;
    document.getElementById('product-stock').textContent = `На складе: ${product.stock_quantity}`;
}

let currentIndex = 0;

function showSlide(index) {
    const carouselInner = document.querySelector('.carousel-inner');
    const slides = document.querySelectorAll('.carousel-item');
    if (index >= slides.length) currentIndex = 0;
    if (index < 0) currentIndex = slides.length - 1;
    for (let i = 0; i < slides.length; i++) {
        slides[i].classList.remove('active');
    }
    slides[currentIndex].classList.add('active');
}

function nextSlide() {
    currentIndex++;
    showSlide(currentIndex);
}

function prevSlide() {
    currentIndex--;
    showSlide(currentIndex);
}

function openFullscreen(element) {
    const modal = document.getElementById("myModal");
    const modalImg = document.getElementById("img01");
    modal.style.display = "flex";
    modalImg.src = element.src;
    currentIndex = Array.from(element.parentNode.parentNode.children).indexOf(element.parentNode);
}

function closeFullscreen() {
    const modal = document.getElementById("myModal");
    modal.style.display = "none";
}

function nextSlideInModal() {
    currentIndex++;
    const slides = document.querySelectorAll('.carousel-item img');
    if (currentIndex >= slides.length) currentIndex = 0;
    document.getElementById("img01").src = slides[currentIndex].src;
}

function prevSlideInModal() {
    currentIndex--;
    const slides = document.querySelectorAll('.carousel-item img');
    if (currentIndex < 0) currentIndex = slides.length - 1;
    document.getElementById("img01").src = slides[currentIndex].src;
}

function addToCart() {
    const name = document.querySelector('h1').textContent;
    const price = parseInt(document.querySelector('.price').textContent.replace('Цена: ', '').replace(' руб.', ''));
    const image = document.querySelector('.product-gallery img').src;
    const quantity = document.getElementById('quantity').value;

    const product = {
        name: name,
        price: price,
        quantity: quantity,
        image: image
    };

    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));

    alert(`Товар "${name}" добавлен в корзину. Количество: ${quantity}`);
    updateCartCount();
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    document.getElementById('cartCount').textContent = cart.length;
}

document.getElementById('review-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const rating = document.getElementById('rating').value;
    const comment = document.getElementById('comment').value;
    alert(`Отзыв добавлен. Рейтинг: ${rating}, Комментарий: ${comment}`);
});

function buyNow() {
    addToCart();
    window.location.href = 'shopping_cart.html';
}

document.addEventListener('fullscreenchange', () => {
    if (!document.fullscreenElement) {
        document.querySelector('.carousel-inner').style.transform = `translateX(-${currentIndex * 100}%)`;
    }
});