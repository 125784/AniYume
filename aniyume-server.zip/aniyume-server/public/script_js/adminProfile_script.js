let salesData = { salesByDate: [], revenueByDate: [], averageCheckByDate: [] };
let currentChart = null;

document.addEventListener('DOMContentLoaded', () => {
    updateStatistics();
    
    // Обработчик изменения периода
    const periodSelect = document.getElementById('period');
    if (periodSelect) {
        periodSelect.addEventListener('change', function() {
            const customDateRange = document.getElementById('customDateRange');
            if (customDateRange) {
                customDateRange.style.display = this.value === 'custom' ? 'flex' : 'none';
            }
        });
    }
    
    // Поиск по товарам
    const searchInput = document.getElementById('product-search');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const val = e.target.value.toLowerCase();
            document.querySelectorAll('.product-row').forEach(row => {
                row.style.display = row.innerText.toLowerCase().includes(val) ? '' : 'none';
            });
        });
    }
});

async function updateStatistics() {
    const period = document.getElementById('period')?.value || 'month';
    const productFilter = document.getElementById('productFilter')?.value || 'quantity';
    let startDate = '', endDate = '';
    
    if (period === 'custom') {
        startDate = document.getElementById('startDate')?.value || '';
        endDate = document.getElementById('endDate')?.value || '';
    }
    
    try {
        const response = await fetch(`/admin/statistics?period=${period}&productFilter=${productFilter}&startDate=${startDate}&endDate=${endDate}`);
        const data = await response.json();
        
        // Сохраняем данные
        salesData = data.sales || { salesByDate: [], revenueByDate: [], averageCheckByDate: [] };
        
        // Обновляем карточки метрик
        const metrics = {
            salesCount: data.sales?.salesCount || 0,
            totalRevenue: data.sales?.totalRevenue || 0,
            averageCheck: data.sales?.averageCheck || 0,
            cancelledOrdersCount: data.sales?.cancelledOrdersCount || 0,
            returnsCount: data.sales?.returnsCount || 0,
            profit: data.sales?.profit || 0
        };
        
        for (const [key, value] of Object.entries(metrics)) {
            const element = document.getElementById(key);
            if (element) {
                if (key === 'totalRevenue' || key === 'averageCheck' || key === 'profit' || key === 'returnsCount') {
                    element.innerText = typeof value === 'number' ? value.toLocaleString('ru-RU') + ' ₽' : value;
                } else {
                    element.innerText = typeof value === 'number' ? value.toLocaleString('ru-RU') : value;
                }
            }
        }
        
        // Обновляем таблицу популярных товаров
        updatePopularProductsTable(data.popularProducts || []);
        
        // Обновляем информацию о пользователях и товарах
        if (data.users) {
            const userTotal = document.getElementById('userTotal');
            if (userTotal) userTotal.innerText = data.users.total || 0;
        }
        
        if (data.products) {
            const productTotal = document.getElementById('productTotal');
            if (productTotal) productTotal.innerText = data.products.total || 0;
            const lowStock = document.getElementById('lowStock');
            if (lowStock) lowStock.innerText = data.products.lowStock || 0;
        }
        
        // Обновляем конверсию
        const conversionRate = document.getElementById('conversionRate');
        if (conversionRate) conversionRate.innerText = data.conversionRate + '%';
        
    } catch (error) {
        console.error("Ошибка при получении статистики:", error);
    }
}

function updatePopularProductsTable(products) {
    const table = document.getElementById('popularProductsTable');
    if (!table) return;
    
    let tbody = table.querySelector('tbody');
    if (!tbody) {
        tbody = document.createElement('tbody');
        table.appendChild(tbody);
    }
    tbody.innerHTML = '';
    
    if (products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align: center;">Нет данных</td></tr>';
        return;
    }
    
    products.forEach(product => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = product.name;
        row.insertCell(1).textContent = product.quantity;
        row.insertCell(2).textContent = product.revenue.toLocaleString('ru-RU') + ' ₽';
    });
}

function drawChart(type) {
    const canvas = document.getElementById('salesChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (currentChart) currentChart.destroy();
    
    let labels = [], data = [], title = '';
    
    if (type === 'sales' && salesData.salesByDate) {
        labels = salesData.salesByDate.map(item => item.date);
        data = salesData.salesByDate.map(item => item.count);
        title = 'Количество продаж';
    } else if (type === 'revenue' && salesData.revenueByDate) {
        labels = salesData.revenueByDate.map(item => item.date);
        data = salesData.revenueByDate.map(item => item.revenue);
        title = 'Выручка по дням';
    } else if (type === 'averageCheck' && salesData.averageCheckByDate) {
        labels = salesData.averageCheckByDate.map(item => item.date);
        data = salesData.averageCheckByDate.map(item => item.averageCheck);
        title = 'Средний чек';
    }
    
    if (labels.length === 0) {
        labels = ['Нет данных'];
        data = [0];
    }
    
    currentChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: title,
                data: data,
                borderColor: '#ff6b6b',
                backgroundColor: 'rgba(255,107,107,0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { labels: { color: '#fff' } }
            },
            scales: {
                y: { 
                    ticks: { color: '#fff' }, 
                    grid: { color: 'rgba(255,255,255,0.1)' } 
                },
                x: { 
                    ticks: { color: '#fff', maxRotation: 45, minRotation: 45 }, 
                    grid: { color: 'rgba(255,255,255,0.1)' } 
                }
            }
        }
    });
}

function exportToPDF() {
    alert('Функция экспорта в PDF будет реализована позже.');
}

function exportToExcel() {
    alert('Функция экспорта в Excel будет реализована позже.');
}