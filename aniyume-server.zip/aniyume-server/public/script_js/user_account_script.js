function toggleOrder(element) {
    const details = element.nextElementSibling;
    details.classList.toggle('active');
}

function addAddress() {
    const input = document.getElementById('newAddress');
    const address = input.value.trim();
    if (address) {
        fetch('/user/add-address', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ address: address })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                showNotification('❌ Ошибка при добавлении адреса', 'error');
            }
        })
        .catch(err => console.error(err));
    }
}

function removeAddress(index) {
    fetch('/user/remove-address', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ index: index })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            showNotification('❌ Ошибка при удалении адреса', 'error');
        }
    })
    .catch(err => console.error(err));
}

document.getElementById('passwordForm')?.addEventListener('submit', function(e) {
    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmPassword').value;
    if (newPass !== confirmPass) {
        e.preventDefault();
        showNotification('❌ Новый пароль и подтверждение не совпадают', 'error');
    }
});

function showNotification(message, type = 'success') {
    const notif = document.createElement('div');
    notif.className = 'notification';
    notif.style.background = type === 'success' ? '#2ecc71' : '#e74c3c';
    notif.innerHTML = message;
    document.body.appendChild(notif);
    setTimeout(() => notif.remove(), 3000);
}

function downloadOrders() {
    fetch('/user/download-orders')
        .then(res => res.blob())
        .then(blob => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'my_orders.json';
            a.click();
            URL.revokeObjectURL(url);
            showNotification('📥 История заказов скачана');
        })
        .catch(err => showNotification('❌ Ошибка при скачивании', 'error'));
}

function leaveReview(orderId) {
    const review = prompt('✍️ Напишите ваш отзыв о заказе:');
    if (review) {
        fetch('/user/leave-review', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId: orderId, review: review })
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                showNotification('✨ Спасибо за отзыв!');
            } else {
                showNotification('❌ Ошибка', 'error');
            }
        });
    }
}

function createSakura() {
    const sakura = document.createElement('div');
    sakura.innerHTML = '🌸';
    sakura.classList.add('sakura');
    sakura.style.position = 'fixed';
    sakura.style.left = Math.random() * window.innerWidth + 'px';
    sakura.style.top = '-30px';
    sakura.style.fontSize = (15 + Math.random() * 15) + 'px';
    sakura.style.opacity = 0.5 + Math.random() * 0.5;
    document.body.appendChild(sakura);
    let pos = -30;
    const interval = setInterval(() => {
        pos += 2 + Math.random() * 2;
        sakura.style.top = pos + 'px';
        sakura.style.transform = `rotate(${pos}deg)`;
        if (pos > window.innerHeight) {
            clearInterval(interval);
            sakura.remove();
        }
    }, 50);
}
setInterval(createSakura, 1000);

const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('updated') === 'true') {
    showNotification('✅ Профиль успешно обновлён!');
}

function openSellerModal() {
    document.getElementById('sellerModal').style.display = 'flex';
}

function closeSellerModal() {
    document.getElementById('sellerModal').style.display = 'none';
}

async function submitSellerRequest() {
    const storeName = document.getElementById('storeName').value.trim();
    const storeDescription = document.getElementById('storeDescription').value.trim();
    const contactPhone = document.getElementById('contactPhone').value.trim();
    
    if (!storeName) {
        showNotification('❌ Введите название магазина', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/become-seller', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ storeName, storeDescription, contactPhone })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('✅ Поздравляем! Вы теперь продавец!');
            setTimeout(() => location.reload(), 2000);
        } else {
            showNotification('❌ ' + data.message, 'error');
        }
    } catch (err) {
        showNotification('❌ Ошибка при отправке запроса', 'error');
    }
}