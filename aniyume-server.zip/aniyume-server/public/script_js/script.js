document.addEventListener('DOMContentLoaded', () => {
    // --- Аутентификация и поиск ---
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const profileIconDiv = document.getElementById('profileIcon');
    const userIcon = document.getElementById('userIcon');
    const adminIcon = document.getElementById('adminIcon');

    if (loginBtn) {
        loginBtn.addEventListener('click', () => window.location.href = '/login');
    }
    if (registerBtn) {
        registerBtn.addEventListener('click', () => window.location.href = '/register');
    }

    // Проверка статуса авторизации
    fetch('/auth-status')
        .then(res => res.json())
        .then(data => {
            if (data.loggedIn) {
                if (loginBtn) loginBtn.style.display = 'none';
                if (registerBtn) registerBtn.style.display = 'none';
                if (profileIconDiv) profileIconDiv.style.display = 'block';

                fetch('/user-info')
                    .then(res => res.json())
                    .then(userData => {
                        if (userData.role === "Главный администратор") {
                            if (adminIcon) adminIcon.style.display = 'block';
                            if (userIcon) userIcon.style.display = 'none';
                        } else {
                            if (userIcon) userIcon.style.display = 'block';
                            if (adminIcon) adminIcon.style.display = 'none';
                        }
                    })
                    .catch(err => console.error('Error getting user info:', err));
            } else {
                if (loginBtn) loginBtn.style.display = 'block';
                if (registerBtn) registerBtn.style.display = 'block';
                if (profileIconDiv) profileIconDiv.style.display = 'none';
            }
        })
        .catch(err => console.error('Auth status error:', err));

    // Поиск
    const searchBtn = document.getElementById('search-button');
    const searchInput = document.getElementById('search-input');
    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            const query = searchInput.value;
            if (query) window.location.href = `/search?q=${encodeURIComponent(query)}`;
        });
    }

    // --- Загрузка товаров ---
    const productGrid = document.getElementById('product-grid');
    if (productGrid) {
        fetch('/api/random-products')
            .then(res => res.json())
            .then(products => {
                products.forEach(product => {
                    const card = document.createElement('div');
                    card.className = 'product-net';
                    card.onclick = () => window.location.href = `/product/${product._id}`;
                    card.innerHTML = `
                        <img src="${product.images[0]}" alt="${product.name}">
                        <p>${product.name}</p>
                        <div class="price">${product.price} ₽</div>
                    `;
                    productGrid.appendChild(card);
                });
            })
            .catch(err => console.error('Error loading products:', err));
    }

    // --- Карусель ---
    async function loadCarouselProducts(apiEndpoint, trackId, noItemsId) {
        const track = document.getElementById(trackId);
        const noMsg = document.getElementById(noItemsId);
        if (!track) return;

        try {
            const res = await fetch(apiEndpoint);
            const products = await res.json();
            track.innerHTML = '';

            if (products.length === 0) {
                if (noMsg) noMsg.style.display = 'block';
                return;
            }

            if (noMsg) noMsg.style.display = 'none';
            products.forEach(product => {
                const slide = document.createElement('div');
                slide.className = 'carousel-slide';
                slide.onclick = () => window.location.href = `/product/${product._id}`;
                slide.innerHTML = `
                    <img src="${product.images[0]}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <div class="price">${product.price} ₽</div>
                `;
                track.appendChild(slide);
            });

            initCarousel(track.closest('.carousel-container'));
        } catch (err) {
            console.error(err);
            if (noMsg) noMsg.style.display = 'block';
        }
    }

    function initCarousel(container) {
        if (!container) return;
        const track = container.querySelector('.carousel-track');
        const slides = Array.from(track.children);
        const prevBtn = container.querySelector('.prev');
        const nextBtn = container.querySelector('.next');
        let currentIndex = 0;

        const updatePosition = () => {
            const slideWidth = slides[0]?.offsetWidth + 20 || 0;
            track.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
        };

        if (prevBtn) prevBtn.onclick = () => {
            currentIndex = Math.max(0, currentIndex - 1);
            updatePosition();
        };
        if (nextBtn) nextBtn.onclick = () => {
            currentIndex = Math.min(slides.length - 1, currentIndex + 1);
            updatePosition();
        };

        window.addEventListener('resize', updatePosition);
        setTimeout(updatePosition, 100);
    }

    loadCarouselProducts('/api/popular-products', 'popular-products-track', 'popular-no-items');

    // --- Сакура ---
    function createSakura() {
        const sakura = document.createElement('div');
        sakura.innerHTML = '🌸';
        sakura.style.position = 'fixed';
        sakura.style.left = Math.random() * window.innerWidth + 'px';
        sakura.style.top = '-30px';
        sakura.style.fontSize = (15 + Math.random() * 15) + 'px';
        sakura.style.opacity = 0.6;
        sakura.style.zIndex = 9999;
        document.body.appendChild(sakura);
        let pos = -30;
        const interval = setInterval(() => {
            pos += 2 + Math.random() * 2;
            sakura.style.top = pos + 'px';
            sakura.style.transform = `rotate(${pos}deg)`;
            if (pos > window.innerHeight) {
                clearInterval(interval);
                sakura.remove();
            }
        }, 50);
    }
    setInterval(createSakura, 800);

    // --- Корзина ---
    async function updateCartCount() {
        try {
            const response = await fetch('/cart/count');
            const data = await response.json();
            const countElement = document.getElementById('cartCount');
            if (countElement) {
                countElement.textContent = data.count || 0;
            }
        } catch (err) {
            console.error('Ошибка обновления корзины:', err);
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const countElement = document.getElementById('cartCount');
            if (countElement) countElement.textContent = cart.length;
        }
    }

    updateCartCount();
});