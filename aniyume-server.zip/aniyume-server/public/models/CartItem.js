const mongoose = require('mongoose');

const CartItemSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true
    },
    product_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true
    },
    quantity: {
        type: Number,
        required: true,
        default: 1,
        min: 1
    },
    size: {
        type: String,
        trim: true
    },
    color: {
        type: String,
        trim: true
    },
    selected: {
        type: Boolean,
        default: false
    },
    added_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: { createdAt: 'added_at', updatedAt: 'updated_at' }
});

// Уникальный индекс для комбинации пользователь+товар+размер+цвет
CartItemSchema.index(
    { user: 1, product_id: 1, size: 1, color: 1 },
    { unique: true, partialFilterExpression: { user: { $exists: true } } }
);

// Middleware для обновления updated_at
CartItemSchema.pre('save', function(next) {
    this.updated_at = Date.now();
    next();
});

// Middleware для обновления updated_at при findOneAndUpdate
CartItemSchema.pre('findOneAndUpdate', function(next) {
    this.set({ updated_at: Date.now() });
    next();
});

// Виртуальное поле для подсчета суммы
CartItemSchema.virtual('total_price').get(function() {
    if (this.populated('product_id') && this.product_id) {
        return this.product_id.price * this.quantity;
    }
    return 0;
});

// Метод для увеличения количества
CartItemSchema.methods.increaseQuantity = function(amount = 1) {
    this.quantity += amount;
    return this.save();
};

// Метод для уменьшения количества
CartItemSchema.methods.decreaseQuantity = function(amount = 1) {
    this.quantity = Math.max(1, this.quantity - amount);
    return this.save();
};

// Статический метод для получения корзины пользователя
CartItemSchema.statics.getUserCart = async function(userId) {
    return await this.find({ user: userId })
        .populate('product_id')
        .sort({ added_at: -1 });
};

// Статический метод для подсчета товаров в корзине
CartItemSchema.statics.getCartCount = async function(userId) {
    const result = await this.aggregate([
        { $match: { user: mongoose.Types.ObjectId(userId) } },
        { $group: { _id: null, totalItems: { $sum: "$quantity" } } }
    ]);
    return result.length > 0 ? result[0].totalItems : 0;
};

// Статический метод для получения общей суммы корзины
CartItemSchema.statics.getCartTotal = async function(userId) {
    const cartItems = await this.find({ user: userId }).populate('product_id');
    return cartItems.reduce((total, item) => {
        if (item.product_id && item.product_id.price) {
            return total + (item.product_id.price * item.quantity);
        }
        return total;
    }, 0);
};

// Статический метод для очистки корзины
CartItemSchema.statics.clearCart = async function(userId) {
    return await this.deleteMany({ user: userId });
};

// Статический метод для миграции из сессии
CartItemSchema.statics.migrateFromSession = async function(userId, sessionCart) {
    if (!sessionCart || !Array.isArray(sessionCart)) return [];

    const migratedItems = [];

    for (const sessionItem of sessionCart) {
        if (sessionItem.product_id && sessionItem.product_id._id) {
            const existingItem = await this.findOne({
                user: userId,
                product_id: sessionItem.product_id._id,
                size: sessionItem.size || null,
                color: sessionItem.color || null
            });

            if (existingItem) {
                // Объединяем количество
                existingItem.quantity += sessionItem.quantity || 1;
                await existingItem.save();
                migratedItems.push(existingItem);
            } else {
                // Создаем новый элемент
                const newItem = new this({
                    user: userId,
                    product_id: sessionItem.product_id._id,
                    quantity: sessionItem.quantity || 1,
                    size: sessionItem.size || null,
                    color: sessionItem.color || null,
                    selected: sessionItem.selected || false
                });
                await newItem.save();
                migratedItems.push(newItem);
            }
        }
    }

    return migratedItems;
};

// JSON-представление с виртуальными полями
CartItemSchema.set('toJSON', {
    virtuals: true,
    transform: function(doc, ret) {
        delete ret.__v;
        return ret;
    }
});

const CartItem = mongoose.model('CartItem', CartItemSchema);

module.exports = CartItem;