const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Chat = require('../models/Chat');
const ChatParticipant = require('../models/ChatParticipant');
const User = require('../models/User');

// Настройка multer для загрузки файлов
const chatStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        let folder = 'public/chat_files';
        if (file.mimetype.startsWith('image/')) folder = 'public/chat_images';
        else if (file.mimetype.startsWith('video/')) folder = 'public/chat_videos';
        else if (file.mimetype.startsWith('audio/')) folder = 'public/chat_audio';
        else folder = 'public/chat_files';
        
        if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
        cb(null, folder);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});

const chatUpload = multer({ 
    storage: chatStorage,
    limits: { fileSize: 50 * 1024 * 1024 } // 50MB лимит
});

// Middleware для аутентификации
const authenticate = (req, res, next) => {
    if (!req.session.user) {
        return res.status(401).json({ error: 'Не авторизован' });
    }
    next();
};

// Поиск пользователей по никнейму
router.get('/search', authenticate, async (req, res) => {
    try {
        const { q } = req.query;
        if (!q || q.length < 2) {
            return res.json([]);
        }

        const users = await User.find({
            _id: { $ne: req.session.user._id },
            username: { $regex: q, $options: 'i' }
        }).select('_id username avatar');

        res.json(users);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка поиска' });
    }
});

// Получить список чатов пользователя
router.get('/list', authenticate, async (req, res) => {
    try {
        const chats = await ChatParticipant.find({
            userId: req.session.user._id,
            isDeleted: false
        }).sort({ updatedAt: -1 });

        res.json(chats);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка загрузки чатов' });
    }
});

// Получить историю сообщений чата
router.get('/history/:chatId', authenticate, async (req, res) => {
    try {
        const { chatId } = req.params;
        const currentUserId = req.session.user._id;
        
        const chat = await Chat.findOne({ chatId });
        if (!chat) {
            return res.json([]);
        }
        
        if (!chat.participants.includes(currentUserId)) {
            return res.status(403).json({ error: 'Нет доступа' });
        }
        
        // Фильтруем сообщения: не показываем те, которые удалил текущий пользователь
        const filteredMessages = chat.messages.filter(msg => 
            !msg.deletedFor || !msg.deletedFor.includes(currentUserId)
        );
        
        // Обновляем прочитанные сообщения
        await Chat.updateOne(
            { chatId, 'messages.senderId': { $ne: currentUserId } },
            { $set: { 'messages.$[].read': true, 'messages.$[].readAt': new Date() } }
        );
        
        await ChatParticipant.updateOne(
            { userId: currentUserId, chatId },
            { $set: { unreadCount: 0 } }
        );
        
        res.json(filteredMessages);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка загрузки истории' });
    }
});

// Создать или получить существующий чат
router.post('/create', authenticate, async (req, res) => {
    try {
        const { companionId } = req.body;
        const currentUserId = req.session.user._id;
        
        // Сортируем ID для создания уникального chatId
        const sortedIds = [currentUserId.toString(), companionId.toString()].sort();
        const chatId = `${sortedIds[0]}_${sortedIds[1]}`;
        
        // Проверяем, существует ли чат
        let chat = await Chat.findOne({ chatId });
        
        if (!chat) {
            // Создаём новый чат
            chat = new Chat({
                chatId,
                participants: [currentUserId, companionId],
                messages: []
            });
            await chat.save();
            
            // Получаем данные собеседника
            const companion = await User.findById(companionId);
            const currentUser = await User.findById(currentUserId);
            
            // Создаём запись для текущего пользователя
            await ChatParticipant.findOneAndUpdate(
                { userId: currentUserId, chatId },
                {
                    userId: currentUserId,
                    chatId,
                    companionId,
                    companionName: companion.username,
                    companionAvatar: companion.avatar,
                    isDeleted: false
                },
                { upsert: true }
            );
            
            // Создаём запись для собеседника
            await ChatParticipant.findOneAndUpdate(
                { userId: companionId, chatId },
                {
                    userId: companionId,
                    chatId,
                    companionId: currentUserId,
                    companionName: currentUser.username,
                    companionAvatar: currentUser.avatar,
                    isDeleted: false
                },
                { upsert: true }
            );
        } else {
            // Восстанавливаем чат, если он был удалён у пользователя
            await ChatParticipant.updateOne(
                { userId: currentUserId, chatId },
                { $set: { isDeleted: false, updatedAt: new Date() } }
            );
        }
        
        res.json({ chatId, success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка создания чата' });
    }
});

// Удалить чат только у себя
router.delete('/:chatId', authenticate, async (req, res) => {
    try {
        const { chatId } = req.params;
        
        await ChatParticipant.updateOne(
            { userId: req.session.user._id, chatId },
            { $set: { isDeleted: true, updatedAt: new Date() } }
        );
        
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка удаления чата' });
    }
});

// Загрузить файл (аудио, изображение, видео, документ)
router.post('/upload', authenticate, chatUpload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'Файл не загружен' });
        }
        
        let fileUrl = req.file.path.replace(/\\/g, '/').replace('public/', '/');
        let fileType = 'file';
        
        if (req.file.mimetype.startsWith('image/')) fileType = 'image';
        else if (req.file.mimetype.startsWith('video/')) fileType = 'video';
        else if (req.file.mimetype.startsWith('audio/')) fileType = 'audio';
        
        res.json({
            success: true,
            fileUrl,
            fileType,
            fileName: req.file.originalname,
            fileSize: req.file.size
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка загрузки файла' });
    }
});

// Записать аудио-сообщение
router.post('/upload-audio', authenticate, chatUpload.single('audio'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'Аудио не загружено' });
        }
        
        const fileUrl = req.file.path.replace(/\\/g, '/').replace('public/', '/');
        const duration = req.body.duration || 0;
        
        res.json({
            success: true,
            fileUrl,
            duration
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка загрузки аудио' });
    }
});

module.exports = router;