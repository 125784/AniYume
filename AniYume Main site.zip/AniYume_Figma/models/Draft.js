const mongoose = require('mongoose');

const draftSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    title: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    pngFilePath: { 
        type: String, 
        required: true 
    }, 
    dateSaved: {
        type: Date,
        default: Date.now
    },
    isDraft: {
        type: Boolean,
        default: true 
    }
});

module.exports = mongoose.model('Draft', draftSchema, 'drafts');

