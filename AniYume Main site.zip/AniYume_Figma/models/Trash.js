const mongoose = require('mongoose');

const trashSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['canvas', 'other']
  },
  imageUrl: {
    type: String,
    required: true
  },
  deletedAt: {
    type: Date,
    default: Date.now
  },
  animeId: { 
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Recommendation', 
    default: null
  },
  title: { 
    type: String
  },
  author: { 
    type: String
  }
});

module.exports = mongoose.model('Trash', trashSchema);
