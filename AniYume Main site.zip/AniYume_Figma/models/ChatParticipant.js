const mongoose = require('mongoose');

const chatParticipantSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    chatId: { type: String, required: true },
    companionId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    companionName: { type: String, required: true },
    companionAvatar: { type: String, default: '' },
    lastMessage: { type: String, default: '' },
    lastMessageTime: { type: Date, default: Date.now },
    lastMessageSender: { type: String, default: '' },
    unreadCount: { type: Number, default: 0 },
    isDeleted: { type: Boolean, default: false }, // Удалён ли чат у этого пользователя
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

chatParticipantSchema.index({ userId: 1, chatId: 1 });
chatParticipantSchema.index({ userId: 1, isDeleted: 1, updatedAt: -1 });

module.exports = mongoose.model('ChatParticipant', chatParticipantSchema);