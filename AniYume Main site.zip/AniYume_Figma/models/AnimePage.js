const Recommendation = require('./Recommendation'); 

class AnimePage {
    static async getAnimeById(id) {
        try {
            const anime = await Recommendation.findById(id)
                .select('title description year episodes genres type rating seasons studio manga images');
            if (!anime) {
                throw new Error('Аниме не найдено');
            }
            return anime;
        } catch (error) {
            console.error('Ошибка при получении аниме:', error);
            throw error;
        }
    }

    static async getSimilarAnime(id, genres) {
        try {
            const similarAnime = await Recommendation.find({
                _id: { $ne: id },
                genres: { $in: genres } 
            }).limit(5); 
            return similarAnime;
        } catch (error) {
            console.error('Ошибка при получении похожих аниме:', error);
            throw error;
        }
    }
}

module.exports = AnimePage;
