const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema({
    title: String,
    description: String,
    year: Number,
    episodes: Number,
    genres: [String],
    type: String,
    rating: Number,
    seasons: Number,
    studio: String,
    manga: {
        exists: Boolean,
        author: String,
        title: String,
        volumes: Number,
        year: Number
    },
    images: [String]
});

module.exports = mongoose.model('Recommendation', recommendationSchema);
