const bcrypt = require('bcrypt');

async function generateHash() {
    const password = 'admin78';  // Ваш пароль
    const hash = await bcrypt.hash(password, 10);
    console.log('Хэш пароля:', hash);
    console.log('Пароль:', password);
}

generateHash();