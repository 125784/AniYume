const multer = require('multer');
const path = require('path');
const fs = require('fs');

const uploadConfigs = {
    avatar: {
        destination: path.join(__dirname, 'uploads'), 
        fieldname: 'avatar', 
        maxSize: 2 * 1024 * 1024, 
        allowedFileTypes: ['.jpg', '.jpeg', '.png', '.gif'] 
    },
    art: {
        destination: path.join(__dirname, '..', 'public', 'arts'),
        fieldname: 'art', 
        maxSize: 5 * 1024 * 1024, 
        allowedFileTypes: ['.jpg', '.jpeg', '.png', '.gif'] 
    }
};

function createStorage(type) {
    const config = uploadConfigs[type];
    if (!config) {
        throw new Error(`Неизвестный тип загрузки: ${type}`);
    }

    return multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, config.destination);
        },
        filename: function (req, file, cb) {
            const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
            const fileExtension = path.extname(file.originalname);

            if (!config.allowedFileTypes.includes(fileExtension.toLowerCase())) {
                return cb(new Error('Недопустимый тип файла'), false);
            }

            cb(null, config.fieldname + '-' + uniqueSuffix + fileExtension); 
        }
    });
}

function createUploadMiddleware(type) {
    try {
        const storage = createStorage(type);
        const config = uploadConfigs[type];

        const upload = multer({
            storage: storage,
            limits: { fileSize: config.maxSize },
            fileFilter: function (req, file, cb) {
                const fileExtension = path.extname(file.originalname).toLowerCase();
                if (config.allowedFileTypes.includes(fileExtension)) {
                    cb(null, true);
                } else {
                    cb(new Error(`Недопустимый тип файла. Разрешены: ${config.allowedFileTypes.join(', ')}`));
                }
            }
        });

        return upload.single(config.fieldname);

    } catch (error) {
        console.error("Ошибка при создании middleware multer:", error);
        return (req, res, next) => {
            next(error); 
        };
    }
}

const uploadAvatar = createUploadMiddleware('avatar');
const uploadArt = createUploadMiddleware('art');

for (const key in uploadConfigs) {
    const dirPath = uploadConfigs[key].destination;
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });  
    }
}

module.exports = { uploadAvatar, uploadArt };