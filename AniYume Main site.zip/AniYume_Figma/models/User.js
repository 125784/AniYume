const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    role: {
        type: String,
        enum: ['Пользователь', 'Главный администратор', 'Администратор', 'Модератор', 'Контент-менеджер'],
        default: 'Пользователь'
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    password: {
        type: String,
        required: true
    },
    gender: {
        type: String,
        enum: ['male', 'female', 'other'],
        default: 'other'
    },
    date_of_birth: {
        type: Date,
        default: null
    },
    country: {
        type: String,
        default: ''
    },
    language: {
        type: String,
        default: 'en'
    },
    favorite_genres: {
        type: [String],
        default: []
    },
    favorite_anime: {
        type: [String],
        default: []
    },
    terms_agreement: {
        type: Boolean,
        default: false
    },
    newsletter_subscription: {
        type: Boolean,
        default: false
    },
    favorite_character: {
        type: String,
        default: ''
    },
    avatar: {
        type: String,
        default: 'https://i.ibb.co/sJ5Bdp8d/default.jpg'
    },
    profile_description: {
        type: String,
        default: ''
    },
    downloads: {
        type: [String],
        default: []
    },
    watchHistory: {
        type: [{
            animeId: String,
            episode: Number,
            watchedAt: { type: Date, default: Date.now }
        }],
        default: []
    },
    settings: {
        type: {
            theme: { type: String, default: 'light' },
            notifications: { type: Boolean, default: true },
            autoPlay: { type: Boolean, default: true }
        },
        default: {}
    },
    favorites: {
        type: [String],
        default: []
    },
    online: { 
        type: Boolean, 
        default: false 
    },
    socketId: { 
        type: String, 
        default: null 
    },
    inChat: { 
        type: Boolean, 
        default: false 
    },
    isSearchingText: { 
        type: Boolean, 
        default: false 
    },
    isSearchingAudio: { 
        type: Boolean, 
        default: false 
    },
    isSearchingVideo: { 
        type: Boolean, 
        default: false 
    },
    textChatEnabled: { 
        type: Boolean, 
        default: true 
    },
    audioChatEnabled: { 
        type: Boolean, 
        default: true 
    },
    videoChatEnabled: { 
        type: Boolean, 
        default: true 
    }
});

userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) return next();
    try {
        const hashedPassword = await bcrypt.hash(this.password, 10);
        this.password = hashedPassword;
        next();
    } catch (error) {
        next(error);
    }
});

userSchema.methods.comparePassword = async function (candidatePassword) {
    console.log('Введенный пароль:', candidatePassword);
    console.log('Захешированный пароль из базы данных:', this.password);
    const isMatch = await bcrypt.compare(candidatePassword, this.password);
    console.log('Результат сравнения:', isMatch);
    return isMatch;
};

module.exports = mongoose.model('User', userSchema, 'users_download');