const mongoose = require('mongoose');

const artSchema = new mongoose.Schema({
    animeId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Recommendation',
        required: false,
        default: null
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', 
        required: true
    },
    title: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    signature: {
        type: String,
        maxlength: 500
    },
    tag: {
        type: String,
        maxlength: 100
    },
    imageUrl: {
        type: String,
        required: true
    },
    uploadDate: {
        type: Date,
        default: Date.now
    },
    draft: {
        type: Boolean,
        default: false 
    },
    isPublished: {
        type: Boolean,
        default: false
    }
});

module.exports = mongoose.model('Art', artSchema, 'arts');
