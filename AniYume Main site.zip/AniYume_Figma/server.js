const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const router = express.Router();
const session = require('express-session');
const fs = require('fs');
const http = require('http');
const { Server } = require("socket.io");

const { HfInference } = require('@huggingface/inference');
const { ObjectId } = mongoose.Types;

const HF_ACCESS_TOKEN = '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';
const hf = new HfInference(HF_ACCESS_TOKEN);

const app = express();

const server = http.createServer(app);
const io = new Server(server);

app.use(cors());
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.urlencoded({ extended: true }));
const { uploadAvatar, uploadArt } = require('./models/multer-config');
const AnimePage = require('./models/AnimePage');
const Recommendation = require('./models/Recommendation');
const User = require('./models/User');
const Review = require('./models/Review');
const Art = require('./models/Arts');
const Trash = require('./models/Trash');
const Draft = require('./models/Draft');
const BlogPost = require('./models/BlogPost');
const chatRoutes = require('./routes/chat');
const Chat = require('./models/Chat');
const ChatParticipant = require('./models/ChatParticipant');

app.use(express.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/AniYume', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

app.use(session({
    secret: 'jkbdbzVby.yub2006',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 3600000 }
}));

const authenticateUser = (req, res, next) => {
    if (!req.session.user) {
        return res.status(401).json({ message: 'Пользователь не авторизован' });
    }
    next();
};

function isAdmin(req, res, next) {
    if (req.session && req.session.user && 
        (req.session.user.role === "Главный администратор" || req.session.user.role === "Администратор")) {
        return next();
    }
    res.status(403).send('Доступ запрещен. Требуются права администратора.');
}

function sanitizeFilename(filename) {
    return filename.replace(/[^a-zA-Z0-9._-]/g, '_');
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const folder = req.query.folder === 'drafts' ? 'drafts' : 'public/uploads';
        const uploadDir = path.join(__dirname, folder);
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        if (req.query.folder === 'drafts') {
            const sanitizedTitle = sanitizeFilename(req.body.title || 'draft');
            const fileName = `${Date.now()}-${sanitizedTitle}.png`;
            cb(null, fileName);
        } else {
            const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
            cb(null, uniqueSuffix + path.extname(file.originalname));
        }
    }
});

const upload = multer({ storage: storage, limits: { fileSize: 10 * 1024 * 1024 } });

function deleteOldAvatar(userAvatar) {
    if (userAvatar && userAvatar !== 'https://i.ibb.co/sJ5Bdp8d/default.jpg') {
        const oldAvatarPath = path.join(__dirname, userAvatar);
        if (fs.existsSync(oldAvatarPath)) {
            fs.unlinkSync(oldAvatarPath);
        }
    }
}

app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        return res.status(400).json({ message: `Ошибка загрузки файла: ${err.message}` });
    } else if (err) {
        console.error("Глобальная обработка ошибок:", err);
        return res.status(500).json({ message: `Внутренняя ошибка сервера: ${err.message}` });
    }
    next();
});

app.use('/api/chat', chatRoutes);

app.post('/upload-avatar', authenticateUser, (req, res, next) => {
    uploadAvatar(req, res, async (err) => {
        if (err instanceof multer.MulterError) {
            return res.status(400).json({ message: err.message });
        } else if (err) {
            return res.status(400).json({ message: err.message });
        }

        try {
            if (!req.file) {
                return res.status(400).json({ message: 'Пожалуйста, загрузите файл' });
            }

            const absolutePath = req.file.path;
            const relativePath = path.relative(__dirname, absolutePath);
            const userId = req.session.user._id;

            const user = await User.findById(userId).select('avatar');
            if (!user) {
                return res.status(404).json({ message: 'Пользователь не найден' });
            }

            deleteOldAvatar(user.avatar);

            user.avatar = `/${relativePath.replace(/\\/g, '/')}`;
            await user.save();

            res.status(200).json({ 
                message: 'Аватар успешно загружен', 
                avatarPath: user.avatar
            });

        } catch (error) {
            console.error('Ошибка при загрузке аватара:', error);
            res.status(500).json({ message: error.message });
        }
    });
});

app.post('/api/register', uploadAvatar, async (req, res) => {
    try {
        const {
            username,
            email,
            password,
            confirm_password,
            gender,
            date_of_birth,
            country,
            language,
            favorite_genres,
            favorite_anime,
            terms_agreement,
            newsletter_subscription,
            favorite_character,
            profile_description,
            settings
        } = req.body;

        if (password !== confirm_password) {
            return res.status(400).json({ message: 'Пароли не совпадают' });
        }

        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ message: 'Пользователь с таким именем или email уже существует' });
        }

        let avatarUrl = 'https://i.ibb.co/sJ5Bdp8d/default.jpg';
        if (req.file) {
            avatarUrl = req.file.path;
        }

        const newUser = new User({
            username,
            email,
            password,
            gender,
            date_of_birth,
            country,
            language,
            favorite_genres: favorite_genres ? favorite_genres.split(',').map(item => item.trim()) : [],
            favorite_anime: favorite_anime ? favorite_anime.split(',').map(item => item.trim()) : [],
            terms_agreement,
            newsletter_subscription,
            favorite_character,
            avatar: avatarUrl,
            profile_description,
            settings: settings ? JSON.parse(settings) : undefined
        });

        await newUser.save();

        req.session.user = { _id: newUser._id, username: newUser.username, email: newUser.email };

        res.status(201).json({ redirect: '/personal_account' });

    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({ message: 'Имя пользователя или email уже заняты' });
        }
        console.error('Ошибка регистрации:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        console.log('=== ВХОД ПОЛЬЗОВАТЕЛЯ ===');
        console.log('Email:', email);
        console.log('Пароль:', password);

        if (!email || !password) {
            return res.status(400).json({ message: 'Email и пароль обязательны' });
        }

        const user = await User.findOne({ email });
        if (!user) {
            console.log('Пользователь не найден');
            return res.status(400).json({ message: 'Пользователь с таким email не найден' });
        }

        console.log('Найден пользователь:', user.username);
        console.log('Роль из БД:', user.role);
        console.log('Хеш пароля из БД:', user.password);

        const isPasswordValid = await user.comparePassword(password);
        console.log('Пароль валиден:', isPasswordValid);

        if (!isPasswordValid) {
            return res.status(400).json({ message: 'Неверный пароль' });
        }

        req.session.user = { 
            _id: user._id, 
            username: user.username, 
            email: user.email,
            role: user.role
        };
        console.log('Сохранено в сессию:', req.session.user);

        console.log('Отправляем роль клиенту:', user.role);
        res.status(200).json({ 
            redirect: '/personal_account',
            role: user.role
        });

    } catch (error) {
        console.error('Ошибка входа:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/login', (req, res) => {
    if (req.session.userId || req.session.user) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/register', (req, res) => {
    if (req.session.userId || req.session.user) {
        return res.redirect('/');
    }
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.get('/api/user', authenticateUser, async (req, res) => {
    try {
        const user = await User.findById(req.session.user._id).select('-password');
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        res.json(user);

    } catch (error) {
        console.error('Ошибка получения данных пользователя:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/user-avatar/:userId', authenticateUser, async (req, res) => {
    try {
        const userId = req.params.userId;

        const user = await User.findById(userId).select('avatar');
        if (!user) {
            return res.status(404).send('Пользователь не найден');
        }

        if (!user.avatar || user.avatar === 'https://i.ibb.co/sJ5Bdp8d/default.jpg') {
            return res.redirect('https://i.ibb.co/sJ5Bdp8d/default.jpg');
        }

        const avatarPath = path.join(__dirname, user.avatar);
        if (!fs.existsSync(avatarPath)) {
            return res.redirect('https://i.ibb.co/sJ5Bdp8d/default.jpg');
        }

        res.sendFile(avatarPath);

    } catch (error) {
        console.error('Ошибка при получении аватара:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/delete-avatar', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;

        const user = await User.findById(userId).select('avatar');
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        if (user.avatar && user.avatar !== 'https://i.ibb.co/sJ5Bdp8d/default.jpg') {
            const oldAvatarPath = path.join(__dirname, user.avatar);
            if (fs.existsSync(oldAvatarPath)) {
                fs.unlinkSync(oldAvatarPath);
            }
        }

        user.avatar = 'https://i.ibb.co/sJ5Bdp8d/default.jpg';
        await user.save();

        res.status(200).json({ message: 'Аватар успешно удален', avatarPath: user.avatar });

    } catch (error) {
        console.error('Ошибка при удалении аватара:', error);
        res.status(500).json({ message: 'Ошибка сервера при удалении аватара' });
    }
});

app.post('/api/update-profile', uploadAvatar, authenticateUser, async (req, res) => {
    try {
        const { username, email, old_password, new_password, country, language, favorite_genres, favorite_anime, profile_description, settings } = req.body;

        const user = await User.findById(req.session.user._id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        let isPasswordValid = true;
        if (old_password) {
            isPasswordValid = await user.comparePassword(old_password);
            if (!isPasswordValid) {
                return res.status(400).json({ message: 'Старый пароль неверный' });
            }
        }

        if (new_password) {
            user.password = new_password;
        }

        user.username = username || user.username;
        user.email = email || user.email;
        user.country = country || user.country;
        user.language = language || user.language;
        user.favorite_genres = favorite_genres ? favorite_genres.split(',').map(item => item.trim()) : user.favorite_genres;
        user.favorite_anime = favorite_anime ? favorite_anime.split(',').map(item => item.trim()) : user.favorite_anime;
        user.profile_description = profile_description || user.profile_description;

        if (settings) {
            try {
                const parsedSettings = JSON.parse(settings);
                user.settings.theme = parsedSettings.theme || user.settings.theme;
                user.settings.notifications = parsedSettings.notifications !== undefined ? parsedSettings.notifications : user.settings.notifications;
            } catch (error) {
                console.error('Ошибка парсинга настроек:', error);
                return res.status(400).json({ message: 'Неверный формат настроек' });
            }
        }

        if (req.file) {
            user.avatar = req.file.path;
        }

        await user.save();

        req.session.user = { _id: user._id, username: user.username, email: user.email };

        res.status(200).json({ message: 'Данные успешно обновлены' });
    } catch (error) {
        console.error('Ошибка обновления профиля:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

function getRandomBackground(theme) {
    const darkThemeBackgrounds = [
        "https://i.ibb.co/BVqynzFF/body-dark-theme1.jpg",
        "https://i.ibb.co/QvqfnpGP/body-dark-theme.jpg",
        "https://i.ibb.co/s973m5Tp/body-dark-theme2.jpg",
        "https://i.ibb.co/VWHHpHFC/body-dark-theme3.jpg"
    ];

    const lightThemeBackgrounds = [
        "https://i.ibb.co/YBbFNjy3/body-fon.jpg",
        "https://i.ibb.co/sJQsR2xt/body-light-theme1.jpg",
        "https://i.ibb.co/qLkstRQp/body-light-theme.jpg",
        "https://i.ibb.co/60mkh7t8/body-light-theme2.jpg",
        "https://i.ibb.co/JWMGDTY0/body-light-theme3.jpg"
    ];

    let backgrounds;
    if (theme === 'dark') {
        backgrounds = darkThemeBackgrounds;
    } else {
        backgrounds = lightThemeBackgrounds;
    }

    const randomIndex = Math.floor(Math.random() * backgrounds.length);
    return backgrounds[randomIndex];
}

app.get('/personal_account', authenticateUser, async (req, res) => {
    try {
        const user = await User.findById(req.session.user._id);

        if (!user) {
            return res.status(404).send('Пользователь не найден');
        }

        const userTheme = user.settings && user.settings.theme ? user.settings.theme : 'light';
        const backgroundImage = getRandomBackground(userTheme);

        res.render('personal_account', {
            user: user,
            countries: ["Россия", "США", "Германия", "Франция", "Япония", "Китай", "Индия", "Бразилия", "Канада", "Австралия"],
            languages: ["Русский", "Английский", "Немецкий", "Французский", "Японский", "Китайский", "Испанский", "Португальский"],
            theme: userTheme,
            backgroundImage: backgroundImage
        });

    } catch (error) {
        console.error('Ошибка при загрузке личного кабинета:', error);
        res.redirect('/');
    }
});

app.post('/upload-art', uploadArt, async (req, res) => {
    try {
        const { animeId, author, signature, tag, title } = req.body;
        if (!req.file) {
            return res.status(400).json({ message: 'Пожалуйста, загрузите файл' });
        }

        const imageUrl = '/arts/' + req.file.filename;

        const newArt = new Art({
            animeId: animeId,
            userId: req.session.user._id,
            title: title,
            author: author,
            signature: signature,
            tag: tag,
            imageUrl: imageUrl
        });

        await newArt.save();
        req.session.message = {
            type: 'success',
            text: 'Изображение успешно загружено!'
        };
        res.redirect('/personal_account');
    } catch (error) {
        console.error('Ошибка при загрузке арта:', error);
        req.session.message = {
            type: 'danger',
            text: 'Ошибка при загрузке изображения.'
        };
        res.redirect('/personal_account');
    }
});

app.get('/anime/:id', async (req, res) => {
    try {
        const animeId = req.params.id;
        let anime = await AnimePage.getAnimeById(animeId);

        if (!anime.downloadLinks) {
            anime.downloadLinks = {};
        }
        if (!anime.fileSizes) {
            anime.fileSizes = {};
        }

        const similarAnime = await AnimePage.getSimilarAnime(animeId, anime.genres);
        const reviews = await Review.find({ animeId: animeId }).populate('userId', 'username');
        const arts = await Art.find({ animeId: animeId });

        let userTheme = 'light';
        let backgroundImage = getRandomBackground(userTheme);

        if (req.session && req.session.user) {
            const user = await User.findById(req.session.user._id);
            if (user && user.settings && user.settings.theme) {
                userTheme = user.settings.theme;
                backgroundImage = getRandomBackground(userTheme);
            }
        }

        res.render('anime_page', { anime, similarAnime, theme: userTheme, backgroundImage: backgroundImage, reviews: reviews, arts: arts });
    } catch (error) {
        console.error('Ошибка получения аниме:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/arts', async (req, res) => {
    try {
        const searchTerm = req.query.search;
        let arts;

        if (searchTerm) {
            arts = await Art.find({
                $or: [
                    { title: { $regex: searchTerm, $options: 'i' } },
                    { author: { $regex: searchTerm, $options: 'i' } },
                    { tag: { $regex: searchTerm, $options: 'i' } },
                    {
                        animeId: {
                            $in: await Recommendation.find({ title: { $regex: searchTerm, $options: 'i' } }, '_id')
                                .distinct('_id')
                        }
                    }
                ]
            })
                .populate('animeId', 'title');
        } else {
            arts = await Art.find({}).populate('animeId', 'title');
        }

        res.render('arts', { arts: arts, searchTerm: searchTerm });
    } catch (error) {
        console.error('Ошибка при поиске артов:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/api/anime-titles', async (req, res) => {
    try {
        const animeList = await Recommendation.find({}, '_id title');
        const titles = animeList.map(anime => ({
            id: anime._id.toString(),
            title: anime.title
        }));

        console.log('Ответ сервера:', titles);

        res.json(titles);
    } catch (error) {
        console.error('Ошибка при получении названий аниме:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/user-arts', async (req, res) => {
    try {
        if (!req.session || !req.session.user) {
            return res.status(401).json({ message: 'Пользователь не авторизован' });
        }

        const userArts = await Art.find({ userId: req.session.user._id })
            .populate('animeId', 'title')
            .sort({ uploadDate: -1 });

        res.json(userArts);
    } catch (error) {
        console.error('Ошибка при получении артов пользователя:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.delete('/art/:id', async (req, res) => {
    try {
        const artId = req.params.id;

        const art = await Art.findById(artId);
        if (!art) {
            return res.status(404).json({ message: 'Арт не найден' });
        }

        if (art.userId.toString() !== req.session.user._id.toString()) {
            return res.status(403).json({ message: 'У вас нет прав на удаление этого арта' });
        }

        let filePath;
        if (art.isDraft) {
            filePath = path.join(__dirname, 'drafts', art.imageUrl.split('/').pop());
        } else {
            filePath = path.join(__dirname, 'public', 'arts', art.imageUrl.split('/').pop());
        }

        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        } else {
            console.warn(`Файл для арта с ID ${artId} не найден по пути: ${filePath}`);
        }

        await Art.findByIdAndDelete(artId);

        res.json({ message: 'Арт успешно удален' });
    } catch (error) {
        console.error('Ошибка при удалении арта:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.put('/art/:id', uploadArt, async (req, res) => {
    try {
        const artId = req.params.id;
        const { title, author, signature, tag } = req.body;

        const art = await Art.findById(artId);
        if (!art) {
            return res.status(404).json({ message: 'Арт не найден' });
        }

        if (art.userId.toString() !== req.session.user._id.toString()) {
            return res.status(403).json({ message: 'У вас нет прав на редактирование этого арта' });
        }

        art.title = title || art.title;
        art.author = author || art.author;
        art.signature = signature || art.signature;
        art.tag = tag || art.tag;

        if (req.file) {
            const oldFilePath = path.join(__dirname, 'public', 'arts', art.imageUrl.split('/').pop());
            if (fs.existsSync(oldFilePath)) {
                fs.unlinkSync(oldFilePath);
            }
            art.imageUrl = '/arts/' + req.file.filename;
        }

        await art.save();

        res.json({ message: 'Арт успешно обновлен', art });
    } catch (error) {
        console.error('Ошибка при редактировании арта:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/art/:id', async (req, res) => {
    try {
        const art = await Art.findById(req.params.id);
        if (!art) {
            return res.status(404).json({ message: 'Арт не найден' });
        }
        res.json(art);
    } catch (error) {
        console.error('Ошибка при получении арта:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/drawing_board', (req, res) => {
    try {
        const { canvasData } = req.query;
        res.render('drawing_board', { canvasData });
    } catch (error) {
        console.error('Ошибка при рендеринге drawing_board:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/api/drafts/save', upload.single('canvasFile'), async (req, res) => {
    try {
        const { userId, title, author } = req.body;

        if (!req.file) {
            return res.status(400).json({ message: "Отсутствует PNG файл" });
        }

        const fileName = req.file.filename;
        const pngFilePath = '/drafts/' + fileName;

        const newDraft = new Draft({
            userId,
            title,
            author,
            pngFilePath: pngFilePath,
            dateSaved: Date.now(),
        });

        const savedDraft = await newDraft.save();
        console.log("Черновик успешно сохранен:", savedDraft);

    } catch (error) {
        console.error("Ошибка при сохранении черновика:", error);
        res.status(500).json({ message: "Ошибка при сохранении черновика", error: error.message });
    }
});

app.get('/api/drafts', authenticateUser, async (req, res) => {
    try {
        const { userId } = req.query;
        const query = userId ? { userId, isDraft: true } : { userId: req.session.user._id, isDraft: true };

        const drafts = await Draft.find(query)
            .sort({ dateSaved: -1 });

        res.json(drafts);
    } catch (error) {
        console.error('Ошибка при получении черновиков:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/drafts', authenticateUser, async (req, res) => {
    try {
        const drafts = await Draft.find({ userId: req.session.user._id, isDraft: true }).sort({ dateSaved: -1 });
        res.render('drafts', { drafts: drafts });
    } catch (error) {
        console.error('Ошибка при получении черновиков:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.delete('/drafts/:id', async (req, res) => {
    try {
        const draft = await Draft.findById(req.params.id);
        if (!draft) {
            return res.status(404).json({ message: 'Черновик не найден' });
        }

        const pngFilePath = path.join(__dirname, draft.pngFilePath);
        if (fs.existsSync(pngFilePath)) {
            fs.unlinkSync(pngFilePath);
        }

        await Draft.findByIdAndDelete(req.params.id);

        res.json({ message: 'Черновик удален' });
    } catch (error) {
        console.error('Ошибка при удалении черновика:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/api/drafts/:id', authenticateUser, async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ message: 'Неверный ID черновика' });
        }

        const draft = await Draft.findOne({ _id: req.params.id, userId: req.session.user._id, isDraft: true });
        if (!draft) {
            return res.status(404).json({ message: 'Черновик не найден' });
        }

        res.json({
            ...draft.toObject(),
            pngFilePath: draft.pngFilePath,
        });

    } catch (error) {
        console.error('Ошибка при получении черновика:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/drafts/:id/edit', authenticateUser, async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).send('Неверный ID черновика');
        }

        const draft = await Draft.findOne({ _id: req.params.id, userId: req.session.user._id });
        if (!draft) {
            return res.status(404).send('Черновик не найден');
        }

        res.redirect(`/drawing_board?draftId=${req.params.id}`);

    } catch (error) {
        console.error('Ошибка при получении черновика:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/publish-draft', authenticateUser, async (req, res) => {
    try {
        const { draftId, animeId, title, author, signature, tag } = req.body;

        const draft = await Draft.findById(draftId);
        if (!draft) {
            return res.status(404).json({ message: 'Черновик не найден' });
        }

        const newArt = new Art({
            animeId: animeId || null,
            userId: req.session.user._id,
            title: title || draft.title,
            author: author || draft.author,
            signature: signature || '',
            tag: tag || '',
            imageUrl: draft.pngFilePath,
            isPublished: true
        });

        await newArt.save();
        await Draft.findByIdAndDelete(draftId);

        req.session.message = {
            type: 'success',
            text: 'Арт успешно опубликован!'
        };

        res.redirect('/personal_account');
    } catch (error) {
        console.error('Ошибка при публикации черновика:', error);
        req.session.message = {
            type: 'danger',
            text: 'Ошибка при публикации черновика.'
        };
        res.redirect('/drafts');
    }
});

app.post('/publish-canvas', upload.single('canvasFile'), async (req, res) => {
    try {
        const { animeId, author, signature, tag, title } = req.body;

        if (!animeId || !author || !title || !req.file) {
            return res.status(400).json({ message: 'Заполните все обязательные поля.' });
        }

        const artsDir = path.join(__dirname, 'public', 'arts');
        if (!fs.existsSync(artsDir)) {
            fs.mkdirSync(artsDir, { recursive: true });
        }

        const fileName = `art-${Date.now()}.png`;
        const filePath = path.join(artsDir, fileName);

        fs.renameSync(req.file.path, filePath);

        const newArt = new Art({
            animeId: animeId,
            userId: req.session.user._id,
            title: title,
            author: author,
            signature: signature,
            tag: tag,
            imageUrl: `/arts/${fileName}`,
        });

        await newArt.save();

        res.status(200).json({ message: 'Арт успешно опубликован!' });
    } catch (error) {
        console.error('Ошибка при публикации арта:', error);
        res.status(500).json({ message: 'Ошибка сервера.' });
    }
});

app.post('/send-to-trash', upload.single('image'), async (req, res) => {
    if (!req.session || !req.session.user || !req.session.user._id) {
        return res.status(401).json({ message: 'Пользователь не авторизован' });
    }

    try {
        const { title, author, animeId } = req.body;
        console.log("Данные из запроса:", req.body);
        console.log("Файл:", req.file);

        const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

        if (!imageUrl) {
            return res.status(400).json({ message: 'Изображение не было загружено' });
        }

        const newTrashItem = new Trash({
            userId: req.session.user._id,
            type: 'canvas',
            imageUrl: imageUrl,
            deletedAt: new Date(),
            title: title,
            author: author,
            animeId: animeId
        });

        await newTrashItem.save();
        res.status(200).json({ message: 'Холст отправлен в корзину и сохранен в базе данных!' });

    } catch (error) {
        console.error('Ошибка при сохранении в корзину:', error);
        res.status(500).json({ message: 'Ошибка сервера при сохранении в корзину', error: error.message });
    }
});

app.get('/trash-bin', async (req, res) => {
    if (!req.session || !req.session.user || !req.session.user._id) {
        return res.status(401).json({ message: 'Пользователь не авторизован' });
    }
    try {
        const trashItems = await Trash.find({ userId: req.session.user._id });
        res.json(trashItems);
    } catch (error) {
        console.error('Ошибка при получении элементов корзины:', error);
        res.status(500).json({ message: 'Ошибка сервера при получении элементов корзины' });
    }
});

app.post('/restore-from-trash/:id', async (req, res) => {
  if (!req.session || !req.session.user || !req.session.user._id) {
    return res.status(401).json({ message: 'Пользователь не авторизован' });
  }

  try {
    const trashItem = await Trash.findById(req.params.id);

    if (!trashItem) {
      return res.status(404).json({ message: 'Элемент не найден в корзине' });
    }

    if (trashItem.userId.toString() !== req.session.user._id.toString()) {
      return res.status(403).json({ message: 'Нет прав на восстановление этого элемента' });
    }

    console.log('trashItem:', trashItem);

    if (!trashItem.imageUrl) {
      return res.status(400).json({ message: 'imageUrl отсутствует в элементе корзины' });
    }

    await Trash.findByIdAndDelete(req.params.id);

    res.json({
      message: 'Элемент восстановлен на холст!',
      imageUrl: trashItem.imageUrl,
    });
  } catch (error) {
    console.error('Ошибка при восстановлении элемента из корзины:', error);
    res.status(500).json({ message: 'Ошибка сервера при восстановлении элемента из корзины' });
  }
});

app.delete('/delete-from-trash/:id', async (req, res) => {
  if (!req.session || !req.session.user || !req.session.user._id) {
    return res.status(401).json({ message: 'Пользователь не авторизован' });
  }

  try {
    const trashItem = await Trash.findById(req.params.id);

    if (!trashItem) {
      return res.status(404).json({ message: 'Элемент не найден в корзине' });
    }

    if (trashItem.userId.toString() !== req.session.user._id.toString()) {
      return res.status(403).json({ message: 'Нет прав на удаление этого элемента' });
    }

    await Trash.findByIdAndDelete(req.params.id);
    res.json({ message: 'Элемент удален из корзины!' });
  } catch (error) {
    console.error('Ошибка при удалении элемента из корзины:', error);
    res.status(500).json({ message: 'Ошибка сервера при удалении элемента из корзины' });
  }
});

app.delete('/clear-trash', async (req, res) => {
    if (!req.session || !req.session.user || !req.session.user._id) {
        return res.status(401).json({ message: 'Пользователь не авторизован' });
    }

    try {
        await Trash.deleteMany({ userId: req.session.user._id });
        res.json({ message: 'Корзина очищена!' });
    } catch (error) {
        console.error('Ошибка при очистке корзины:', error);
        res.status(500).json({ message: 'Ошибка сервера при очистке корзины' });
    }
});

app.post('/api/add-review', authenticateUser, async (req, res) => {
    try {
        const { animeId, text } = req.body;
        const userId = req.session.user._id;

        const newReview = new Review({
            userId: userId,
            animeId: animeId,
            text: text
        });

        await newReview.save();

        res.status(201).json({ message: 'Отзыв успешно добавлен' });
    } catch (error) {
        console.error('Ошибка при добавлении отзыва:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.post('/api/update-theme', authenticateUser, async (req, res) => {
    try {
        const { theme } = req.body;

        const user = await User.findById(req.session.user._id);

        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        user.settings.theme = theme;
        await user.save();

        res.status(200).json({ message: 'Тема успешно обновлена' });

    } catch (error) {
        console.error('Ошибка при обновлении темы:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Ошибка при выходе из аккаунта:', err);
            return res.status(500).send('Ошибка сервера');
        }
        res.redirect('/');
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Ошибка при выходе из аккаунта:', err);
            return res.status(500).send('Ошибка сервера');
        }
        res.redirect('/');
    });
});

app.delete('/api/delete-account', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;

        await User.findByIdAndDelete(userId);

        req.session.destroy((err) => {
            if (err) {
                console.error('Ошибка при удалении сессии:', err);
                return res.status(500).json({ message: 'Ошибка сервера при удалении сессии' });
            }
            res.status(200).json({ message: 'Аккаунт успешно удален', redirect: '/' });
        });

    } catch (error) {
        console.error('Ошибка при удалении аккаунта:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.post('/api/add-to-favorites', authenticateUser, async (req, res) => {
    try {
        const { animeTitle } = req.body;
        const userId = req.session.user._id;

        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }
        if (user.favorite_anime.includes(animeTitle)) {
           return res.status(400).json({ message: 'Аниме уже в избранном' });
        }
        user.favorite_anime.push(animeTitle);

        await user.save();

        res.status(200).json({ message: 'Аниме добавлено в избранное' });

    } catch (error) {
        console.error('Ошибка при добавлении в избранное:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/api/favorites', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;
        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        res.status(200).json({ favorites: user.favorite_anime });

    } catch (error) {
        console.error('Ошибка при получении избранного:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.delete('/api/remove-from-favorites/:animeTitle', authenticateUser, async (req, res) => {
    try {
        const animeTitle = req.params.animeTitle;
        const userId = req.session.user._id;

        const user = await User.findById(userId);

        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        const animeIndex = user.favorite_anime.indexOf(animeTitle);

        if (animeIndex === -1) {
            return res.status(404).json({ message: 'Аниме не найдено в избранном' });
        }

        user.favorite_anime.splice(animeIndex, 1);

        await user.save();

        res.status(200).json({ message: 'Аниме удалено из избранного' });

    } catch (error) {
        console.error('Ошибка при удалении из избранного:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/api/recommendations', async (req, res) => {
    try {
        const recommendations = await Recommendation.find();
        res.json(recommendations);
    } catch (err) {
        res.status(500).json({ message: 'Server error' });
    }
});

app.get('/api/similar-anime/:animeId', async (req, res) => {
    try {
        const animeId = req.params.animeId;

        const anime = await Recommendation.findById(animeId);
        if (!anime) {
            return res.status(404).json({ message: 'Anime not found' });
        }

        const similarAnime = await Recommendation.find({
            genres: { $in: anime.genres },
            _id: { $ne: animeId }
        }).limit(5);

        if (similarAnime.length === 0) {
            return res.json([]);
        }

        res.json(similarAnime);
    } catch (error) {
        console.error('Error fetching similar anime:', error);
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/api/watch-history', authenticateUser, async (req, res) => {
    try {
        const { animeId, episode } = req.body;

        const user = await User.findById(req.user._id);
        if (!user) {
            return res.status(404).json({ message: 'Пользователь не найден' });
        }

        user.watchHistory.push({ animeId, episode });
        await user.save();

        res.json({ message: 'История просмотров обновлена' });
    } catch (error) {
        console.error('Ошибка обновления истории просмотров:', error);
        res.status(500).json({ message: 'Ошибка сервера' });
    }
});

app.get('/genres/:genre', async (req, res) => {
    try {
        let genre = req.params.genre;
        const searchTerm = req.query.searchTerm;
        
        let englishGenre = genre;
        if (reverseGenreTranslations[genre]) {
            englishGenre = reverseGenreTranslations[genre];
        }
        
        let findOptions = { genres: englishGenre };
        
        if (searchTerm) {
            findOptions.title = { $regex: searchTerm, $options: 'i' };
        }
        
        const animeList = await Recommendation.find(findOptions);
        
        const displayGenre = genreTranslations[englishGenre] || englishGenre;
        
        res.render('genres_anime', { 
            genre: displayGenre, 
            animeList: animeList, 
            searchTerm: searchTerm 
        });
    } catch (err) {
        console.error('Error fetching anime by genre:', err);
        res.status(500).send('Server error');
    }
});

app.get('/api/random-anime-home', async (req, res) => {
    try {
        const allAnime = await Recommendation.find({});
        const shuffled = allAnime.sort(() => 0.5 - Math.random());
        const randomAnime = shuffled.slice(0, 4);
        res.json({ success: true, anime: randomAnime });
    } catch (err) {
        console.error('Ошибка при получении рандомных аниме:', err);
        res.status(500).json({ success: false, message: err.message });
    }
});

app.get('/chat_ai', (req, res) => {
    const user = req.user || null;
    const initialMessages = req.messages || [];
    res.render('chat_ai', {
        messages: initialMessages,
        user: user
    });
});

app.post('/api/chat_ai', async (req, res) => {
  try {
    const userMessage = req.body.message;

    const result = await hf.textGeneration({
        model: 'mistralai/Mistral-7B-Instruct-v0.1',
        inputs: userMessage,
    });
    console.log('Hugging Face API Response:', result);
    const botResponse = result.generated_text;
    res.json({ response: botResponse });

  } catch (error) {
    console.error('Ошибка при вызове Hugging Face API:', error);
    res.status(500).json({ response: 'Ошибка при обработке запроса к ИИ.' });
  }
});

app.get('/chats', authenticateUser, (req, res) => {
    res.render('chats');
});

app.get('/text_random_chat', authenticateUser, (req, res) => {
    res.render('text_random_chat', { user: req.session.user }); 
});

app.get('/audio_random_chat', authenticateUser, (req, res) => {
    res.render('audio_random_chat', { user: req.session.user });
});
app.get('/video_random_chat', authenticateUser, (req, res) => {
    res.render('video_random_chat', { user: req.session.user });
});

io.on('connection', (socket) => {
    console.log('User connected', socket.id);

    let userId = null;

    const notifyAndDisconnectCompanion = async (socket, companionSid) => {
        if (!companionSid) return;

        console.log(`Уведомляем собеседника ${companionSid} об отключении пользователя ${socket.id}`);

        io.to(companionSid).emit('companionDisconnected');

        const companionSocket = io.sockets.sockets.get(companionSid);
        if (companionSocket) {
            companionSocket.companionId = null;
        }

        socket.companionId = null;

        try {
            await User.findOneAndUpdate({socketId: companionSid}, {inChat: false}, {new: true});
            await User.findOneAndUpdate({socketId: socket.id}, {inChat: false}, {new: true});
        } catch (e) {
            console.error("Ошибка обновления базы:", e);
        }
    };

    socket.on('user connected', async (uid) => {
        userId = uid;
        try {
            await User.findByIdAndUpdate(userId, {
                online: true,
                socketId: socket.id,
                inChat: false
            }, {new: true});
            console.log(`User ${userId} status updated in DB`);
        } catch (err) {
            console.error("Error in user connected:", err);
        }
    });

    socket.on('disconnect', async () => {
        console.log('User disconnected', socket.id);
        try {
            if (socket.companionId) {
                await notifyAndDisconnectCompanion(socket, socket.companionId);
            }
            if (userId) {
                await User.findByIdAndUpdate(userId, {online: false, socketId: null, inChat: false}, {new: true});
            }
        } catch (e) {
            console.error("Ошибка при дисконнекте ", e);
        }
    });

    async function findRandomAvailableUserForText(currentUserId) {
        try {
            const potentialUsers = await User.find({
                _id: { $ne: new ObjectId(currentUserId) },
                online: true,
                inChat: false,
                textChatEnabled: true,
                isSearchingText: true
            });

            const availableUsers = potentialUsers.filter(u => {
                const s = io.sockets.sockets.get(u.socketId);
                return s && s.isSearchingText === true;
            });

            return availableUsers.length > 0 ? availableUsers[Math.floor(Math.random() * availableUsers.length)] : null;
        } catch (err) {
            console.error("Ошибка при поиске собеседника для ТЕКСТА:", err);
            return null;
        }
    }

    socket.isSearchingText = false;

    socket.on('requestRandomTextChat', async () => {
        if (!userId) return;

        console.log(`[Текст] Пользователь ${userId} начал поиск`);
        socket.isSearchingText = true;
        
        await User.findByIdAndUpdate(userId, { isSearchingText: true });

        try {
            const currentUser = await User.findById(userId);
            const randomUser = await findRandomAvailableUserForText(userId);

            if (randomUser) {
                const recipientSocket = io.sockets.sockets.get(randomUser.socketId);
                console.log(`[Текст] Найден потенциальный собеседник: ${randomUser.username}, searching: ${recipientSocket?.isSearchingText}`);

                if (recipientSocket && recipientSocket.isSearchingText) {
                    console.log(`[Текст] Собеседник подтверждён! Соединяем ${currentUser.username} и ${randomUser.username}`);

                    socket.isSearchingText = false;
                    recipientSocket.isSearchingText = false;
                    
                    await User.findByIdAndUpdate(userId, { isSearchingText: false, inChat: true });
                    await User.findByIdAndUpdate(randomUser._id, { isSearchingText: false, inChat: true });

                    socket.companionId = recipientSocket.id;
                    recipientSocket.companionId = socket.id;

                    socket.emit('textChatMatchFound', {
                        companionName: randomUser.username,
                        socketId: recipientSocket.id
                    });

                    recipientSocket.emit('textChatMatchFound', {
                        companionName: currentUser.username,
                        socketId: socket.id
                    });
                } else {
                    socket.emit('textChatMatchNotFound');
                }
            } else {
                console.log(`[Текст] Собеседник не найден`);
                socket.emit('textChatMatchNotFound');
            }
        } catch (e) {
            console.error("Ошибка поиска:", e);
            socket.emit('textChatMatchNotFound');
        }
    });

    socket.on('leaveTextChat', async () => {
        console.log(`[Текст] Пользователь ${userId} покинул чат`);
        socket.isSearchingText = false;
        
        await User.findByIdAndUpdate(userId, { isSearchingText: false, inChat: false });
        
        if (socket.companionId) {
            const companionSocket = io.sockets.sockets.get(socket.companionId);
            if (companionSocket) {
                companionSocket.emit('companionDisconnected');
                companionSocket.companionId = null;
                await User.findByIdAndUpdate(companionSocket.userId, { inChat: false });
            }
            socket.companionId = null;
        }
    });

    socket.on('message', (data) => {
        console.log(`[Текст] Сообщение от ${userId} к ${data.toSocketId}: ${data.text}`);
        if (data.toSocketId) {
            io.to(data.toSocketId).emit('message', {
                text: data.text,
                from: socket.id
            });
        }
    });

    async function findRandomAvailableUserForAudio(currentUserId) {
        try {
            const potentialUsers = await User.find({
                _id: { $ne: new ObjectId(currentUserId) },
                online: true,
                inChat: false,
                audioChatEnabled: true,
                isSearchingAudio: true
            });

            const availableUsers = potentialUsers.filter(u => {
                const s = io.sockets.sockets.get(u.socketId);
                return s && s.isSearchingAudio === true;
            });

            return availableUsers.length > 0 ? availableUsers[Math.floor(Math.random() * availableUsers.length)] : null;
        } catch (err) {
            console.error("Ошибка при поиске собеседника для АУДИО:", err);
            return null;
        }
    }

    socket.on('audioSignal', (data) => {
        if (data.target) {
            io.to(data.target).emit('audioSignal', {
                signal: data.signal,
                from: socket.id
            });
        }
    });

    socket.isSearchingAudio = false;

    socket.on('requestRandomAudioChat', async () => {
        if (!userId) return;

        console.log(`[Аудио] Пользователь ${userId} начал поиск`);
        socket.isSearchingAudio = true;
        await User.findByIdAndUpdate(userId, { isSearchingAudio: true });

        try {
            const currentUser = await User.findById(userId);
            const randomUser = await findRandomAvailableUserForAudio(userId);

            if (randomUser) {
                const recipientSocket = io.sockets.sockets.get(randomUser.socketId);

                if (recipientSocket && recipientSocket.isSearchingAudio) {
                    console.log(`[Аудио] Соединяем ${currentUser.username} и ${randomUser.username}`);

                    socket.isSearchingAudio = false;
                    recipientSocket.isSearchingAudio = false;

                    socket.companionId = recipientSocket.id;
                    recipientSocket.companionId = socket.id;

                    await User.findByIdAndUpdate(userId, { isSearchingAudio: false, inChat: true });
                    await User.findByIdAndUpdate(randomUser._id, { isSearchingAudio: false, inChat: true });

                    socket.emit('audioChatMatchFound', {
                        companionName: randomUser.username,
                        socketId: recipientSocket.id
                    });

                    recipientSocket.emit('audioChatMatchFound', {
                        companionName: currentUser.username,
                        socketId: socket.id
                    });
                } else {
                    socket.emit('audioChatMatchNotFound');
                }
            } else {
                socket.emit('audioChatMatchNotFound');
            }
        } catch (e) {
            console.error("Ошибка поиска:", e);
            socket.emit('audioChatMatchNotFound');
        }
    });

    socket.on('leaveAudioChat', async () => {
        console.log(`[Аудио] Пользователь ${userId} покинул чат`);
        socket.isSearchingAudio = false;
        await User.findByIdAndUpdate(userId, { isSearchingAudio: false, inChat: false });
        
        if (socket.companionId) {
            const companionSocket = io.sockets.sockets.get(socket.companionId);
            if (companionSocket) {
                companionSocket.emit('companionDisconnected');
                companionSocket.companionId = null;
                await User.findByIdAndUpdate(companionSocket.userId, { inChat: false });
            }
            socket.companionId = null;
        }
    });

    async function findRandomAvailableUserForVideo(currentUserId) {
        try {
            const potentialUsers = await User.find({
                _id: { $ne: new ObjectId(currentUserId) },
                online: true,
                inChat: false,
                videoChatEnabled: true,
                isSearchingVideo: true
            });

            const availableUsers = potentialUsers.filter(u => {
                const s = io.sockets.sockets.get(u.socketId);
                return s && s.isSearchingVideo === true;
            });

            return availableUsers.length > 0 ? availableUsers[Math.floor(Math.random() * availableUsers.length)] : null;
        } catch (err) {
            console.error("Ошибка при поиске собеседника для ВИДЕО:", err);
            return null;
        }
    }

    socket.on('videoSignal', (data) => {
        if (data.target) {
            io.to(data.target).emit('videoSignal', {
                signal: data.signal,
                from: socket.id
            });
        }
    });

    socket.isSearchingVideo = false;

    socket.on('requestRandomVideoChat', async () => {
        if (!userId) return;

        console.log(`[Видео] Пользователь ${userId} начал поиск`);
        socket.isSearchingVideo = true;
        await User.findByIdAndUpdate(userId, { isSearchingVideo: true });

        try {
            const currentUser = await User.findById(userId);
            const randomUser = await findRandomAvailableUserForVideo(userId);

            if (randomUser) {
                const recipientSocket = io.sockets.sockets.get(randomUser.socketId);

                if (recipientSocket && recipientSocket.isSearchingVideo) {
                    console.log(`[Видео] Соединяем ${currentUser.username} и ${randomUser.username}`);

                    socket.isSearchingVideo = false;
                    recipientSocket.isSearchingVideo = false;

                    socket.companionId = recipientSocket.id;
                    recipientSocket.companionId = socket.id;

                    await User.findByIdAndUpdate(userId, { isSearchingVideo: false, inChat: true });
                    await User.findByIdAndUpdate(randomUser._id, { isSearchingVideo: false, inChat: true });

                    socket.emit('videoChatMatchFound', {
                        companionName: randomUser.username,
                        socketId: recipientSocket.id
                    });

                    recipientSocket.emit('videoChatMatchFound', {
                        companionName: currentUser.username,
                        socketId: socket.id
                    });
                } else {
                    socket.emit('videoChatMatchNotFound');
                }
            } else {
                console.log(`[Видео] Собеседник не найден`);
                socket.emit('videoChatMatchNotFound');
            }
        } catch (e) {
            console.error("Ошибка поиска:", e);
            socket.emit('videoChatMatchNotFound');
        }
    });

    socket.on('leaveVideoChat', async () => {
        console.log(`[Видео] Пользователь ${userId} покинул чат`);
        socket.isSearchingVideo = false;
        await User.findByIdAndUpdate(userId, { isSearchingVideo: false, inChat: false });
        
        if (socket.companionId) {
            const companionSocket = io.sockets.sockets.get(socket.companionId);
            if (companionSocket) {
                companionSocket.emit('companionDisconnected');
                companionSocket.companionId = null;
                await User.findByIdAndUpdate(companionSocket.userId, { inChat: false });
            }
            socket.companionId = null;
        }
    });
    
    function getFileTypeName(type) {
        switch(type) {
            case 'audio': return 'Аудиосообщение';
            case 'image': return 'Изображение';
            case 'video': return 'Видео';
            default: return 'Файл';
        }
    }
    
    socket.on('join-chat', async (chatId) => {
        if (!chatId) return;
        socket.join(`chat_${chatId}`);
        console.log(`[Чат] ${userId} присоединился к комнате ${chatId}`);
    });
    
    socket.on('leave-chat', (chatId) => {
        if (!chatId) return;
        socket.leave(`chat_${chatId}`);
        console.log(`[Чат] ${userId} покинул комнату ${chatId}`);
    });
    
    socket.on('send-message', async (data) => {
        console.log(`[Чат] Получено сообщение от ${userId}:`, data);
        
        try {
            const { chatId, message, type, fileName, fileSize, duration } = data;
            
            if (!chatId || !message) {
                console.log('[Чат] Нет chatId или message');
                return;
            }
            
            const currentUser = await User.findById(userId);
            if (!currentUser) {
                console.log('[Чат] Пользователь не найден');
                return;
            }
            
            const newMessage = {
                senderId: userId,
                senderName: currentUser.username,
                type: type || 'text',
                content: message,
                fileName: fileName || '',
                fileSize: fileSize || 0,
                duration: duration || 0,
                read: false,
                createdAt: new Date()
            };
            
            const chat = await Chat.findOne({ chatId });
            if (!chat) {
                console.log('[Чат] Чат не найден:', chatId);
                return;
            }
            
            chat.messages.push(newMessage);
            chat.lastMessage = type === 'text' ? message : `[${getFileTypeName(type)}]`;
            chat.lastMessageTime = new Date();
            chat.lastMessageSender = currentUser.username;
            chat.updatedAt = new Date();
            await chat.save();
            
            console.log('[Чат] Сообщение сохранено, всего сообщений:', chat.messages.length);
            
            const participants = await ChatParticipant.find({ chatId });
            for (const participant of participants) {
                const isCurrentUser = participant.userId.toString() === userId;
                await ChatParticipant.updateOne(
                    { _id: participant._id },
                    {
                        $set: {
                            lastMessage: type === 'text' ? message : `[${getFileTypeName(type)}]`,
                            lastMessageTime: new Date(),
                            lastMessageSender: currentUser.username,
                            updatedAt: new Date()
                        },
                        $inc: { unreadCount: isCurrentUser ? 0 : 1 }
                    }
                );
            }
            
            io.to(`chat_${chatId}`).emit('new-message', newMessage);
            console.log(`[Чат] Сообщение отправлено в комнату chat_${chatId}`);
            
            for (const participant of participants) {
                const updatedChat = await ChatParticipant.findOne({ 
                    userId: participant.userId, 
                    chatId 
                });
                io.to(participant.userId.toString()).emit('chat-list-update', updatedChat);
            }
            
        } catch (err) {
            console.error('Ошибка отправки сообщения:', err);
            socket.emit('message-error', { error: 'Не удалось отправить сообщение' });
        }
    });
    
    socket.on('typing-start', (chatId) => {
        if (chatId) {
            socket.to(`chat_${chatId}`).emit('user-typing', { userId, isTyping: true });
        }
    });
    
    socket.on('typing-stop', (chatId) => {
        if (chatId) {
            socket.to(`chat_${chatId}`).emit('user-typing', { userId, isTyping: false });
        }
    });
    
    socket.on('mark-read', async (chatId) => {
        try {
            await Chat.updateOne(
                { chatId, 'messages.senderId': { $ne: userId } },
                { $set: { 'messages.$[].read': true, 'messages.$[].readAt': new Date() } }
            );
            await ChatParticipant.updateOne(
                { userId, chatId },
                { $set: { unreadCount: 0 } }
            );
            io.to(`chat_${chatId}`).emit('messages-read', { userId });
        } catch (err) {
            console.error('Ошибка отметки прочитано:', err);
        }
    });
    
    socket.on('audio-call-signal', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('audio-call-signal', {
                signal: data.signal,
                from: socket.id
            });
        }
    });
    
    socket.on('audio-call-ended', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('audio-call-ended');
        }
    });
    
    socket.on('audio-call-rejected', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('audio-call-rejected');
        }
    });
    
    socket.on('request-audio-call', async (data) => {
        const { targetUserId, targetSocketId, offer } = data;
        console.log(`[Аудио-звонок] Пользователь ${userId} звонит ${targetUserId}`);
        const caller = await User.findById(userId);
        if (!caller) return;
        const targetSocket = io.sockets.sockets.get(targetSocketId);
        if (targetSocket) {
            targetSocket.emit('incoming-audio-call', {
                from: socket.id,
                fromUserId: userId,
                fromName: caller.username,
                offer: offer
            });
        } else {
            socket.emit('call-error', { message: 'Пользователь не в сети' });
        }
    });
    
    socket.on('audio-call-cancelled', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('audio-call-cancelled');
        }
    });
    
    socket.on('video-call-signal', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('video-call-signal', {
                signal: data.signal,
                from: socket.id,
                fromUserId: userId
            });
        }
    });

    socket.on('video-call-ended', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('video-call-ended');
        }
    });

    socket.on('video-call-rejected', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('video-call-rejected');
        }
    });

    socket.on('video-call-cancelled', (data) => {
        const targetSocket = io.sockets.sockets.get(data.target);
        if (targetSocket) {
            targetSocket.emit('video-call-cancelled');
        }
    });

    socket.on('request-video-call', async (data) => {
        const { targetUserId, targetSocketId, offer } = data;
        console.log(`[Видео-звонок] Пользователь ${userId} звонит ${targetUserId}`);
        const caller = await User.findById(userId);
        if (!caller) return;
        const targetSocket = io.sockets.sockets.get(targetSocketId);
        if (targetSocket) {
            targetSocket.emit('incoming-video-call', {
                from: socket.id,
                fromUserId: userId,
                fromName: caller.username,
                offer: offer
            });
        } else {
            socket.emit('call-error', { message: 'Пользователь не в сети' });
        }
    });
    
    socket.on('delete-message', async (data) => {
        try {
            const { chatId, messageId } = data;
            const currentUserId = userId;
            
            console.log(`[Чат] Пользователь ${currentUserId} удаляет сообщение ${messageId} в чате ${chatId}`);
            
            const chat = await Chat.findOne({ chatId });
            if (!chat) {
                console.log('[Чат] Чат не найден');
                return;
            }
            
            const message = chat.messages.id(messageId);
            if (!message) {
                console.log('[Чат] Сообщение не найдено');
                return;
            }
            
            if (!message.deletedFor.includes(currentUserId)) {
                message.deletedFor.push(currentUserId);
            }
            
            const participants = chat.participants.map(p => p.toString());
            const deletedByAll = participants.every(p => message.deletedFor.includes(p));
            
            if (deletedByAll) {
                chat.messages.pull({ _id: messageId });
                console.log('[Чат] Сообщение полностью удалено из БД');
            }
            
            await chat.save();
            
            io.to(`chat_${chatId}`).emit('message-deleted', {
                messageId: messageId,
                deletedBy: currentUserId
            });
            
            if (chat.messages.length > 0) {
                const lastMsg = chat.messages[chat.messages.length - 1];
                chat.lastMessage = lastMsg.type === 'text' ? lastMsg.content : `[${getFileTypeName(lastMsg.type)}]`;
                chat.lastMessageTime = lastMsg.createdAt;
                chat.lastMessageSender = lastMsg.senderName;
            } else {
                chat.lastMessage = 'Нет сообщений';
                chat.lastMessageTime = new Date();
                chat.lastMessageSender = '';
            }
            await chat.save();
            
            const participantsList = await ChatParticipant.find({ chatId });
            for (const participant of participantsList) {
                const updatedChat = await ChatParticipant.findOne({ 
                    userId: participant.userId, 
                    chatId 
                });
                io.to(participant.userId.toString()).emit('chat-list-update', updatedChat);
            }
            
        } catch (err) {
            console.error('Ошибка удаления сообщения:', err);
            socket.emit('message-error', { error: 'Не удалось удалить сообщение' });
        }
    });
    
});

app.get('/api/chat/list', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;
        console.log('Запрос списка чатов для пользователя:', userId);
        
        const participants = await ChatParticipant.find({ userId: userId });
        console.log('Найдено участников:', participants.length);
        
        const chatList = await Promise.all(participants.map(async (participant) => {
            const chat = await Chat.findOne({ chatId: participant.chatId });
            if (!chat) {
                console.log('Чат не найден:', participant.chatId);
                return null;
            }
            
            const companionId = chat.participants.find(id => id.toString() !== userId.toString());
            if (!companionId) {
                console.log('Собеседник не найден в чате:', chat.chatId);
                return null;
            }
            
            const companion = await User.findById(companionId);
            if (!companion) {
                console.log('Пользователь-собеседник не найден:', companionId);
                return null;
            }
            
            let avatarUrl = companion.avatar;
            console.log(`Аватар собеседника ${companion.username} из БД:`, avatarUrl);
            
            if (!avatarUrl || avatarUrl === 'https://i.ibb.co/sJ5Bdp8d/default.jpg') {
                avatarUrl = 'https://i.ibb.co/sJ5Bdp8d/default.jpg';
            } else if (!avatarUrl.startsWith('http')) {
                const cleanPath = avatarUrl.startsWith('/') ? avatarUrl.slice(1) : avatarUrl;
                if (cleanPath.startsWith('models/uploads/')) {
                    avatarUrl = '/' + cleanPath;
                } else {
                    avatarUrl = '/models/uploads/' + cleanPath;
                }
            }
            console.log(`Итоговый URL аватара для ${companion.username}:`, avatarUrl);
            
            return {
                chatId: chat.chatId,
                companionId: companionId,
                companionName: companion.username,
                companionAvatar: avatarUrl,
                lastMessage: participant.lastMessage || 'Нет сообщений',
                lastMessageTime: participant.lastMessageTime || chat.updatedAt,
                unreadCount: participant.unreadCount || 0
            };
        }));
        
        const filtered = chatList.filter(chat => chat !== null);
        console.log('Отправляем список чатов:', filtered.length);
        res.json(filtered);
    } catch (error) {
        console.error('Ошибка получения списка чатов:', error);
        res.status(500).json({ error: 'Ошибка сервера', details: error.message });
    }
});

app.post('/api/chat/create', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;
        const { companionId } = req.body;
        
        if (!companionId) {
            return res.status(400).json({ error: 'Не указан собеседник' });
        }
        
        const existingChat = await Chat.findOne({
            participants: { $all: [userId, companionId] }
        });
        
        if (existingChat) {
            return res.json({ 
                success: true, 
                chatId: existingChat.chatId,
                exists: true 
            });
        }
        
        const chatId = `chat_${userId}_${companionId}_${Date.now()}`;
        
        const newChat = new Chat({
            chatId: chatId,
            participants: [userId, companionId],
            createdAt: new Date(),
            updatedAt: new Date(),
            messages: []
        });
        await newChat.save();
        
        await ChatParticipant.create([
            {
                userId: userId,
                chatId: chatId,
                joinedAt: new Date(),
                lastMessage: 'Чат создан',
                lastMessageTime: new Date(),
                lastMessageSender: 'Система',
                unreadCount: 0
            },
            {
                userId: companionId,
                chatId: chatId,
                joinedAt: new Date(),
                lastMessage: 'Чат создан',
                lastMessageTime: new Date(),
                lastMessageSender: 'Система',
                unreadCount: 0
            }
        ]);
        
        const companionSocket = await User.findById(companionId).select('socketId');
        if (companionSocket && companionSocket.socketId) {
            io.to(companionSocket.socketId).emit('chat-list-update');
        }
        
        res.json({ success: true, chatId: chatId });
    } catch (error) {
        console.error('Ошибка создания чата:', error);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/api/chat/history/:chatId', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;
        const { chatId } = req.params;
        
        const chat = await Chat.findOne({ chatId: chatId });
        if (!chat) {
            return res.status(404).json({ error: 'Чат не найден' });
        }
        
        if (!chat.participants.some(id => id.toString() === userId.toString())) {
            return res.status(403).json({ error: 'Доступ запрещён' });
        }
        
        await Chat.updateOne(
            { chatId: chatId, 'messages.senderId': { $ne: userId } },
            { $set: { 'messages.$[].read': true } }
        );
        
        await ChatParticipant.updateOne(
            { userId: userId, chatId: chatId },
            { $set: { unreadCount: 0 } }
        );
        
        res.json(chat.messages || []);
    } catch (error) {
        console.error('Ошибка получения истории:', error);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/api/chat/search', authenticateUser, async (req, res) => {
    try {
        const query = req.query.q;
        if (!query || query.length < 2) {
            return res.json([]);
        }
        
        const userId = req.session.user._id;
        const users = await User.find({
            _id: { $ne: userId },
            username: { $regex: query, $options: 'i' }
        }).select('_id username avatar');
        
        console.log('Найдено пользователей по запросу:', users.length);
        res.json(users);
    } catch (error) {
        console.error('Ошибка поиска:', error);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.delete('/api/chat/:chatId', authenticateUser, async (req, res) => {
    try {
        const userId = req.session.user._id;
        const { chatId } = req.params;
        
        await ChatParticipant.deleteOne({ userId: userId, chatId: chatId });
        
        const remaining = await ChatParticipant.countDocuments({ chatId: chatId });
        if (remaining === 0) {
            await Chat.deleteOne({ chatId: chatId });
        }
        
        res.json({ success: true });
    } catch (error) {
        console.error('Ошибка удаления чата:', error);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/api/chat/user-info/:socketId', authenticateUser, async (req, res) => {
    try {
        const user = await User.findOne({ socketId: req.params.socketId });
        if (!user) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }
        res.json({ username: user.username, _id: user._id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка' });
    }
});

app.get('/api/chat/get-socket-id/:userId', authenticateUser, async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }
        res.json({ socketId: user.socketId });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/api/avatar/:userId', async (req, res) => {
    try {
        const user = await User.findById(req.params.userId).select('avatar');
        if (!user) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }
        
        let avatarPath = user.avatar;
        if (!avatarPath || avatarPath === 'https://i.ibb.co/sJ5Bdp8d/default.jpg') {
            return res.json({ avatar: 'https://i.ibb.co/sJ5Bdp8d/default.jpg' });
        }
        
        if (!avatarPath.startsWith('/') && !avatarPath.startsWith('http')) {
            avatarPath = `/models/uploads/${avatarPath}`;
        }
        
        res.json({ avatar: avatarPath });
    } catch (error) {
        console.error('Ошибка получения аватара:', error);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/models/uploads/:filename', (req, res) => {
    const filepath = path.join(__dirname, 'models', 'uploads', req.params.filename);
    console.log('Запрос аватара:', filepath);
    
    if (fs.existsSync(filepath)) {
        res.sendFile(filepath);
    } else {
        console.log('Файл не найден, используем дефолтный аватар');
        res.redirect('https://i.ibb.co/sJ5Bdp8d/default.jpg');
    }
});

User.updateMany({}, {online: false, inChat: false, socketId: null, textChatEnabled: true, audioChatEnabled: true, videoChatEnabled: true})
    .then(() => console.log("Database statuses reset"))
    .catch(err => console.error("Status reset error:", err));

app.get('/api/admin/anime/:id', isAdmin, async (req, res) => {
    try {
        const anime = await Recommendation.findById(req.params.id);
        if (!anime) {
            return res.status(404).json({ error: 'Аниме не найдено' });
        }
        res.json(anime);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.put('/api/admin/anime/:id', isAdmin, async (req, res) => {
    try {
        const { title, description, genres, year, type, seasons, episodes, studio, rating, images } = req.body;
        
        const updatedAnime = await Recommendation.findByIdAndUpdate(
            req.params.id,
            {
                title,
                description,
                genres: Array.isArray(genres) ? genres : genres.split(',').map(g => g.trim()),
                year,
                type,
                seasons,
                episodes,
                studio,
                rating,
                images: Array.isArray(images) ? images : [images]
            },
            { new: true, runValidators: true }
        );
        
        if (!updatedAnime) {
            return res.status(404).json({ error: 'Аниме не найдено' });
        }
        
        res.json({ success: true, anime: updatedAnime });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/api/admin/genres/list', isAdmin, async (req, res) => {
    try {
        const allAnime = await Recommendation.find({});
        const genresSet = new Set();
        
        allAnime.forEach(anime => {
            if (anime.genres && Array.isArray(anime.genres)) {
                anime.genres.forEach(genre => {
                    genresSet.add(genre);
                });
            }
        });
        
        const genres = Array.from(genresSet).map(genre => ({
            name: genre,
            nameRu: genreTranslations[genre] || genre,
            description: getGenreDescription(genre)
        }));
        
        res.json(genres);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.get('/api/admin/genres/detailed', isAdmin, async (req, res) => {
    try {
        const allAnime = await Recommendation.find({});
        const genresMap = new Map();
        
        allAnime.forEach(anime => {
            if (anime.genres && Array.isArray(anime.genres)) {
                anime.genres.forEach(genre => {
                    if (!genresMap.has(genre)) {
                        genresMap.set(genre, {
                            _id: genre,
                            name: genre,
                            nameRu: genreTranslations[genre] || genre,
                            description: getGenreDescription(genre),
                            animeCount: 0
                        });
                    }
                    genresMap.get(genre).animeCount++;
                });
            }
        });
        
        const genres = Array.from(genresMap.values());
        res.json(genres);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.post('/api/admin/genres', isAdmin, async (req, res) => {
    try {
        const { name, nameRu, description } = req.body;
        const genreName = name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
        
        const existingAnime = await Recommendation.findOne({ genres: genreName });
        if (existingAnime) {
            return res.status(400).json({ error: 'Жанр уже существует' });
        }
        
        genreTranslations[genreName] = nameRu || genreName;
        
        res.json({ success: true, genre: { name: genreName, nameRu: nameRu || genreName, description } });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.put('/api/admin/genres/:oldName', isAdmin, async (req, res) => {
    try {
        const { oldName, newName, nameRu, description } = req.body;
        
        if (!oldName || !newName) {
            return res.status(400).json({ error: 'Не указаны названия жанров' });
        }
        
        const newGenreName = newName.charAt(0).toUpperCase() + newName.slice(1).toLowerCase();
        const oldGenreName = oldName;
        
        if (oldGenreName !== newGenreName) {
            const animeWithGenre = await Recommendation.find({ genres: oldGenreName });
            
            for (const anime of animeWithGenre) {
                const updatedGenres = anime.genres.map(g => 
                    g === oldGenreName ? newGenreName : g
                );
                await Recommendation.findByIdAndUpdate(anime._id, { genres: updatedGenres });
            }
        }
        
        genreTranslations[newGenreName] = nameRu || newGenreName;
        if (oldGenreName !== newGenreName) {
            delete genreTranslations[oldGenreName];
        }
        
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

app.delete('/api/admin/genres/:name', isAdmin, async (req, res) => {
    try {
        const genreName = req.params.name;
        
        await Recommendation.updateMany(
            { genres: genreName },
            { $pull: { genres: genreName } }
        );
        
        delete genreTranslations[genreName];
        
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});
app.get('/nikname_chat', authenticateUser, (req, res) => {
    res.render('nikname_chat', { user: req.session.user });
});

app.get('/catalog', async (req, res) => {
    try {
        const allAnime = await Recommendation.find({});
        
        const genresSet = new Set();
        allAnime.forEach(anime => {
            if (anime.genres && Array.isArray(anime.genres)) {
                anime.genres.forEach(genre => {
                    genresSet.add(genre);
                });
            }
        });
        
        const genres = Array.from(genresSet).sort();
        
        const genresWithCount = await Promise.all(
            genres.map(async (genre) => {
                const count = await Recommendation.countDocuments({ genres: genre });
                return { name: genre, count: count };
            })
        );
        
        let userTheme = 'light';
        let backgroundImage = getRandomBackground(userTheme);
        
        if (req.session && req.session.user) {
            const user = await User.findById(req.session.user._id);
            if (user && user.settings && user.settings.theme) {
                userTheme = user.settings.theme;
                backgroundImage = getRandomBackground(userTheme);
            }
        }
        
        res.render('catalog', { 
            genres: genresWithCount, 
            theme: userTheme, 
            backgroundImage: backgroundImage,
            user: req.session.user || null
        });
    } catch (error) {
        console.error('Ошибка при загрузке каталога:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/api/genres-with-images', async (req, res) => {
    try {
        const allAnime = await Recommendation.find({});
        
        const genresMap = new Map();
        
        allAnime.forEach(anime => {
            if (anime.genres && Array.isArray(anime.genres)) {
                anime.genres.forEach(genre => {
                    if (!genresMap.has(genre)) {
                        genresMap.set(genre, {
                            name: genre,
                            count: 0,
                            image: null,
                            description: getGenreDescription(genre)
                        });
                    }
                    genresMap.get(genre).count++;
                    if (!genresMap.get(genre).image && anime.images && anime.images[0]) {
                        genresMap.get(genre).image = anime.images[0];
                    }
                });
            }
        });
        
        const genres = Array.from(genresMap.values()).sort((a, b) => a.name.localeCompare(b.name));
        
        res.json(genres);
    } catch (error) {
        console.error('Ошибка при получении жанров:', error);
        res.status(500).json([]);
    }
});

const genreTranslations = {
    "Detective": "Детектив",
    "Action": "Боевик",
    "Drama": "Драма",
    "Fantasy": "Фэнтези",
    "Thriller": "Триллер",
    "Adventure": "Приключения",
    "Comedy": "Комедия",
    "Superhero": "Супергерои",
    "Historical": "Исторический",
    "Supernatural": "Сверхъестественное",
    "Family": "Семейный",
    "Sci-Fi": "Научная фантастика",
    "Sports": "Спорт",
    "Friendship": "Дружба",
    "Shonen": "Сёнэн",
    "Horror": "Ужасы",
    "Mystery": "Мистика",
    "Psychological": "Психологическое",
    "Slice of Life": "Повседневность",
    "Romance": "Романтика",
    "Music": "Музыка",
    "School": "Школа",
    "Mecha": "Меха",
    "Space": "Космос",
    "Magic": "Магия",
    "Vampire": "Вампиры",
    "Demons": "Демоны",
    "Angels": "Ангелы",
    "Martial Arts": "Боевые искусства",
    "Military": "Военное",
    "Police": "Полиция",
    "Game": "Игры",
    "Cooking": "Кулинария",
    "Art": "Искусство",
    "Travel": "Путешествия",
    "Workplace": "Работа",
    "Isekai": "Исекай (попаданцы)",
    "Harem": "Гарем",
    "Reverse Harem": "Обратный гарем",
    "Ecchi": "Эччи",
    "Seinen": "Сэйнэн",
    "Josei": "Дзёсей",
    "Kodomo": "Кодомо",
    "Cyberpunk": "Киберпанк",
    "Steampunk": "Стимпанк",
    "Post-Apocalyptic": "Постапокалипсис",
    "Time Travel": "Путешествия во времени",
    "Virtual Reality": "Виртуальная реальность",
    "Psychological Thriller": "Психологический триллер",
    "Dark Fantasy": "Тёмное фэнтези",
    "Comedy Drama": "Комедийная драма",
    "Romantic Comedy": "Романтическая комедия"
};

function getGenreDescription(genre) {
    const descriptions = {
        'Detective': 'Загадочные преступления, расследования, детективные загадки и поиск улик. Герои распутывают сложные дела и ищут правду.',
        'Action': 'Захватывающие боевые сцены, эпичные сражения и динамичный сюжет. Наполнено экшеном и адреналином.',
        'Drama': 'Эмоциональные истории, глубокие переживания и жизненные драмы. Заставляет задуматься о важных вещах.',
        'Fantasy': 'Магические миры, необычные существа и волшебство. Погружение в фантастические вселенные с уникальными правилами.',
        'Thriller': 'Напряжённый сюжет, неожиданные повороты и интрига. Держит в напряжении до самого конца.',
        'Adventure': 'Путешествия, поиски сокровищ и открытие новых миров. Герои отправляются в опасные и захватывающие приключения.',
        'Comedy': 'Юмористические ситуации, забавные диалоги и пародии. Поднимает настроение и дарит позитивные эмоции.',
        'Superhero': 'Супергерои, борьба со злом, невероятные способности и спасение мира. Люди с особыми силами защищают человечество.',
        'Historical': 'Исторические события, эпохи и культура прошлого. Погружение в разные временные периоды и традиции.',
        'Supernatural': 'Сверхъестественные силы, демоны и магия. Встречи с потусторонними явлениями и необъяснимыми феноменами.',
        'Family': 'Семейные ценности, тёплые отношения и душевные истории. Подходит для просмотра всей семьёй.',
        'Sci-Fi': 'Будущее, космос, технологии и научные открытия. Исследование передовых концепций и футуристических миров.',
        'Sports': 'Спортивные соревнования, командный дух и достижения. Путь к победе, тренировки и преодоление себя.',
        'Friendship': 'Дружба, взаимовыручка и верность товарищам. Истории о настоящих друзьях и крепких узах.',
        'Shonen': 'Сёнэн — аниме для юношей с динамичным сюжетом, дружбой и борьбой. Герои становятся сильнее и преодолевают препятствия.',
        'Horror': 'Пугающие истории, мистика и сверхъестественное. Вызывает чувство страха и тревоги.',
        'Mystery': 'Загадочные события, расследования и тайны. Заставляет зрителя строить догадки и разгадывать секреты.',
        'Psychological': 'Глубокие психологические аспекты, внутренние конфликты. Исследование человеческой психики и моральных дилемм.',
        'Slice of Life': 'Повседневная жизнь, обычные люди и реалистичные ситуации. Показывает красоту в простых моментах.',
        'Romance': 'Любовные линии, романтические отношения и чувства. Истории о первой любви и сердечных переживаниях.',
        'Music': 'Музыкальная тематика, выступления и творчество. Герои стремятся к мечте через музыку.',
        'School': 'Школьная жизнь, дружба и взросление. История о школьниках и их повседневных приключениях.',
        'Mecha': 'Гигантские роботы, битвы на мехах и технологии. Пилоты управляют огромными боевыми машинами.',
        'Space': 'Космические путешествия, галактики и звёздные войны. Исследование бескрайних просторов вселенной.',
        'Magic': 'Магические школы, заклинания и волшебные существа. Мир, где магия является неотъемлемой частью жизни.',
        'Vampire': 'Вампиры, кровь и ночные приключения. Тёмные и романтичные истории о бессмертных существах.',
        'Demons': 'Демоны, ад и битвы со злом. Противостояние сил света и тьмы.',
        'Angels': 'Ангелы, божественное и небесные битвы. Истории о падших и возвышенных созданиях.',
        'Martial Arts': 'Боевые искусства, турниры и тренировки. Путь воина и мастерство владения телом.',
        'Military': 'Военные действия, армия и тактика. Стратегические сражения и военные конфликты.',
        'Police': 'Полицейские будни, преступность и правосудие. Борьба с преступностью и защита закона.',
        'Game': 'Игры, виртуальные миры и киберспорт. Герои сражаются в игровых вселенных.',
        'Cooking': 'Кулинария, рецепты и гастрономические приключения. Вкусная еда и соревнования поваров.',
        'Art': 'Искусство, творчество и вдохновение. История о художниках, музыкантах и творцах.',
        'Travel': 'Путешествия, новые места и культурный обмен. Открытие мира и знакомство с разными культурами.',
        'Workplace': 'Офисные будни, карьера и профессиональные отношения. Жизнь обычных работников и их успехи.',
        'Isekai': 'Исекай — попадание в другой мир. Обычный человек оказывается в фантастическом мире.',
        'Harem': 'Гарем — один герой и множество поклонниц. Любовные многоугольники и романтические ситуации.',
        'Reverse Harem': 'Обратный гарем — одна героиня и множество поклонников. Девушка оказывается в центре внимания.',
        'Ecchi': 'Эччи — эротический подтекст, фансервис. Лёгкие пикантные сцены и комичные ситуации.',
        'Seinen': 'Сэйнэн — аниме для взрослой аудитории. Более серьёзные темы и глубокий сюжет.',
        'Josei': 'Дзёсей — аниме для взрослых женщин. Реалистичные отношения и жизненные истории.',
        'Kodomo': 'Кодомо — аниме для маленьких детей. Обучающие и развлекательные истории.',
        'Cyberpunk': 'Киберпанк — высокие технологии и антиутопия. Будущее с кибернетическими имплантами и корпорациями.',
        'Steampunk': 'Стимпанк — альтернативная викторианская эпоха с паром и механизмами. Ретро-футуристические технологии.',
        'Post-Apocalyptic': 'Постапокалипсис — мир после катастрофы. Выживание в разрушенном мире и борьба за ресурсы.',
        'Time Travel': 'Путешествия во времени, изменение прошлого и будущего. Герои перемещаются между эпохами.',
        'Virtual Reality': 'Виртуальная реальность — игра внутри игры. Полное погружение в цифровые миры.',
        'Psychological Thriller': 'Психологический триллер — напряжение и манипуляции. Игры разума и психологические ловушки.',
        'Dark Fantasy': 'Тёмное фэнтези — мрачные миры и суровая реальность. Жестокие истории с элементами магии.',
        'Comedy Drama': 'Комедийная драма — смех сквозь слёзы. Сочетание юмора и глубоких переживаний.',
        'Romantic Comedy': 'Романтическая комедия — любовь и юмор. Смешные ситуации и романтические линии.'
    };
    
    return descriptions[genre] || 'Увлекательные аниме этого жанра ждут вас! Погрузитесь в мир ярких эмоций и незабываемых историй.';
}

const reverseGenreTranslations = {
    "Детектив": "Detective",
    "Боевик": "Action",
    "Драма": "Drama",
    "Фэнтези": "Fantasy",
    "Триллер": "Thriller",
    "Приключения": "Adventure",
    "Комедия": "Comedy",
    "Супергерои": "Superhero",
    "Исторический": "Historical",
    "Сверхъестественное": "Supernatural",
    "Семейный": "Family",
    "Научная фантастика": "Sci-Fi",
    "Спорт": "Sports",
    "Дружба": "Friendship",
    "Сёнэн": "Shonen",
    "Ужасы": "Horror",
    "Мистика": "Mystery",
    "Психологическое": "Psychological",
    "Повседневность": "Slice of Life",
    "Романтика": "Romance",
    "Музыка": "Music",
    "Школа": "School",
    "Меха": "Mecha",
    "Космос": "Space",
    "Магия": "Magic",
    "Вампиры": "Vampire",
    "Демоны": "Demons",
    "Ангелы": "Angels",
    "Боевые искусства": "Martial Arts",
    "Военное": "Military",
    "Полиция": "Police",
    "Игры": "Game",
    "Кулинария": "Cooking",
    "Искусство": "Art",
    "Путешествия": "Travel",
    "Работа": "Workplace",
    "Исекай": "Isekai",
    "Гарем": "Harem",
    "Обратный гарем": "Reverse Harem",
    "Эччи": "Ecchi",
    "Сэйнэн": "Seinen",
    "Дзёсей": "Josei",
    "Кодомо": "Kodomo",
    "Киберпанк": "Cyberpunk",
    "Стимпанк": "Steampunk",
    "Постапокалипсис": "Post-Apocalyptic",
    "Путешествия во времени": "Time Travel",
    "Виртуальная реальность": "Virtual Reality",
    "Психологический триллер": "Psychological Thriller",
    "Тёмное фэнтези": "Dark Fantasy",
    "Комедийная драма": "Comedy Drama",
    "Романтическая комедия": "Romantic Comedy"
};

app.get('/blog', async (req, res) => {
    try {
        const { category, search } = req.query;
        let query = { published: true };
        
        if (category && category !== 'all') {
            query.category = category;
        }
        
        if (search) {
            query.$or = [
                { title: { $regex: search, $options: 'i' } },
                { content: { $regex: search, $options: 'i' } },
                { tags: { $in: [new RegExp(search, 'i')] } }
            ];
        }
        
        const page = parseInt(req.query.page) || 1;
        const limit = 9;
        const skip = (page - 1) * limit;
        
        const posts = await BlogPost.find(query)
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit);
        
        const totalPosts = await BlogPost.countDocuments(query);
        const totalPages = Math.ceil(totalPosts / limit);
        
        const popularPosts = await BlogPost.find({ published: true })
            .sort({ views: -1 })
            .limit(5);
        
        const categories = await BlogPost.aggregate([
            { $match: { published: true } },
            { $group: { _id: '$category', count: { $sum: 1 } } },
            { $sort: { count: -1 } }
        ]);
        
        const tags = await BlogPost.aggregate([
            { $match: { published: true } },
            { $unwind: '$tags' },
            { $group: { _id: '$tags', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
            { $limit: 15 }
        ]);
        
        let userTheme = 'light';
        let backgroundImage = getRandomBackground(userTheme);
        
        if (req.session && req.session.user) {
            const user = await User.findById(req.session.user._id);
            if (user && user.settings && user.settings.theme) {
                userTheme = user.settings.theme;
                backgroundImage = getRandomBackground(userTheme);
            }
        }
        
        res.render('blog', {
            posts,
            categories: categories.map(c => ({ name: c._id, count: c.count })),
            popularPosts,
            tags: tags.map(t => ({ name: t._id, count: t.count })),
            currentPage: page,
            totalPages,
            currentCategory: category || 'all',
            searchQuery: search || '',
            theme: userTheme,
            backgroundImage,
            user: req.session.user || null
        });
    } catch (error) {
        console.error('Ошибка загрузки блога:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/blog/:slug', async (req, res) => {
    try {
        const post = await BlogPost.findOne({ slug: req.params.slug, published: true });
        
        if (!post) {
            return res.status(404).send('Статья не найдена');
        }
        
        post.views += 1;
        await post.save();
        
        const relatedPosts = await BlogPost.find({
            _id: { $ne: post._id },
            published: true,
            $or: [
                { category: post.category },
                { tags: { $in: post.tags } }
            ]
        }).limit(3);
        
        let userTheme = 'light';
        let backgroundImage = getRandomBackground(userTheme);
        
        if (req.session && req.session.user) {
            const user = await User.findById(req.session.user._id);
            if (user && user.settings && user.settings.theme) {
                userTheme = user.settings.theme;
                backgroundImage = getRandomBackground(userTheme);
            }
        }
        
        res.render('blog_post', {
            post,
            relatedPosts,
            theme: userTheme,
            backgroundImage,
            user: req.session.user || null
        });
    } catch (error) {
        console.error('Ошибка загрузки статьи:', error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/api/blog/:slug/comment', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.status(401).json({ success: false, message: 'Не авторизован' });
        }
        
        const { text } = req.body;
        const post = await BlogPost.findOne({ slug: req.params.slug });
        
        if (!post) {
            return res.status(404).json({ success: false, message: 'Статья не найдена' });
        }
        
        post.comments.push({
            userId: req.session.user._id,
            username: req.session.user.username,
            text: text
        });
        
        await post.save();
        
        res.json({ success: true, message: 'Комментарий добавлен' });
    } catch (error) {
        console.error('Ошибка добавления комментария:', error);
        res.status(500).json({ success: false, message: 'Ошибка сервера' });
    }
});

app.post('/api/blog/:slug/like', async (req, res) => {
    try {
        if (!req.session.user) {
            return res.status(401).json({ success: false, message: 'Не авторизован' });
        }
        
        const post = await BlogPost.findOne({ slug: req.params.slug });
        
        if (!post) {
            return res.status(404).json({ success: false, message: 'Статья не найдена' });
        }
        
        const userId = req.session.user._id;
        const hasLiked = post.likes.includes(userId);
        
        if (hasLiked) {
            post.likes = post.likes.filter(id => id.toString() !== userId.toString());
        } else {
            post.likes.push(userId);
        }
        
        await post.save();
        
        res.json({ success: true, likes: post.likes.length, hasLiked: !hasLiked });
    } catch (error) {
        console.error('Ошибка лайка:', error);
        res.status(500).json({ success: false, message: 'Ошибка сервера' });
    }
});

app.get('/admin/blog', isAdmin, async (req, res) => {
    try {
        const posts = await BlogPost.find().sort({ createdAt: -1 });
        res.render('admin_blog', { posts, user: req.session.user });
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка сервера');
    }
});

app.get('/admin/blog/new', isAdmin, (req, res) => {
    res.render('admin_blog_edit', { post: null, isEdit: false, user: req.session.user });
});

app.post('/admin/blog/new', isAdmin, async (req, res) => {
    try {
        const { title, category, excerpt, content, tags, author, image } = req.body;
        let slug = title.toLowerCase()
            .replace(/[^a-zа-яё0-9\s]/gi, '')
            .replace(/\s+/g, '-');
        
        const existingPost = await BlogPost.findOne({ slug });
        if (existingPost) {
            slug += '-' + Date.now();
        }
        
        const tagsArray = tags ? tags.split(',').map(t => t.trim()) : [];
        
        const post = new BlogPost({
            title,
            slug,
            category,
            excerpt,
            content,
            tags: tagsArray,
            author: author || req.session.user.username,
            image: image || '/uploads/blog/default.jpg'
        });
        
        await post.save();
        res.redirect('/admin/blog');
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка создания статьи');
    }
});

app.get('/admin/blog/edit/:id', isAdmin, async (req, res) => {
    try {
        const post = await BlogPost.findById(req.params.id);
        if (!post) {
            return res.status(404).send('Статья не найдена');
        }
        res.render('admin_blog_edit', { post, isEdit: true, user: req.session.user });
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка сервера');
    }
});

app.post('/admin/blog/edit/:id', isAdmin, async (req, res) => {
    try {
        const { title, category, excerpt, content, tags, author, image, published } = req.body;
        const tagsArray = tags ? tags.split(',').map(t => t.trim()) : [];
        
        await BlogPost.findByIdAndUpdate(req.params.id, {
            title,
            category,
            excerpt,
            content,
            tags: tagsArray,
            author,
            image: image || '/uploads/blog/default.jpg',
            published: published === 'on',
            updatedAt: new Date()
        });
        
        res.redirect('/admin/blog');
    } catch (error) {
        console.error(error);
        res.status(500).send('Ошибка обновления статьи');
    }
});

app.delete('/admin/blog/delete/:id', isAdmin, async (req, res) => {
    try {
        await BlogPost.findByIdAndDelete(req.params.id);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false });
    }
});

app.get('/api/admin/stats/users', isAdmin, async (req, res) => {
    const count = await User.countDocuments();
    res.json({ count });
});
app.get('/api/admin/stats/anime', isAdmin, async (req, res) => {
    const count = await Recommendation.countDocuments();
    res.json({ count });
});
app.get('/api/admin/stats/genres', isAdmin, async (req, res) => {
    const genres = await Recommendation.distinct('genres');
    res.json({ count: genres.length });
});
app.get('/api/admin/stats/posts', isAdmin, async (req, res) => {
    const count = await BlogPost.countDocuments();
    res.json({ count });
});

app.get('/api/admin/users', isAdmin, async (req, res) => {
    const users = await User.find().select('-password');
    res.json(users);
});
app.put('/api/admin/users/:id/role', isAdmin, async (req, res) => {
    await User.findByIdAndUpdate(req.params.id, { role: req.body.role });
    res.json({ success: true });
});
app.delete('/api/admin/users/:id', isAdmin, async (req, res) => {
    await User.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

app.get('/api/admin/genres', isAdmin, async (req, res) => {
    const genres = await Recommendation.distinct('genres');
    res.json(genres.map(g => ({ name: g, _id: g })));
});
app.post('/api/admin/genres', isAdmin, async (req, res) => {
    res.json({ success: true });
});
app.delete('/api/admin/genres/:id', isAdmin, async (req, res) => {
    res.json({ success: true });
});

app.get('/api/admin/comments', isAdmin, async (req, res) => {
    const reviews = await Review.find().populate('userId', 'username').populate('animeId', 'title');
    res.json(reviews.map(r => ({ _id: r._id, username: r.userId?.username, animeTitle: r.animeId?.title, text: r.text, createdAt: r.createdAt })));
});
app.delete('/api/admin/comments/:id', isAdmin, async (req, res) => {
    await Review.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

app.get('/api/admin/arts', isAdmin, async (req, res) => {
    const arts = await Art.find().populate('animeId', 'title');
    res.json(arts.map(a => ({ _id: a._id, imageUrl: a.imageUrl, title: a.title, author: a.author, animeTitle: a.animeId?.title })));
});
app.delete('/api/admin/arts/:id', isAdmin, async (req, res) => {
    await Art.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

app.get('/api/admin/blog-posts', isAdmin, async (req, res) => {
    const posts = await BlogPost.find().sort({ createdAt: -1 });
    res.json(posts);
});
app.delete('/api/admin/blog-posts/:id', isAdmin, async (req, res) => {
    await BlogPost.findByIdAndDelete(req.params.id);
    res.json({ success: true });
});

app.post('/api/admin/anime', isAdmin, async (req, res) => {
    const { title, description, genres, year, type, seasons, episodes, studio, rating, images } = req.body;
    const newAnime = new Recommendation({
        title, description, genres, year, type, seasons, episodes, studio, rating, images,
        category_name: 'Аниме', seller_name: 'AniYume'
    });
    await newAnime.save();
    res.json({ success: true });
});

app.delete('/api/admin/anime/:id', isAdmin, async (req, res) => {
    try {
        await Recommendation.findByIdAndDelete(req.params.id);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false });
    }
});

app.get('/admin', isAdmin, (req, res) => {
    res.render('admin_account', { user: req.session.user });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/arts', express.static(path.join(__dirname, 'models', 'public', 'arts')));
app.use('/drafts', express.static(path.join(__dirname, 'drafts')));
app.use('/music', express.static(path.join(__dirname, 'music')));
app.use('/models/uploads', express.static(path.join(__dirname, 'models', 'uploads')));

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});