let currentIndex = 0;
const cardWidth = document.querySelector('.card-instance').offsetWidth + 20;
const cardsContainer = document.querySelector('.cards');
const totalCards = document.querySelectorAll('.card-instance').length;

function scrollCards(direction) {
    currentIndex = (currentIndex + direction + totalCards) % totalCards;
    cardsContainer.style.transform = `translateX(-${currentIndex * cardWidth}px)`;
}

function getVisibleCards() {
    return Math.floor(document.querySelector('.slider-container').offsetWidth / cardWidth);
}

window.addEventListener('resize', () => {
    currentIndex = 0;
    cardsContainer.style.transform = 'translateX(0)';
});

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('open-register-modal').addEventListener('click', (event) => {
        event.preventDefault();
        document.getElementById('login-modal').style.display = 'none';
        document.getElementById('register-modal').style.display = 'block';
    });

    document.querySelectorAll('.close-button').forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });

    window.addEventListener('click', (event) => {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
    
    const authButtons = document.getElementById('auth-buttons');
    const personalAccountCard = document.getElementById('personal-account-card');

    document.querySelectorAll('.testimonial-link').forEach(link => {
        link.addEventListener('click', async (event) => {
            event.preventDefault();
            try {
                const response = await fetch('/api/user', {
                    method: 'GET',
                    credentials: 'include'
                });
                if (response.ok) {
                    window.location.href = '/personal_account';
                } else {
                    document.getElementById('login-modal').style.display = 'block';
                }
            } catch (error) {
                console.error('Ошибка проверки авторизации:', error);
                Toastify({
                    text: 'An error occurred while checking authorization.',
                    className: 'toastify-error',
                    duration: 3000
                }).showToast();
            }
        });
    });
    
    const chatCard = document.getElementById('chat-card');

    document.querySelectorAll('.testimonial-chat-link').forEach(link => {
        link.addEventListener('click', async (event) => {
            event.preventDefault();
            try {
                const response = await fetch('/api/user', {
                    method: 'GET',
                    credentials: 'include'
                });
                if (response.ok) {
                    window.location.href = '/chats';
                } else {
                    document.getElementById('login-modal').style.display = 'block';
                }
            } catch (error) {
                console.error('Ошибка проверки авторизации:', error);
                Toastify({
                    text: 'An error occurred while checking authorization.',
                    className: 'toastify-error',
                    duration: 3000
                }).showToast();
            }
        });
    });

document.getElementById('login-submit').addEventListener('click', async (event) => {
    event.preventDefault();

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    console.log('Отправляемые данные:', { email, password });

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password }),
            credentials: 'include'
        });

        const data = await response.json();
        console.log('Ответ сервера:', data);
        console.log('Полученная роль:', data.role);

        if (response.ok) {
            Toastify({
                text: data.message || 'Вход выполнен успешно',
                className: 'toastify-success',
                duration: 3000
            }).showToast();
            
            // ПРОВЕРКА РОЛИ
            if (data.role === "Главный администратор" || data.role === "Администратор") {
                console.log('Перенаправление на /admin (админ-панель)');
                window.location.href = '/admin';
            } else {
                console.log('Перенаправление на /personal_account (личный кабинет)');
                window.location.href = '/personal_account';
            }
        } else {
            Toastify({
                text: data.message || 'Произошла ошибка при входе.',
                className: 'toastify-error',
                duration: 3000
            }).showToast();
        }
    } catch (error) {
        console.error('Ошибка входа:', error);
        Toastify({
            text: 'Произошла ошибка при входе.',
            className: 'toastify-error',
            duration: 3000
        }).showToast();
    }
});

document.getElementById('register-submit').addEventListener('click', async (event) => {
    event.preventDefault();

    const formData = new FormData();
    formData.append('username', document.getElementById('register-username').value);
    formData.append('email', document.getElementById('register-email').value);
    formData.append('password', document.getElementById('register-password').value);
    formData.append('confirm_password', document.getElementById('register-confirm-password').value);
    formData.append('gender', document.getElementById('register-gender').value);
    formData.append('date_of_birth', document.getElementById('register-date-of-birth').value);
    formData.append('country', document.getElementById('register-country').value);
    formData.append('language', document.getElementById('register-language').value);
    formData.append('favorite_genres', document.getElementById('register-favorite-genres').value);
    formData.append('favorite_anime', document.getElementById('register-favorite-anime').value);
    formData.append('terms_agreement', document.getElementById('register-terms-agreement').checked);
    formData.append('newsletter_subscription', document.getElementById('register-newsletter-subscription').checked);
    formData.append('favorite_character', document.getElementById('register-favorite-character').value);
    formData.append('profile_description', document.getElementById('register-profile-description').value);
    formData.append('avatar', document.getElementById('register-avatar').files[0]);

    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            body: formData,
            credentials: 'include'
        });

        const data = await response.json();

        if (response.ok) {
            alert(data.message || 'Регистрация успешна');
            window.location.href = '/personal_account';
        } else {
            alert(data.message || 'Произошла ошибка при регистрации.');
        }
    } catch (error) {
        console.error('Ошибка регистрации:', error);
        alert('Произошла ошибка при регистрации.');
    }
});
 });   

document.addEventListener('DOMContentLoaded', () => {
    const socialIcons = document.querySelectorAll('.social-icon');

    socialIcons.forEach(icon => {
        icon.addEventListener('click', (event) => {
            event.preventDefault();
            const modalId = icon.dataset.modal;
            const modal = document.getElementById(modalId);
            modal.style.display = "block";
        });
    });

    const closeButtons = document.querySelectorAll('.close-social');

    closeButtons.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal-social'); 
            modal.style.display = "none"; 
        });
    });

    window.addEventListener('click', (event) => {
        if (event.target.classList.contains('modal-social')) {
            event.target.style.display = "none"; 
        }
    });
});

// Проверка авторизации и отображение карточки админа
async function checkAdminAndShowCard() {
    try {
        const response = await fetch('/api/user', {
            method: 'GET',
            credentials: 'include'
        });
        
        if (response.ok) {
            const userData = await response.json();
            console.log('Данные пользователя:', userData);
            
            if (userData.role === "Главный администратор" || userData.role === "Администратор") {
                const adminCard = document.getElementById('admin-card');
                if (adminCard) {
                    adminCard.style.display = 'block';
                    console.log('Карточка админа показана');
                }
            }
        }
    } catch (error) {
        console.error('Ошибка проверки прав администратора:', error);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    checkAdminAndShowCard();
});