let currentIndex = {
    userArts: 0,
    animeCards: 0
};

function scrollCards(direction, containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) return;

    const cards = Array.from(container.children);
    if (cards.length === 0) return;

    const currentContainerKey = containerSelector === '#userArtsList' ? 'userArts' : 'animeCards';
    let cardWidth = cards[0].offsetWidth + 20;

    currentIndex[currentContainerKey] += direction;

    currentIndex[currentContainerKey] =
        ((currentIndex[currentContainerKey] % cards.length) + cards.length) % cards.length;

    container.style.transform = `translateX(-${currentIndex[currentContainerKey] * cardWidth}px)`;
}

window.addEventListener('resize', () => {
    currentIndex.userArts = 0;
    currentIndex.animeCards = 0;

    const userArtsContainer = document.getElementById('userArtsList');
    const animeCardsContainer = document.querySelector('.anime-cards');

    if (userArtsContainer) userArtsContainer.style.transform = 'translateX(0)';
    if (animeCardsContainer) animeCardsContainer.style.transform = 'translateX(0)';
});

document.addEventListener('DOMContentLoaded', () => {
    const userId = document.body.getAttribute('data-user-id');

    const uploadPhotoButton = document.getElementById('uploadPhotoButton');
    const uploadPhotoInput = document.getElementById('uploadPhotoInput');

    uploadPhotoButton.addEventListener('click', () => {
        uploadPhotoInput.click();
    });

    uploadPhotoInput.addEventListener('change', async () => {
        try {
            const file = uploadPhotoInput.files[0];
            if (!file) {
                return alert('Файл не выбран');
            }

            const formData = new FormData();
            formData.append('avatar', file);

            const response = await fetch('/upload-avatar', {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();
            if (response.ok) {
                updateUserAvatar(userId);
                alert(data.message);
            } else {
                alert(data.message || 'Ошибка при загрузке аватара');
            }
        } catch (error) {
            console.error('Ошибка при загрузке аватара:', error);
            alert('Произошла ошибка при загрузке аватара');
        }
    });

    const deletePhotoButton = document.getElementById('deletePhotoButton');
    deletePhotoButton.addEventListener('click', async () => {
        try {
            const response = await fetch('/delete-avatar', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            const data = await response.json();
            if (response.ok) {
                updateUserAvatar(userId);
                alert(data.message);
            } else {
                alert(data.message || 'Ошибка при удалении аватара');
            }
        } catch (error) {
            console.error('Ошибка при удалении аватара:', error);
            alert('Произошла ошибка при удалении аватара');
        }
    });

    function updateUserAvatar(userId) {
        const avatarElement = document.getElementById('user-avatar');
        if (avatarElement) {
            avatarElement.src = `/user-avatar/${userId}`;
        }
    }

    if (userId) {
        updateUserAvatar(userId);
    }
});

document.getElementById('profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    if (!data.username || !data.email) {
        Toastify({
            text: 'Имя пользователя и email обязательны',
            duration: 3000,
            close: true,
            gravity: 'top',
            position: 'right',
            backgroundColor: '#ff4d4d',
        }).showToast();
        return;
    }

    try {
        const response = await fetch('/api/update-profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        if (response.ok) {
            Toastify({
                text: result.message || 'Данные успешно обновлены',
                duration: 3000,
                close: true,
                gravity: 'top',
                position: 'right',
                backgroundColor: '#4caf50',
            }).showToast();
        } else {
            Toastify({
                text: result.message || 'Ошибка при обновлении профиля',
                duration: 3000,
                close: true,
                gravity: 'top',
                position: 'right',
                backgroundColor: '#ff4d4d',
            }).showToast();
        }
    } catch (error) {
        console.error('Ошибка:', error);
        Toastify({
            text: 'Произошла ошибка при отправке данных',
            duration: 3000,
            close: true,
            gravity: 'top',
            position: 'right',
            backgroundColor: '#ff4d4d',
        }).showToast();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    fetchFavorites();
});

async function fetchFavorites() {
    try {
        const response = await fetch('/api/favorites');
        if (!response.ok) {
            throw new Error('Ошибка при запросе избранного');
        }
        const data = await response.json();

        const favoritesList = document.getElementById('favorites-list');
        const noFavoritesMessage = document.getElementById('no-favorites-message');

        if (Array.isArray(data.favorites)) {
            if (data.favorites.length > 0) {
                favoritesList.innerHTML = '';

                data.favorites.forEach(animeTitle => {
                    const listItem = document.createElement('li');
                    listItem.innerHTML = `
                        <span>${animeTitle}</span>
                        <button class="remove-favorite" data-title="${animeTitle}">Удалить</button>
                    `;
                    favoritesList.appendChild(listItem);
                });

                const removeButtons = document.querySelectorAll('.remove-favorite');
                removeButtons.forEach(button => {
                    button.addEventListener('click', removeFavorite);
                });

                noFavoritesMessage.style.display = 'none';
            } else {
                noFavoritesMessage.style.display = 'block';
            }
        } else {
            console.error('Ошибка: favorites не является массивом или отсутствует. Полученные данные:', data);
            noFavoritesMessage.style.display = 'block';
        }

    } catch (error) {
        console.error('Ошибка при загрузке избранного:', error);
        Toastify({
            text: 'Ошибка при загрузке избранного.',
            className: 'toastify-error',
            duration: 3000
        }).showToast();
    }
}

async function removeFavorite(event) {
    const animeTitle = event.target.dataset.title;
    try {
        const response = await fetch(`/api/remove-from-favorites/${encodeURIComponent(animeTitle)}`, {
            method: 'DELETE',
        });

        if (!response.ok) {
            throw new Error('Ошибка при удалении из избранного');
        }

        fetchFavorites();

    } catch (error) {
        console.error('Ошибка при удалении из избранного:', error);
        Toastify({
            text: 'Ошибка при удалении аниме из избранного',
            className: 'toastify-error',
            duration: 3000
        }).showToast();
    }
}

document.getElementById('delete-account-btn').addEventListener('click', deleteAccount);

async function deleteAccount() {
    if (confirm('Вы уверены, что хотите удалить свой аккаунт? Это действие необратимо.')) {
        try {
            const response = await fetch('/api/delete-account', {
                method: 'DELETE',
            });

            if (!response.ok) {
                throw new Error('Ошибка при удалении аккаунта');
            }

            const data = await response.json();
            Toastify({
                text: data.message,
                className: 'toastify-success',
                duration: 3000
            }).showToast();

            window.location.href = data.redirect;

        } catch (error) {
            console.error('Ошибка при удалении аккаунта:', error);
            Toastify({
                text: 'Ошибка при удалении аккаунта',
                className: 'toastify-error',
                duration: 3000
            }).showToast();
        }
    }
}

async function fetchRecommendations() {
    try {
        const response = await fetch('/api/recommendations');
        const data = await response.json();
        generateCards(data);
    } catch (error) {
        console.error('Error fetching recommendations:', error);
    }
}

function generateCards(animeData) {
    const container = document.querySelector('.anime-cards');
    container.innerHTML = '';

    animeData.forEach((anime) => {
        const firstImage = Array.isArray(anime.images) && anime.images.length > 0 ? anime.images[0] : 'https://via.placeholder.com/150';

        const card = document.createElement('div');
        card.classList.add('anime-card');
        card.setAttribute('data-id', anime._id);

        card.innerHTML = `
            <img src="${firstImage}" alt="${anime.title}">
            <h4>${anime.title}</h4>
            <p>${anime.description.substring(0, 100)}...</p>
        `;

        card.addEventListener('click', () => {
            createAnimePage(anime);
        });
        container.appendChild(card);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    fetchRecommendations();
});

function createAnimePage(anime) {
    window.location.href = `/anime/${anime._id}`;
}

function goBack() {
    location.reload();
}

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('uploadArtModal');
    const openModalButton = document.getElementById('openUploadArtModal');
    const closeModalButton = document.querySelector('.close-button');
    const animeSelect = document.getElementById('animeId');

    openModalButton.addEventListener('click', async () => {
        modal.style.display = 'block';

        try {
            const response = await fetch('/api/anime-titles');

            if (!response.ok) {
                throw new Error(`Ошибка HTTP: ${response.status}`);
            }

            const animeTitles = await response.json();

            console.log('Данные с сервера:', animeTitles);

            if (!Array.isArray(animeTitles)) {
                throw new Error('Полученные данные не являются массивом');
            }

            animeSelect.innerHTML = '';

            animeTitles.forEach(anime => {
                const option = document.createElement('option');
                option.value = anime.id;
                option.textContent = anime.title;
                animeSelect.appendChild(option);
            });
        } catch (error) {
            console.error('Ошибка при загрузке названий аниме:', error);
        }
    });

    closeModalButton.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const userArtsList = document.getElementById('userArtsList');
    const editModal = document.getElementById('editArtModal');
    const closeModalButton = document.querySelector('#editArtModal .close-button');

    async function loadUserArts() {
        try {
            const response = await fetch('/user-arts');
            if (!response.ok) throw new Error('Ошибка загрузки артов');

            const arts = await response.json();
            userArtsList.innerHTML = '';

            arts.forEach(art => {
                const artCard = document.createElement('div');
                artCard.classList.add('art-card');

                artCard.innerHTML = `
                    <img src="${art.imageUrl}" alt="${art.title}" class="art-image">
                    <div class="art-info">
                        <h5>${art.title}</h5>
                        <p><strong>Автор:</strong> ${art.author}</p>
                        <p><strong>Аниме:</strong> ${art.animeId.title}</p>
                        <p><strong>Тэг:</strong> ${art.tag || 'Нет'}</p>
                        <p><strong>Подпись:</strong> ${art.signature || 'Нет'}</p>
                        <button class="btn btn-edit" data-id="${art._id}">Редактировать</button>
                        <button class="btn btn-delete" data-id="${art._id}">Удалить</button>
                    </div>
                `;

                userArtsList.appendChild(artCard);
            });

            document.querySelectorAll('.btn-edit').forEach(button => {
                button.addEventListener('click', async () => {
                    const artId = button.dataset.id;
                    openEditModal(artId);
                });
            });

            document.querySelectorAll('.btn-delete').forEach(button => {
                button.addEventListener('click', async () => {
                    const artId = button.dataset.id;
                    if (confirm('Вы уверены, что хотите удалить этот арт?')) {
                        const response = await fetch(`/art/${artId}`, { method: 'DELETE' });
                        if (response.ok) {
                            loadUserArts();
                        } else {
                            alert('Ошибка при удалении арта');
                        }
                    }
                });
            });
        } catch (error) {
            console.error('Ошибка загрузки артов:', error);
        }
    }

    loadUserArts();

    async function openEditModal(artId) {
        try {
            const response = await fetch(`/art/${artId}`);
            if (!response.ok) throw new Error('Арт не найден');

            const art = await response.json();

            document.getElementById('editArtId').value = art._id;
            document.getElementById('editTitle').value = art.title;
            document.getElementById('editAuthor').value = art.author;
            document.getElementById('editSignature').value = art.signature || '';
            document.getElementById('editTag').value = art.tag || '';

            editModal.style.display = 'block';
        } catch (error) {
            console.error('Ошибка загрузки данных для редактирования:', error);
            alert('Не удалось загрузить данные арта');
        }
    }

    closeModalButton.addEventListener('click', () => {
        editModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target === editModal) {
            editModal.style.display = 'none';
        }
    });

    document.getElementById('editArtForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const artId = document.getElementById('editArtId').value;
        const formData = new FormData(e.target);

        try {
            const response = await fetch(`/art/${artId}`, {
                method: 'PUT',
                body: formData
            });

            if (response.ok) {
                editModal.style.display = 'none';
                loadUserArts();
            } else {
                const errorData = await response.json();
                alert(errorData.message || 'Ошибка при сохранении изменений');
            }
        } catch (error) {
            console.error('Ошибка при отправке данных:', error);
            alert('Произошла ошибка при сохранении изменений');
        }
    });
});

const themeSelect = document.getElementById('theme');
const body = document.body;
const settingsForm = document.getElementById('settings-form');

themeSelect.addEventListener('change', (event) => {
    const selectedTheme = event.target.value;

    fetch('/api/update-theme', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ theme: selectedTheme })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        window.location.reload();
    })
    .catch(error => {
        console.error('Ошибка при сохранении темы:', error);
    });
});

settingsForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const theme = themeSelect.value;
    const notifications = document.getElementById('notifications').checked;

    try {
        const response = await fetch('/api/update-profile', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                settings: JSON.stringify({ theme: theme, notifications: notifications })
            })
        });

        if (response.ok) {
            Toastify({
                text: 'Настройки успешно сохранены!',
                className: 'toastify-success',
                duration: 3000
            }).showToast();
        } else {
            const data = await response.json();
            Toastify({
                text: 'Ошибка сохранения настроек: ' + (data.message || 'Неизвестная ошибка'),
                className: 'toastify-error',
                duration: 3000
            }).showToast();
        }
    } catch (error) {
        console.error('Ошибка при отправке настроек:', error);
        Toastify({
            text: 'Ошибка сервера при сохранении настроек.',
            className: 'toastify-error',
            duration: 3000
        }).showToast();
    }
});