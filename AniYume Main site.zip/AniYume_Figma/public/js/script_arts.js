document.addEventListener("DOMContentLoaded", function () {
    // Инициализация Masonry
    const container = document.querySelector('.arts-container');
    if (container) {
        const masonry = new Masonry(container, {
            itemSelector: '.art-item', 
            columnWidth: '.art-item', 
            percentPosition: true, 
            gutter: 20, 
            horizontalOrder: true,
        });

        window.addEventListener('resize', function () {
            masonry.layout();
        });
    }
});
