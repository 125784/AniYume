let currentIndex = 0;

function scrollCarousel(direction, containerSelector, itemSelector) {
    const container = document.querySelector(containerSelector);
    const items = document.querySelectorAll(itemSelector);
    const itemWidth = items[0].offsetWidth + 20;

    let currentIndex = parseInt(container.dataset.currentIndex || 0);

    currentIndex += direction;

    if (currentIndex < 0) {
        currentIndex = 0;
    } else if (currentIndex > items.length - Math.floor(container.offsetWidth / itemWidth)) {
        currentIndex = items.length - Math.floor(container.offsetWidth / itemWidth);
    }

    container.dataset.currentIndex = currentIndex;

    container.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
}



const similarAnimeContainer = document.querySelector('.similar-anime-cards');

function loadSimilarAnime(animeId) {
    fetch(`/api/similar-anime/${animeId}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            const container = document.querySelector('.similar-anime-cards');
            container.innerHTML = '';

            if (!data || data.length === 0) {
                container.textContent = 'Похожие аниме не найдены.';
                return;
            }

            data.forEach(anime => {
                const card = document.createElement('div');
                card.classList.add('anime-card');

                const img = document.createElement('img');
                img.src = anime.images[0];
                img.alt = anime.title;

                const title = document.createElement('h3');
                title.textContent = anime.title;

                const details = document.createElement('p');
                details.innerHTML = `
                    <strong>Тип:</strong> ${anime.type || 'Неизвестно'}<br>
                    <strong>Сезонов:</strong> ${anime.seasons || 'Неизвестно'}<br>
                    <strong>Рейтинг:</strong> ${anime.rating || 'Неизвестно'}
                `;

                card.appendChild(img);
                card.appendChild(title);
                card.appendChild(details);

                container.appendChild(card);
            });
        })
        .catch(error => {
            console.error('Error loading similar anime:', error);
            const container = document.querySelector('.similar-anime-cards');
            container.textContent = 'Ошибка загрузки похожих аниме.';
        });
}

document.addEventListener('DOMContentLoaded', () => {
    const favoriteButton = document.querySelector('.favorite-btn');

    if (favoriteButton) {
        favoriteButton.addEventListener('click', async () => {
            const animeTitle = favoriteButton.dataset.animeTitle;

            try {
                const response = await fetch('/api/add-to-favorites', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ animeTitle: animeTitle })
                });

                const result = await response.json();

                if (response.ok) {
                    Toastify({
                        text: result.message || 'Аниме успешно добавлено в избранное!',
                        className: 'toastify-success',
                        duration: 3000
                    }).showToast();

                } else {
                    Toastify({
                        text: result.message || 'Ошибка при добавлении в избранное',
                        className: 'toastify-error',
                        duration: 3000
                    }).showToast();
                }


            } catch (error) {
                console.error('Ошибка:', error);
                Toastify({
                    text: 'Произошла ошибка при отправке запроса',
                    className: 'toastify-error',
                    duration: 3000
                }).showToast();
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const submitReviewButton = document.querySelector('.submit-review');

    if (submitReviewButton) {
        submitReviewButton.addEventListener('click', async (event) => {
            const animeId = event.target.dataset.animeId;
            const reviewText = document.getElementById('review-text').value;

            if (reviewText.trim() === '') {
                Toastify({
                    text: 'Пожалуйста, напишите отзыв.',
                    className: 'toastify-warning',
                    duration: 3000
                }).showToast();
                return;
            }

            try {
                const response = await fetch('/api/add-review', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ animeId: animeId, text: reviewText })
                });

                if (response.ok) {
                    window.location.reload();
                } else {
                    const data = await response.json();
                    Toastify({
                        text: `Ошибка: ${data.message || 'Не удалось добавить отзыв'}`,
                        className: 'toastify-error',
                        duration: 3000
                    }).showToast();
                }
            } catch (error) {
                console.error('Ошибка при отправке отзыва:', error);
                Toastify({
                    text: 'Произошла ошибка при отправке отзыва.',
                    className: 'toastify-error',
                    duration: 3000
                }).showToast();
            }
        });
    }
});