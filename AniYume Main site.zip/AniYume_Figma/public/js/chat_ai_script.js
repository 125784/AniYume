document.addEventListener('DOMContentLoaded', () => {
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const chatBody = document.getElementById('chat-body');
    const imageInput = document.getElementById('image-input');
    const messageSound = document.getElementById('message-sound');
    const loadingIndicator = document.querySelector('.loading-indicator');
    const sidebar = document.getElementById('right-sidebar');
    const sidebarToggleButton = document.getElementById('sidebar-toggle-button');
    const sidebarContent = document.querySelector('.right-sidebar .sidebar-content');
    const characterSelect = document.getElementById('character-select');
    const characterImage = document.getElementById('character-image');
    const characterName = document.querySelector('#character-details h4');
    const characterBio = document.getElementById('character-bio');
    const characterAnimeLinkDiv = document.getElementById('character-anime-link');

    // ===== Голосовой ввод =====
    const voiceInputButton = document.getElementById('voice-input-button');
    let recognition;
    let isVoiceRecording = false;

    if ('webkitSpeechRecognition' in window) {
        recognition = new webkitSpeechRecognition();
    } else if ('SpeechRecognition' in window) {
        recognition = new SpeechRecognition();
    } else {
        console.error('Speech Recognition API не поддерживается!');
        voiceInputButton.disabled = true;
    }

    const visualizerCanvas = document.getElementById('visualizer');
    const visualizerContext = visualizerCanvas.getContext('2d');
    let audioContext;
    let analyser;
    let microphone;

    function initVisualizer() {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 256;
        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                microphone = audioContext.createMediaStreamSource(stream);
                microphone.connect(analyser);
                analyser.connect(audioContext.destination);
                visualize(dataArray, bufferLength);
            })
            .catch(err => {
                console.error('Ошибка при получении доступа к микрофону:', err);
            });
    }

    function visualize(dataArray, bufferLength) {
        visualizerContext.clearRect(0, 0, visualizerCanvas.width, visualizerCanvas.height);
        analyser.getByteTimeDomainData(dataArray);

        visualizerContext.fillStyle = 'rgb(200, 200, 200)';
        visualizerContext.fillRect(0, 0, visualizerCanvas.width, visualizerCanvas.height);
        visualizerContext.lineWidth = 2;
        visualizerContext.strokeStyle = 'rgb(0, 0, 0)';
        visualizerContext.beginPath();

        const sliceWidth = visualizerCanvas.width * 1.0 / bufferLength;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
            const v = dataArray[i] / 128.0;
            const y = v * visualizerCanvas.height / 2;
            if (i === 0) visualizerContext.moveTo(x, y);
            else visualizerContext.lineTo(x, y);
            x += sliceWidth;
        }
        visualizerContext.lineTo(visualizerCanvas.width, visualizerCanvas.height / 2);
        visualizerContext.stroke();

        if (isVoiceRecording) {
            requestAnimationFrame(() => visualize(dataArray, bufferLength));
        } else {
            visualizerContext.clearRect(0, 0, visualizerCanvas.width, visualizerCanvas.height);
        }
    }

    if (recognition) {
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = 'ru-RU';
        initVisualizer();

        recognition.onresult = (event) => {
            let finalTranscript = '';
            let interimTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                } else {
                    interimTranscript += event.results[i][0].transcript;
                }
            }
            messageInput.value = finalTranscript + interimTranscript;
        };

        recognition.onerror = (event) => {
            console.error('Ошибка распознавания:', event.error);
            messageInput.value = 'Произошла ошибка при распознавании голоса.';
        };

        recognition.onstart = () => {
            isVoiceRecording = true;
            voiceInputButton.classList.add('recording');
            voiceInputButton.innerHTML = '<i class="fas fa-microphone-slash"></i> Остановить';
            visualizerCanvas.style.display = 'block';
        };

        recognition.onend = () => {
            isVoiceRecording = false;
            voiceInputButton.classList.remove('recording');
            voiceInputButton.innerHTML = '<i class="fas fa-microphone"></i> Голосовой ввод';
            visualizerCanvas.style.display = 'none';
        };

        voiceInputButton.addEventListener('click', () => {
            if (isVoiceRecording) stopVoiceRecording();
            else startVoiceRecording();
        });
    }

    function stopVoiceRecording() {
        if (recognition) recognition.stop();
        visualizerCanvas.style.display = 'none';
    }

    function startVoiceRecording() {
        messageInput.value = '';
        visualizerCanvas.style.display = 'block';
        if (recognition) recognition.start();
    }

    // ===== Управление чатом =====
    let isSidebarOpen = true;
    const initialMessages = window.__initialMessages || [];
    const userName = window.__userName || 'пользователь';
    let messages = initialMessages;

    function renderMessages() {
        chatBody.innerHTML = '';

        // Всегда добавляем приветственное сообщение
        const welcomeMessageDiv = document.createElement('div');
        welcomeMessageDiv.classList.add('message', 'bot-message', 'welcome-message');
        welcomeMessageDiv.innerHTML = `<p>Привет, ${userName}! Как прошёл твой день?</p>`;
        chatBody.appendChild(welcomeMessageDiv);

        // Затем все остальные сообщения
        messages.forEach(message => {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', message.sender === 'user' ? 'user-message' : 'bot-message');

            if (message.type === 'text') {
                messageDiv.innerHTML = `<p>${message.content}</p>`;
            } else if (message.type === 'image') {
                const img = document.createElement('img');
                img.src = message.content;
                img.alt = 'Uploaded Image';
                messageDiv.appendChild(img);
            }
            chatBody.appendChild(messageDiv);
        });

        scrollToBottom();
    }

    function scrollToBottom() {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') sendMessage();
    });

    function sendMessage() {
        if (isVoiceRecording) stopVoiceRecording();

        const messageText = messageInput.value.trim();
        if (!messageText) return;

        addMessage('user', 'text', messageText);
        showLoadingIndicator();

        fetch('/api/chat_ai', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: messageText })
        })
            .then(response => response.json())
            .then(data => {
                setTimeout(() => {
                    addMessage('bot', 'text', data.response);
                    playMessageSound();
                }, 3000);
            })
            .catch(error => {
                console.error('Ошибка:', error);
                setTimeout(() => {
                    addMessage('bot', 'text', 'Произошла ошибка при обработке запроса.');
                    playMessageSound();
                }, 3000);
            })
            .finally(() => {
                hideLoadingIndicator();
                messageInput.value = '';
            });
    }

    function addMessage(sender, type, content) {
        messages.push({ sender, type, content });
        renderMessages();
    }

    function playMessageSound() {
        if (messageSound) {
            messageSound.currentTime = 0;
            messageSound.play();
        }
    }

    imageInput.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => addMessage('user', 'image', e.target.result);
            reader.readAsDataURL(file);
        }
    });

    function showLoadingIndicator() {
        loadingIndicator.style.display = 'block';
    }

    function hideLoadingIndicator() {
        loadingIndicator.style.display = 'none';
    }

    // ===== Сайдбар и персонажи =====
    sidebarToggleButton.addEventListener('click', () => {
        isSidebarOpen = !isSidebarOpen;
        sidebar.classList.toggle('open', isSidebarOpen);
        sidebarContent.style.display = isSidebarOpen ? 'block' : 'none';
        sidebarToggleButton.textContent = isSidebarOpen ? '←' : '→';
        sidebarToggleButton.style.left = isSidebarOpen ? '-40px' : '-40px';
    });

    const loadCharacters = async () => {
        const characters = [
            { id: '1', name: 'Наруто Узумаки', image: 'https://i.ibb.co/d4WFvxtP/naruto.jpg', bio: 'Наруто Узумаки - главный герой манги и аниме "Наруто". Он сирота, мечтающий стать Хокаге, сильнейшим ниндзя своей деревни...', anime: { title: 'Наруто', link: '/anime/naruto' } },
            { id: '2', name: 'Леви Аккерман', image: 'https://i.ibb.co/h9r7Y3Z/levi.jpg', bio: 'Капрал Леви Аккерман - один из сильнейших бойцов человечества в аниме "Атака титанов". Он известен своим холодным нравом и невероятными боевыми навыками...', anime: { title: 'Атака титанов', link: '/anime/attack-on-titan' } },
            { id: '3', name: 'Рем', image: 'https://i.ibb.co/F8HwS5J/rem.jpg', bio: 'Рем - одна из главных героинь аниме "Re:Zero. Жизнь с нуля в альтернативном мире". Она является демонической горничной и верной служанкой в особняке Роскваля...', anime: { title: 'Re:Zero', link: '/anime/re-zero' } },
            { id: '4', name: 'Гоку', image: 'https://i.ibb.co/s6QJ0hW/gokku.jpg', bio: 'Сон Гоку - главный герой франшизы "Жемчуг дракона". Он является одним из сильнейших бойцов во вселенной и защищает Землю от бесчисленных угроз...', anime: { title: 'Жемчуг дракона', link: '/anime/dragon-ball' } },
            { id: '5', name: 'Саске Учиха', image: 'https://i.ibb.co/J9k111K/sasuke.jpg', bio: 'Саске Учиха - один из главных персонажей аниме и манги "Наруто". Сын главы клана Учиха, Итачи Учиха, и внук Мадары Учиха...', anime: { title: 'Наруто', link: '/anime/naruto' } },
        ];

        characterSelect.innerHTML = '<option value="">-- Выберите персонажа --</option>';
        characters.forEach(char => {
            const option = document.createElement('option');
            option.value = char.id;
            option.textContent = char.name;
            characterSelect.appendChild(option);
        });

        if (characters.length > 0) {
            displayCharacterDetails(characters[0]);
            characterSelect.value = characters[0].id;
        } else {
            document.getElementById('character-details').style.display = 'none';
        }
    };

    const displayCharacterDetails = (character) => {
        if (character) {
            characterImage.src = character.image;
            characterImage.alt = `Фото ${character.name}`;
            characterName.textContent = character.name;
            characterBio.textContent = character.bio;

            const animeLink = document.createElement('a');
            animeLink.href = character.anime.link;
            animeLink.classList.add('anime-link');
            animeLink.textContent = character.anime.title;

            characterAnimeLinkDiv.innerHTML = 'Из аниме: ';
            characterAnimeLinkDiv.appendChild(animeLink);
            document.getElementById('character-details').style.display = 'block';
        } else {
            document.getElementById('character-details').style.display = 'none';
            characterImage.src = 'https://i.ibb.co/cXXVRn0D/chat-ai.jpg';
            characterName.textContent = 'Имя персонажа';
            characterBio.textContent = 'Выберите персонажа, чтобы увидеть его биографию.';
            characterAnimeLinkDiv.innerHTML = 'Из аниме: <a href="#" class="anime-link">Название аниме</a>';
        }
    };

    characterSelect.addEventListener('change', async (event) => {
        const characterId = event.target.value;
        if (characterId) {
            const characters = [
                { id: '1', name: 'Наруто Узумаки', image: 'https://i.ibb.co/d4WFvxtP/naruto.jpg', bio: 'Наруто Узумаки - главный герой манги и аниме "Наруто". Он сирота, мечтающий стать Хокаге, сильнейшим ниндзя своей деревни...', anime: { title: 'Наруто', link: '/anime/naruto' } },
                { id: '2', name: 'Леви Аккерман', image: 'https://i.ibb.co/h9r7Y3Z/levi.jpg', bio: 'Капрал Леви Аккерман - один из сильнейших бойцов человечества в аниме "Атака титанов". Он известен своим холодным нравом и невероятными боевыми навыками...', anime: { title: 'Атака титанов', link: '/anime/attack-on-titan' } },
                { id: '3', name: 'Рем', image: 'https://i.ibb.co/F8HwS5J/rem.jpg', bio: 'Рем - одна из главных героинь аниме "Re:Zero. Жизнь с нуля в альтернативном мире". Она является демонической горничной и верной служанкой в особняке Роскваля...', anime: { title: 'Re:Zero', link: '/anime/re-zero' } },
                { id: '4', name: 'Гоку', image: 'https://i.ibb.co/s6QJ0hW/gokku.jpg', bio: 'Сон Гоку - главный герой франшизы "Жемчуг дракона". Он является одним из сильнейших бойцов во вселенной и защищает Землю от бесчисленных угроз...', anime: { title: 'Жемчуг дракона', link: '/anime/dragon-ball' } },
                { id: '5', name: 'Саске Учиха', image: 'https://i.ibb.co/J9k111K/sasuke.jpg', bio: 'Саске Учиха - один из главных персонажей аниме и манги "Наруто". Сын главы клана Учиха, Итачи Учиха, и внук Мадары Учиха...', anime: { title: 'Наруто', link: '/anime/naruto' } },
            ];
            const selectedCharacter = characters.find(char => char.id === characterId);
            displayCharacterDetails(selectedCharacter);
        } else {
            displayCharacterDetails(null);
        }
    });

    // ===== Инициализация страницы =====
    loadCharacters();
    if (!isSidebarOpen) {
        sidebar.classList.remove('open');
        sidebarContent.style.display = 'none';
        sidebarToggleButton.textContent = '→';
    } else {
        sidebar.classList.add('open');
        sidebarContent.style.display = 'block';
        sidebarToggleButton.textContent = '←';
    }

    renderMessages(); // отображаем приветствие и историю
});

// ===== Тема =====
document.addEventListener('DOMContentLoaded', function() {
    const themeSelector = document.getElementById('theme-selector');
    const chatContainer = document.querySelector('.chat-container');

    themeSelector.addEventListener('click', (event) => {
        if (event.target.tagName === 'BUTTON') {
            const theme = event.target.dataset.theme;
            chatContainer.className = `chat-container ${theme}`;
            const sound = document.getElementById('message-sound');
            if (sound) {
                sound.currentTime = 0;
                sound.play();
            }
        }
    });
});