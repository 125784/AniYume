document.addEventListener('DOMContentLoaded', () => {
    function toggleElementVisibility(buttonId, elementClass, hiddenClass) {
        const button = document.getElementById(buttonId);
        const element = document.querySelector(elementClass);

        button.addEventListener('click', () => {
            element.classList.toggle(hiddenClass);
            const isHidden = element.classList.contains(hiddenClass);
            let buttonText = '';

            if (buttonId === 'toggle-top-toolbar') {
                buttonText = isHidden ? '↓' : '↑';
            } else if (buttonId === 'toggle-right-sidebar') {
                buttonText = isHidden ? '→' : '←';
            } else if (buttonId === 'toggle-bottom-toolbar') {
                buttonText = isHidden ? '↑' : '↓';
            }

            button.textContent = buttonText;
        });
    }

    toggleElementVisibility('toggle-top-toolbar', '.top-toolbar', 'hidden-top');
    toggleElementVisibility('toggle-right-sidebar', '.right-sidebar', 'hidden');
    toggleElementVisibility('toggle-bottom-toolbar', '.bottom-toolbar', 'hidden-bottom');
});

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('drawing-canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = window.innerWidth * 0.8;
    canvas.height = window.innerHeight * 0.8;

    let isDrawing = false;
    let currentTool = 'pencil';
    let lineWidth = 5;
    let lineColor = '#000000';
    let opacity = 1;
    let smoothing = true;
    let isSelecting = false;
    let isMoving = false;
    let startX, startY, endX, endY;
    let selectedArea = null;
    let offsetX, offsetY;
    let eraserSize = 20;
    let eraserShape = 'circle';
    let eraserHardness = 1;
    let isDrawingLine = false;
    let isErasing = false;
    let objects = [];

    let history = [];
    let historyIndex = -1;

    function saveState() {
        historyIndex++;
        if (historyIndex < history.length) {
            history = history.slice(0, historyIndex);
        }
        history.push(canvas.toDataURL());
    }

    function restoreState(step = 0) {
        historyIndex += step;
        if (historyIndex < 0) {
            historyIndex = -1;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            return;
        } else if (historyIndex >= history.length) {
            historyIndex = history.length - 1;
        }
        const img = new Image();
        img.src = history[historyIndex];
        img.onload = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0);
        };
    }

    function resetCanvasSettings() {
        ctx.globalCompositeOperation = 'source-over';
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = lineColor;
        ctx.fillStyle = 'transparent';
    }

    document.querySelectorAll('.right-sidebar button').forEach(button => {
        button.addEventListener('click', () => {
            if (isTextInputActive && currentText.trim() !== '') {
                objects.push({
                    type: 'text',
                    x: textStartX,
                    y: textStartY,
                    text: currentText,
                    options: currentTextOptions
                });
                isTextInputActive = false;
                drawAllObjects();
            }
            
            currentTool = button.id;
            resetSelection();
            resetCanvasSettings();
            selectedShape = null;
            hideOpacityControls();
            hideTextControls();
            hideBlurSettings();
        });
    });

    document.getElementById('reset').addEventListener('click', () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        saveState();
    });

    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUp);

    function getMousePosition(e) {
        const rect = canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }

    let draggedObject = null;
    let originalSelection = null;    
    
    function handleMouseDown(e) {
        const pos = getMousePosition(e);

        if (currentTool === 'drag') {
            if (selectedArea && isPointInSelection(pos.x, pos.y)) {
                isMoving = true;
                draggedObject = {
                    type: 'selection',
                    startX: Math.min(startX, endX),
                    startY: Math.min(startY, endY),
                    width: Math.abs(endX - startX),
                    height: Math.abs(endY - startY),
                    image: selectedArea,
                    x: Math.min(startX, endX),
                    y: Math.min(startY, endY)
                };
                originalSelection = { ...draggedObject };

                offsetX = pos.x - draggedObject.x;
                offsetY = pos.y - draggedObject.y;
            } else {
                isSelecting = true;
                startX = pos.x;
                startY = pos.y;
            }
        } else if (currentTool === 'pencil') {
            startDrawing(pos);
        } else if (currentTool === 'minus') {
            isDrawingLine = true;
            [lineStartX, lineStartY] = [pos.x, pos.y];
        } else if (currentTool === 'eraser') {
            isErasing = true;
            erase(pos);
        } else if (currentTool === 'add-text') {
            const clickedTextIndex = getTextAtPosition(pos.x, pos.y);
            if (clickedTextIndex !== null) {
                selectedTextIndex = clickedTextIndex;
                currentTextOptions = { ...objects[selectedTextIndex].options };
                isTextInputActive = true;
                isDragging = true;
                dragOffsetX = pos.x - objects[selectedTextIndex].x;
                dragOffsetY = pos.y - objects[selectedTextIndex].y;
                return;
            }
            createNewText(pos.x, pos.y);
        } else if (currentTool === 'blur') {
            isBlurring = true;
            applyEffect(pos);
        }
    }

    function handleMouseMove(e) {
        const pos = getMousePosition(e);

        if (isSelecting) {
            updateSelection(pos);
        } else if (isMoving && draggedObject && draggedObject.type === 'selection') {
            moveSelection(pos);
        } else if (isDragging && selectedTextIndex !== null) {
            objects[selectedTextIndex].x = pos.x - dragOffsetX;
            objects[selectedTextIndex].y = pos.y - dragOffsetY;
            drawAllObjects();
        } else if (isDrawing) {
            drawPencil(pos);
        } else if (isErasing) {
            erase(pos);
        } else if (isBlurring) {
            applyEffect(pos);
        }
    }

    function handleMouseUp() {
        if (isSelecting) {
            finalizeSelection();
        } else if (isMoving) {
            finalizeMove();
        } else if (isDrawing) {
            stopDrawing();
        } else if (isDrawingLine) {
            finalizeLine();
        } else if (isErasing) {
            isErasing = false;
        } else if (isBlurring) {
            isBlurring = false;
            saveState();
        } else if (!draggedObject) return;

        const newX = pos.x - offsetX;
        const newY = pos.y - offsetY;

        draggedObject.x = newX;
        draggedObject.y = newY;

        redrawCanvas();
    
        saveState();
        isDragging = false;
    }
    
    function startDrawing(pos) {
        isDrawing = true;
        ctx.beginPath();
        applyDrawingStyles();
        ctx.moveTo(pos.x, pos.y);
    }

    function drawPencil(pos) {
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();
    }

    function stopDrawing() {
        isDrawing = false;
        ctx.closePath();
        saveState();
    }

    function finalizeLine() {
        const pos = getMousePosition(event);
        drawStraightLine(lineStartX, lineStartY, pos.x, pos.y);
        isDrawingLine = false;
    }

    function drawStraightLine(x1, y1, x2, y2) {
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        applyDrawingStyles();
        ctx.stroke();
        ctx.closePath();
        saveState();
    }

    function updateSelection(pos) {
        endX = pos.x;
        endY = pos.y;
        redrawCanvas();
        drawSelectionRectangle(startX, startY, endX, endY);
    }

    function finalizeSelection() {
        isSelecting = false;

        const width = Math.abs(endX - startX);
        const height = Math.abs(endY - startY);
        const selectionX = Math.min(startX, endX);
        const selectionY = Math.min(startY, endY);

        if (width > 0 && height > 0) {
            selectedArea = createImageFromSelection(selectionX, selectionY, width, height);
            ctx.clearRect(selectionX, selectionY, width, height);
            saveState();
        } else {
            resetSelection();
        }
    }

    function moveSelection(pos) {
        if (!draggedObject) return;

        const newX = pos.x - offsetX;
        const newY = pos.y - offsetY;

        draggedObject.x = newX;
        draggedObject.y = newY;

        redrawCanvas();
    }

    function finalizeMove() {
        isMoving = false;

        if (draggedObject && draggedObject.type === 'selection') {
            startX = draggedObject.x;
            startY = draggedObject.y;
            endX = draggedObject.x + draggedObject.width;
            endY = draggedObject.y + draggedObject.height;
            selectedArea = draggedObject.image;

            draggedObject = null;
            originalSelection = null;

            saveState();
            redrawCanvas();
        }
    }

    function resetSelection() {
        isSelecting = false;
        isMoving = false;
        selectedArea = null;
        startX = startY = endX = endY = null;
        draggedObject = null;
        originalSelection = null;
        redrawCanvas();
    }

    function redrawCanvas() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        if (historyIndex >= 0) {
            const img = new Image();
            img.src = history[historyIndex];
            img.onload = () => {
                ctx.drawImage(img, 0, 0);

                if (isMoving && draggedObject && draggedObject.type === 'selection') {
                    ctx.drawImage(draggedObject.image, draggedObject.x, draggedObject.y);
                }
                drawAllObjects();
            };
        } else {
            if (isMoving && draggedObject && draggedObject.type === 'selection') {
                ctx.drawImage(draggedObject.image, draggedObject.x, draggedObject.y);
            }
            drawAllObjects();
        }
        
        layers.forEach(layer => {
            if (layer.visible) {
                layer.ctx.globalAlpha = layer.opacity;
                ctx.drawImage(layer.canvas, 0, 0);
            }
        });
    }

    function createImageFromSelection(x, y, width, height) {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = width;
        tempCanvas.height = height;
        const tempCtx = tempCanvas.getContext('2d');
        tempCtx.drawImage(canvas, x, y, width, height, 0, 0, width, height);
        return tempCanvas;
    }

    function isPointInSelection(x, y) {
        if (!startX || !startY || !endX || !endY) return false;

        const selectionX = Math.min(startX, endX);
        const selectionY = Math.min(startY, endY);
        const width = Math.abs(endX - startX);
        const height = Math.abs(endY - startY);

        return (
            x >= selectionX &&
            x <= selectionX + width &&
            y >= selectionY &&
            y <= selectionY + height
        );
    }

    function drawSelectionRectangle(x1, y1, x2, y2) {
        ctx.lineWidth = 2;
        ctx.strokeRect(
            Math.min(x1, x2),
            Math.min(y1, y2),
            Math.abs(x2 - x1),
            Math.abs(y2 - y1)
        );
    }

    const colorPicker = document.getElementById('color-picker');
    const paletteButton = document.getElementById('palette');

    paletteButton.addEventListener('click', () => {
        colorPicker.style.display = 'block';
        colorPicker.click();
        colorPicker.style.display = 'none';
    });

    colorPicker.addEventListener('input', (e) => {
        const selectedColor = e.target.value;
        setLineColor(selectedColor);
    });

    function setLineColor(color) {
        lineColor = color;
    }
    
    function setLineWidth(value) {
        lineWidth = value;
        ctx.lineWidth = lineWidth;
    }

    function applyDrawingStyles() {
        ctx.strokeStyle = lineColor;
        ctx.lineWidth = lineWidth;
        ctx.globalAlpha = opacity;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.imageSmoothingEnabled = smoothing;
    }

    const scaleControl = document.querySelector('.scale-control input');
    if (scaleControl) {
        scaleControl.addEventListener('input', (e) => {
            const scale = e.target.value / 100;
            canvas.style.transform = `scale(${scale})`;
        });
    }

    document.getElementById('undo').addEventListener('click', () => restoreState(-1));
    document.getElementById('redo').addEventListener('click', () => restoreState(1));

    const thicknessContainer = document.createElement('div');
    thicknessContainer.style.position = 'absolute';
    thicknessContainer.style.top = '10px';
    thicknessContainer.style.right = '10px';
    thicknessContainer.style.display = 'none';
    thicknessContainer.style.border = '1px solid #ccc';
    thicknessContainer.style.padding = '10px';
    thicknessContainer.style.backgroundColor = '#fff';
    thicknessContainer.style.zIndex = '1000';

    const thicknessInput = document.createElement('input');
    thicknessInput.type = 'range';
    thicknessInput.min = '1';
    thicknessInput.max = '50';
    thicknessInput.value = lineWidth;
    thicknessInput.style.width = '200px';

    const thicknessValue = document.createElement('span');
    thicknessValue.textContent = `Толщина: ${thicknessInput.value}`;
    thicknessValue.style.display = 'block';
    thicknessValue.style.marginTop = '10px';

    thicknessInput.addEventListener('input', () => {
        const value = parseInt(thicknessInput.value);
        setLineWidth(value);
        thicknessValue.textContent = `Толщина: ${value}`;
    });

    const closeThicknessButton = document.createElement('button');
    closeThicknessButton.textContent = 'Закрыть';
    closeThicknessButton.style.marginTop = '10px';
    closeThicknessButton.addEventListener('click', () => {
        thicknessContainer.style.display = 'none';
    });

    thicknessContainer.appendChild(thicknessInput);
    thicknessContainer.appendChild(thicknessValue);
    thicknessContainer.appendChild(closeThicknessButton);
    document.body.appendChild(thicknessContainer);

    document.getElementById('text-width').addEventListener('click', () => {
        thicknessContainer.style.display = 'block';
    });
    
    let isSettingsVisible = false;
    
    function toggleEraserSettings() {
        const settingsContainer = document.getElementById('eraser-settings');
        if (isSettingsVisible) {
            settingsContainer.style.display = 'none';
        } else {
            settingsContainer.style.display = 'block';
        }
        isSettingsVisible = !isSettingsVisible;
    }
    
    document.getElementById('eraser').addEventListener('click', () => {
        currentTool = 'eraser';
        resetCanvasSettings();
        toggleEraserSettings();
    });

    document.getElementById('close-settings').addEventListener('click', () => {
        const settingsContainer = document.getElementById('eraser-settings');

        if (currentTool === 'eraser') {
            saveState();
        }

        settingsContainer.style.display = 'none';
        isSettingsVisible = false;
        currentTool = null;
    });
    
    document.getElementById('eraser-size').addEventListener('input', (e) => {
        eraserSize = parseInt(e.target.value);
    });
    document.getElementById('eraser-shape').addEventListener('change', (e) => {
        eraserShape = e.target.value;
    });
    document.getElementById('eraser-hardness').addEventListener('input', (e) => {
        eraserHardness = parseFloat(e.target.value);
    });
    
    function erase(pos) {
        if (currentTool !== 'eraser') return;

        ctx.save();

        if (eraserShape === 'circle') {
            const radius = eraserSize / 2;
            ctx.beginPath();
            ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2);
    
            if (eraserHardness < 1) {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.fillStyle = `rgba(0, 0, 0, ${1 - eraserHardness})`;
                ctx.fill();
            } else {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.fill();
            }
        } else if (eraserShape === 'square') {
            const halfSize = eraserSize / 2;
            ctx.clearRect(pos.x - halfSize, pos.y - halfSize, eraserSize, eraserSize);
        }
        ctx.restore();
        saveState();
    }

    let selectedShape = null;
    let shapeSize = 50;
    let shapeColor = '#000000';

    document.getElementById('shapes').addEventListener('click', () => {
        const panel = document.getElementById('shapes-panel');
        panel.classList.toggle('hidden');
    });

    document.getElementById('close-shapes-panel').addEventListener('click', () => {
        const panel = document.getElementById('shapes-panel');
        panel.classList.add('hidden');
    });

    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));

            tab.classList.add('active');
            const target = tab.getAttribute('data-tab');
            document.getElementById(`tab-${target}`).classList.remove('hidden');
        });
    });

    document.querySelectorAll('.shape-item').forEach(item => {
        item.addEventListener('click', () => {
            selectedShape = item.getAttribute('data-shape');
        });
    });

    document.getElementById('shape-size').addEventListener('input', (e) => {
        shapeSize = parseInt(e.target.value);
    });

    document.getElementById('shape-color').addEventListener('input', (e) => {
        shapeColor = e.target.value;
    });

    canvas.addEventListener('click', (e) => {
        if (!selectedShape) return;

        const pos = getMousePosition(e);

        ctx.save();
        ctx.fillStyle = shapeColor;

        switch (selectedShape) {
            case 'circle':
                ctx.beginPath();
                ctx.arc(pos.x, pos.y, shapeSize / 2, 0, Math.PI * 2);
                ctx.fill();
                break;
            case 'square':
                ctx.fillRect(pos.x - shapeSize / 2, pos.y - shapeSize / 2, shapeSize, shapeSize);
                break;
            case 'triangle':
                const height = shapeSize;
                const width = shapeSize * 0.8;
                ctx.beginPath();
                ctx.moveTo(pos.x, pos.y - height / 2);
                ctx.lineTo(pos.x - width / 2, pos.y + height / 2);
                ctx.lineTo(pos.x + width / 2, pos.y + height / 2);
                ctx.closePath();
                ctx.fill();
                break;
            case 'star':
                drawStar(ctx, pos.x, pos.y, shapeSize / 2, 5);
                break;
            case 'anime-eye':
                drawAnimeEye(ctx, pos.x, pos.y, shapeSize);
                break;
            case 'anime-mouth':
                drawAnimeMouth(ctx, pos.x, pos.y, shapeSize);
                break;
            case 'anime-hair':
                drawAnimeHair(ctx, pos.x, pos.y, shapeSize);
                break;
        }

        ctx.restore();
        saveState(); 
    });

    function drawStar(ctx, x, y, radius, spikes) {
        const rot = Math.PI / 2 * 3;
        const step = 2*Math.PI / spikes;

        ctx.beginPath();
        ctx.moveTo(x, y - radius);
        for (let i = 0; i < spikes; i++) {
            const x1 = x + Math.cos(rot + i * step) * radius;
            const y1 = y + Math.sin(rot + i * step) * radius;
            ctx.lineTo(x1, y1);
            const x2 = x + Math.cos(rot + (i + 0.5) * step) * (radius / 2);
            const y2 = y + Math.sin(rot + (i + 0.5) * step) * (radius / 2);
            ctx.lineTo(x2, y2);
        }
        ctx.closePath();
        ctx.fill();
    }

    function drawAnimeEye(ctx, x, y, size) {
        ctx.beginPath();
        ctx.arc(x, y, size / 2, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(x + size / 4, y - size / 4, size / 8, 0, Math.PI * 2);
        ctx.fillStyle = '#000000';
        ctx.fill();
    }

    function drawAnimeMouth(ctx, x, y, size) {
        ctx.beginPath();
        ctx.arc(x, y, size / 2, 0, Math.PI);
        ctx.stroke();
    }

    function drawAnimeHair(ctx, x, y, size) {
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.quadraticCurveTo(x - size / 2, y - size, x, y - size);
        ctx.quadraticCurveTo(x + size / 2, y - size, x, y);
        ctx.closePath();
        ctx.fillStyle = '#000000';
        ctx.fill();
    }

    let selectedTextIndex = null;
    let isDragging = false;
    let dragOffsetX = 0;
    let dragOffsetY = 0;

    const defaultTextOptions = {
        font: 'Arial',
        size: 20,
        color: 'black',
        textAlign: 'left',
        strokeColor: 'none',
        strokeWidth: 0,
        shadowColor: 'none',
        shadowOffsetX: 0,
        shadowOffsetY: 0,
        shadowBlur: 0
    };

    let isTextInputActive = false;
    let textStartX;
    let textStartY;
    let currentText = '';
    let currentTextOptions = {
        font: document.getElementById('font-select').value,
        size: parseInt(document.getElementById('font-size').value, 10),
        color: document.getElementById('text-color').value,
        ...defaultTextOptions
    };
    let globalTextOptions = {
        font: 'Arial',
        size: 20,
        color: 'black',
        ...defaultTextOptions
    };

    document.getElementById('add-text').addEventListener('click', () => {
        currentTool = 'add-text';
        showTextControls(); 
    });

    function showTextControls() {
        const controls = document.getElementById('text-controls');
        controls.style.display = 'block';
    }

    function hideTextControls() {
        const controls = document.getElementById('text-controls');
        controls.style.display = 'none';
    }
    
    canvas.addEventListener('click', (event) => {
        if (currentTool === 'add-text') {
            const rect = canvas.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            createNewText(x, y);
        } else {
            const clickedTextIndex = getTextAtPosition(event.offsetX, event.offsetY);
            if (clickedTextIndex !== null) {
                selectedTextIndex = clickedTextIndex;
                globalTextOptions = { ...objects[selectedTextIndex].options };
                updateTextPropertiesUI();
            } else {
                selectedTextIndex = null;
            }
            drawAllObjects();
        }
    });

    function updateTextPropertiesUI(options) {
        document.getElementById('font-select').value = options.font; 
        document.getElementById('font-size').value = options.size; 
        document.getElementById('text-color').value = options.color; 
    }

    document.getElementById('font-select').addEventListener('change', (event) => {
        globalTextOptions.font = event.target.value;
        if (selectedTextIndex !== null) {
            objects[selectedTextIndex].options.font = event.target.value;
        }
        drawAllObjects();
    });

    document.getElementById('font-size').addEventListener('input', (event) => {
        globalTextOptions.size = parseInt(event.target.value, 10);
        if (selectedTextIndex !== null) {
            objects[selectedTextIndex].options.size = parseInt(event.target.value, 10);
        }
        drawAllObjects();
    });

    document.getElementById('text-color').addEventListener('input', (event) => {
        globalTextOptions.color = event.target.value;
        if (selectedTextIndex !== null) {
            objects[selectedTextIndex].options.color = event.target.value;
        }
        drawAllObjects();
    });

    function createNewText(x, y) {
        isTextInputActive = true;
        textStartX = x;
        textStartY = y;
        currentText = '';

        currentTextOptions = { ...globalTextOptions };

        drawAllObjects();
    }

    window.addEventListener('keydown', handleTextInput);

    function handleTextInput(event) {
        if (!isTextInputActive) return;
    
        if (event.key === 'Enter') {
            isTextInputActive = false;

            objects.push({
                type: 'text',
                x: textStartX,
                y: textStartY,
                text: currentText,
                options: currentTextOptions
            });

            drawAllObjects();
        } else if (event.key === 'Backspace') {
            currentText = currentText.slice(0, -1);
        } else if (event.key.length === 1) {
            currentText += event.key;
        }

        drawAllObjects();
        drawText(textStartX, textStartY, currentText, currentTextOptions);
    }

    function drawAllObjects() {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        tempCanvas.getContext('2d').drawImage(canvas, 0, 0);

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.drawImage(tempCanvas, 0, 0);

        objects.forEach((object, index) => {
            if (object.type === 'text') {
                drawText(object.x, object.y, object.text, object.options);

                if (index === selectedTextIndex) {
                    ctx.save();
                    ctx.strokeStyle = 'blue';
                    ctx.lineWidth = 2;
                    const textWidth = ctx.measureText(object.text).width;
                    const textHeight = parseInt(object.options.size, 10);
                    ctx.strokeRect(
                        object.x,
                        object.y - textHeight,
                        textWidth,
                        textHeight
                    );
                    ctx.restore();
                }
            }
        });
    }

    function drawText(x, y, text, options) {
        ctx.save();

        ctx.font = `${options.size}px ${options.font}`; 
        ctx.fillStyle = options.color; 
        ctx.textAlign = options.textAlign; 
        
        if (options.strokeColor !== 'none' && options.strokeWidth > 0) {
            ctx.strokeStyle = options.strokeColor;
            ctx.lineWidth = options.strokeWidth;
            ctx.strokeText(text, x, y);
        }

        ctx.fillText(text, x, y);
        ctx.restore();
    }

    function getTextAtPosition(x, y) {
        for (let i = objects.length - 1; i >= 0; i--) {
            const object = objects[i];
            if (object.type === 'text') {
                const textWidth = ctx.measureText(object.text).width;
                const textHeight = parseInt(object.options.size, 10);

                if (
                    x >= object.x &&
                    x <= object.x + textWidth &&
                    y >= object.y - textHeight &&
                    y <= object.y
                ) {
                    return i;
                }
            }
        }
        return null;
    }

    let backgroundImage = null; 
    
    document.getElementById('upload-image').addEventListener('click', () => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/jpeg, image/png, image/gif, image/bmp, image/tiff, image/webp';

        input.onchange = (e) => {
            const file = e.target.files[0];
            if (file) {
                loadImage(file);
                showOpacityControls();
            }
        };

        input.click();
    });

    canvas.addEventListener('paste', (e) => {
        const clipboardItems = e.clipboardData.items;
        for (const item of clipboardItems) {
            if (item.type.indexOf('image') !== -1) {
                const blob = item.getAsFile();
                loadImage(blob);
                showOpacityControls();
                break;
            }
        }
    });

    function loadImage(file) {
        const img = new Image();
        const url = URL.createObjectURL(file);

        img.onload = () => {
            backgroundImage = img;
            drawBackgroundImage();
            URL.revokeObjectURL(url);
        };

        img.src = url;
    }

    function drawBackgroundImage() {
        if (backgroundImage) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);
            saveState();
        }
    }

    document.getElementById('opacity-slider').addEventListener('input', (e) => {
        const opacity = e.target.value / 100;
        ctx.globalAlpha = opacity;
        drawBackgroundImage();
    });

    function showOpacityControls() {
        const controls = document.getElementById('opacity-controls');
        controls.style.display = 'block';
    }

    function hideOpacityControls() {
        const controls = document.getElementById('opacity-controls');
        controls.style.display = 'none';
    }

    let isBlurring = false;
    let blurMode = 'blur';
    let blurIntensity = 10;
    let brushSize = 50;
    let brushHardness = 1;

    document.getElementById('blur-transparency').addEventListener('click', () => {
        currentTool = 'blur';
        resetCanvasSettings();
        document.getElementById('blur-transparency-settings').style.display = 'block';
    });

    function applyEffect(pos) {
        if (!isBlurring) return;

        ctx.save();

        const tempCanvas = document.createElement('canvas');
        const tempCtx = tempCanvas.getContext('2d');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;

        tempCtx.drawImage(canvas, 0, 0);

        const radius = brushSize / 2;

        ctx.beginPath();
        ctx.arc(pos.x, pos.y, radius, 0, Math.PI * 2, false);
        ctx.closePath();
        ctx.clip();

        if (blurMode === 'blur') {
            ctx.clearRect(pos.x - radius, pos.y - radius, brushSize, brushSize);
            ctx.filter = `blur(${blurIntensity}px)`;
            ctx.globalAlpha = brushHardness;
            ctx.drawImage(
                tempCanvas,
                pos.x - radius,
                pos.y - radius,
                brushSize,
                brushSize,
                pos.x - radius,
                pos.y - radius,
                brushSize,
                brushSize
            );
        } else if (blurMode === 'transparency') {
            const intensity = blurIntensity / 100;
            const imageData = tempCtx.getImageData(pos.x - radius, pos.y - radius, brushSize, brushSize);

            for (let y = 0; y < brushSize; y++) {
                for (let x = 0; x < brushSize; x++) {
                    const dx = x - radius;
                    const dy = y - radius;
                    const distance = Math.sqrt(dx * dx + dy * dy);

                    if (distance <= radius) {
                        const index = (y * brushSize + x) * 4 + 3;
                        imageData.data[index] = Math.max(0, imageData.data[index] - intensity * 255);
                    }
                }
            }

            ctx.putImageData(imageData, pos.x - radius, pos.y - radius);
        }

        ctx.restore();
    }

    document.getElementById('blur-mode').addEventListener('change', (e) => {
        blurMode = e.target.value;
    });

    document.getElementById('intensity').addEventListener('input', (e) => {
        blurIntensity = e.target.value;
    });

    document.getElementById('brush-size').addEventListener('input', (e) => {
        brushSize = e.target.value;
    });

    document.getElementById('brush-hardness').addEventListener('input', (e) => {
        brushHardness = e.target.value;
    });
    
    function hideBlurSettings() {
        document.getElementById('blur-transparency-settings').style.display = 'none';
        isBlurring = false;
    }
    
    document.getElementById('blur-transparency').addEventListener('click', () => {
        currentTool = 'blur';
        resetCanvasSettings();
        document.getElementById('settings-modal').style.display = 'block';
    });

    document.querySelector('.close-button').addEventListener('click', () => {
        document.getElementById('settings-modal').style.display = 'none';
        isBlurring = false;
    });

    async function sendCanvasToTrash() {
        try {
            const canvasData = canvas.toDataURL('image/png');
            const blob = await fetch(canvasData).then(res => res.blob());
            const file = new File([blob], 'canvas-image.png', { type: 'image/png' });

            const artTitle = document.getElementById('artTitle')?.value || 'Без названия';
            const artAuthor = document.getElementById('artAuthor')?.value || 'Неизвестный автор';
    
            const formData = new FormData();
            formData.append('image', file);
            formData.append('title', artTitle);
            formData.append('author', artAuthor);
      
            const response = await fetch('/send-to-trash', {
                method: 'POST',
                body: formData
            });
    
            if (!response.ok) {
                const errorMessage = await response.text();
                throw new Error(`Ошибка при отправке в корзину: ${response.status} - ${errorMessage}`);
            }

            const data = await response.json();

            console.log(data.message);
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            alert(data.message);
            loadTrashBin();
        } catch (error) {
            console.error('Ошибка сети:', error);
            alert('Ошибка сети при отправке в корзину: ' + error.message);
        }
    }

    let trashModal = null;
    
    async function showTrashBin() {
        if (trashModal) {
            return;
        }

        trashModal = document.createElement('div');
        trashModal.style.position = 'fixed';
        trashModal.style.top = '50%';
        trashModal.style.left = '50%';
        trashModal.style.transform = 'translate(-50%, -50%)';
        trashModal.style.width = '400px'; 
        trashModal.style.maxHeight = '80vh';
        trashModal.style.backgroundColor = '#fff';
        trashModal.style.borderRadius = '8px';
        trashModal.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.2)';
        trashModal.style.overflowY = 'auto';
        trashModal.style.padding = '20px';
        trashModal.style.zIndex = '1000';
        trashModal.style.fontFamily = 'Arial, sans-serif';

        const title = document.createElement('h3');
        title.textContent = 'Корзина';
        title.style.marginBottom = '20px';
        title.style.color = '#333';
        title.style.textAlign = 'center';
        trashModal.appendChild(title);

        const trashItemsContainer = document.createElement('div');
        trashItemsContainer.style.display = 'flex';
        trashItemsContainer.style.flexDirection = 'column';
        trashItemsContainer.style.gap = '10px';
        trashModal.appendChild(trashItemsContainer);

        const clearTrashButton = document.createElement('button');
        clearTrashButton.textContent = 'Очистить корзину';
        clearTrashButton.style.backgroundColor = '#ff4d4d';
        clearTrashButton.style.color = '#fff';
        clearTrashButton.style.border = 'none';
        clearTrashButton.style.borderRadius = '4px';
        clearTrashButton.style.padding = '10px';
        clearTrashButton.style.cursor = 'pointer';
        clearTrashButton.style.marginTop = '20px';
        clearTrashButton.onclick = clearTrashBin;
        trashModal.appendChild(clearTrashButton);

        const closeButton = document.createElement('button');
        closeButton.textContent = 'Закрыть';
        closeButton.style.backgroundColor = '#007bff';
        closeButton.style.color = '#fff';
        closeButton.style.border = 'none';
        closeButton.style.borderRadius = '4px';
        closeButton.style.padding = '10px';
        closeButton.style.marginLeft = '1%';
        closeButton.style.cursor = 'pointer';
        closeButton.style.marginTop = '10px';
        closeButton.onclick = closeTrashBin;
        trashModal.appendChild(closeButton);

        trashBin = await loadTrashBin();

        if (trashBin.length === 0) {
            const emptyMessage = document.createElement('p');
            emptyMessage.textContent = 'Корзина пуста.';
            emptyMessage.style.textAlign = 'center';
            emptyMessage.style.color = '#666';
            trashItemsContainer.appendChild(emptyMessage);
        } else {
            trashBin.forEach((item, index) => {
                const itemDiv = document.createElement('div');
                itemDiv.style.display = 'flex';
                itemDiv.style.alignItems = 'center';
                itemDiv.style.padding = '10px';
                itemDiv.style.border = '1px solid #ddd';
                itemDiv.style.borderRadius = '4px';
                itemDiv.style.backgroundColor = '#f9f9f9';

                const itemInfo = document.createElement('span');
                itemInfo.textContent = `${item.type} (${new Date(item.deletedAt).toLocaleString()})`;
                itemInfo.style.color = '#333';
                itemInfo.style.marginRight = '20px'; 
                itemDiv.appendChild(itemInfo);

                if (item.type === 'canvas') {
                    const preview = document.createElement('img');
                    preview.src = item.imageUrl;
                    preview.style.width = '80px'; 
                    preview.style.height = '80px'; 
                    preview.style.borderRadius = '4px';
                    preview.style.marginRight = '20px'; 
                    itemDiv.appendChild(preview);
                }

                const restoreButton = document.createElement('button');
                restoreButton.textContent = 'Восстановить';
                restoreButton.style.backgroundColor = '#28a745';
                restoreButton.style.color = '#fff';
                restoreButton.style.border = 'none';
                restoreButton.style.borderRadius = '4px';
                restoreButton.style.padding = '5px 10px';
                restoreButton.style.cursor = 'pointer';
                restoreButton.onclick = () => restoreFromTrashBin(item._id);
                itemDiv.appendChild(restoreButton);

                trashItemsContainer.appendChild(itemDiv);
            });
        }
        document.body.appendChild(trashModal);
    }

    async function clearTrashBin() {
        try {
            const response = await fetch('/clear-trash', {
                method: 'DELETE',
            });

            const data = await response.json();

            if (response.ok) {
                console.log(data.message);
                alert(data.message);
                closeTrashBin();
                loadTrashBin();
            } else {
                console.error('Ошибка:', data.message);
                alert('Ошибка при очистке корзины: ' + data.message);
            }
        } catch (error) {
            console.error('Ошибка сети:', error);
            alert('Ошибка сети при очистке корзины.');
        }
    }

    function closeTrashBin() {
        if (trashModal) {
            document.body.removeChild(trashModal);
        vtrashModal = null;
        }
    }
    
    async function restoreFromTrashBin(id) {
      try {
        const response = await fetch(`/restore-from-trash/${id}`, {
          method: 'POST',
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || 'Ошибка восстановления');
        }

        console.log('Ответ сервера:', data);

        if (!data.imageUrl) {
          throw new Error('imageUrl отсутствует в ответе сервера');
        }

        return new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = "anonymous";
            
            img.onload = () => {
                if (canvas && canvas.width > 0 && canvas.height > 0) {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                
                    const ratio = Math.min(canvas.width / img.width, canvas.height / img.height);
                    const x = (canvas.width - img.width * ratio) / 2;
                    const y = (canvas.height - img.height * ratio) / 2;

                    ctx.drawImage(
                        img,
                        0, 0, img.width, img.height,
                        x, y, img.width * ratio, img.height * ratio
                    );
                
                    console.log('Изображение успешно загружено на холст');
                    closeTrashBin();
                    resolve();
                } else {
                    reject(new Error('Холст не инициализирован или имеет некорректные размеры'));
                }
            };
            
            img.onerror = (error) => {
                console.error('Ошибка загрузки изображения:', error);
                alert('Не удалось загрузить изображение');
                reject(error);
            };
            img.src = data.imageUrl + '?cache=' + Date.now();
        });
      
      } catch (error) {
          console.error('Ошибка:', error);
          alert('Ошибка при восстановлении: ' + (error.message || 'Неизвестная ошибка'));
      }
    }

    async function loadTrashBin() {
        try {
            const response = await fetch('/trash-bin');
            const data = await response.json();
            if (response.ok) {
                console.log("Корзина загружена:", data);
                trashBin = data;
                return data;
            } else {
                console.error("Ошибка при загрузке корзины:", data.message);
                return [];
            }
        } catch (error) {
            console.error("Ошибка при загрузке корзины:", error);
            return [];
        }
    }

    function updateTrashBinContent() {
        if (trashModal) {
            document.body.removeChild(trashModal);
            trashModal = null;
            showTrashBin();
        }
    }

    document.getElementById('trash').addEventListener('click', sendCanvasToTrash);
    document.getElementById('viewTrash').addEventListener('click', showTrashBin);

    
    let canvases = []; 
    let activeCanvasIndex = -1;

    const defaultCanvasSettings = {
        width: 800,
        height: 600,
        resolution: 72,
        colorMode: 'RGB',
        backgroundColor: '#ffffff'
    };

    function initializeDefaultCanvas() {
        const defaultCanvas = document.getElementById('drawing-canvas');
        const defaultCtx = defaultCanvas.getContext('2d');

        defaultCtx.fillStyle = defaultCanvasSettings.backgroundColor;
        defaultCtx.fillRect(0, 0, defaultCanvas.width, defaultCanvas.height);

        canvases.push({ canvas: defaultCanvas, ctx: defaultCtx, settings: defaultCanvasSettings });
        addCanvasTab(0);
        setActiveCanvas(0);
    }

    initializeDefaultCanvas();

    document.getElementById('new-canvas-button').addEventListener('click', () => {
        const settings = openCanvasSettingsDialog();
        if (settings) {
            createNewCanvas(settings);
        }
    });

    function openCanvasSettingsDialog() {
        const width = prompt("Введите ширину холста:", defaultCanvasSettings.width);
        const height = prompt("Введите высоту холста:", defaultCanvasSettings.height);
        const resolution = prompt("Введите разрешение (DPI):", defaultCanvasSettings.resolution);
        const colorMode = prompt("Выберите цветовой режим (RGB/CMYK/Grayscale):", defaultCanvasSettings.colorMode);
        const backgroundColor = prompt("Введите цвет фона (HEX):", defaultCanvasSettings.backgroundColor);

        return {
            width: parseInt(width),
            height: parseInt(height),
            resolution: parseInt(resolution),
            colorMode,
            backgroundColor
        };
    }

    function createNewCanvas(settings) {
        const canvas = document.createElement('canvas');
        canvas.width = settings.width;
        canvas.height = settings.height;
        canvas.style.display = 'none';
        canvas.style.position = 'absolute';

        const canvasContainer = document.querySelector('.canvas-container');
        canvasContainer.appendChild(canvas);

        const ctx = canvas.getContext('2d');
        ctx.fillStyle = settings.backgroundColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        canvases.push({ canvas, ctx, settings });
        addCanvasTab(canvases.length - 1);
        setActiveCanvas(canvases.length - 1);
    }

    function addCanvasTab(index) {
    const tabsContainer = document.getElementById('tabs-container');
    const tab = document.createElement('div');
    tab.className = 'canvas-tab';
    tab.textContent = `Холст ${index + 1}`;
    tab.dataset.index = index;

    const closeButton = document.createElement('span');
    closeButton.className = 'close-tab';
    closeButton.innerHTML = '×';
    closeButton.addEventListener('click', (e) => {
        e.stopPropagation();
        closeCanvas(index);
    });

    tab.appendChild(closeButton);

    tab.addEventListener('click', () => {
        setActiveCanvas(index);
    });

    tabsContainer.appendChild(tab);
}

    function setActiveCanvas(index) {
        if (activeCanvasIndex !== -1) {
            canvases[activeCanvasIndex].canvas.style.display = 'none';
        }

        activeCanvasIndex = index;
        canvases[index].canvas.style.display = 'block';

        document.querySelectorAll('.canvas-tab').forEach((tab, i) => {
            tab.classList.toggle('active', i === index);
        });
    }

    function closeCanvas(index) {
        if (index === 0) {
            alert("Первый холст нельзя удалить!");
            return;
        }

        if (index < 0 || index >= canvases.length) return;

        canvases.splice(index, 1);
        document.getElementById('tabs-container').children[index].remove();
    
        if (activeCanvasIndex === index) {
            if (canvases.length > 0) {
                setActiveCanvas(Math.max(index - 1, 0));
            } else {
                activeCanvasIndex = -1;
            }
        }
    }

    function renameCanvas(index) {
        const newName = prompt("Введите новое имя холста:");
        if (newName) {
            document.getElementById('tabs-container').children[index].textContent = newName;
        }
    }

    function exportCanvas(index) {
        const canvas = canvases[index].canvas;
        const link = document.createElement('a');
        link.download = `canvas-${index + 1}.png`;
        link.href = canvas.toDataURL();
        link.click();
    }

    function duplicateCanvas(index) {
        const original = canvases[index];
        const newCanvas = original.canvas.cloneNode();
        newCanvas.width = original.canvas.width;
        newCanvas.height = original.canvas.height;

        const newCtx = newCanvas.getContext('2d');
        newCtx.drawImage(original.canvas, 0, 0);

        canvases.push({ canvas: newCanvas, ctx: newCtx, settings: original.settings });
        addCanvasTab(canvases.length - 1);
    }
    
    let layers = [];
    let activeLayerIndex = -1;

    function createNewLayer() {
        const canvasContainer = document.getElementById('canvas-container');
        if (!canvasContainer) {
            console.error('Контейнер для canvas не найден.');
            return;
        }

        const newCanvas = document.createElement('canvas');
        newCanvas.width = canvas.width;
        newCanvas.height = canvas.height;
        newCanvas.style.position = 'absolute';
        newCanvas.style.top = '0';
        newCanvas.style.left = '0';

        const layerCtx = newCanvas.getContext('2d');
        layerCtx.globalAlpha = 1;

        layers.push({
            canvas: newCanvas,
            ctx: layerCtx,
            visible: true,
            opacity: 1
        });

        canvasContainer.appendChild(newCanvas);

        updateLayerPanel();

        setActiveLayer(layers.length - 1);
    }

    function setActiveLayer(index) {
        if (index >= 0 && index < layers.length) {
            activeLayerIndex = index;

            document.querySelectorAll('.layer-item').forEach(item => item.classList.remove('active'));

            const activeLayerElement = document.querySelector(`.layer-item[data-index="${index}"]`);
            if (activeLayerElement) {
                activeLayerElement.classList.add('active');
            } else {
                console.error(`Слой с индексом ${index} не найден в DOM.`);
            }

            updateLayerPanel();
        }
    }

    function updateLayerPanel() {
        const container = document.getElementById('layers-container');
        if (!container) {
            console.error('Контейнер для панели слоев не найден.');
            return;
        }

        layers.forEach((layer, index) => {
            let layerItem = document.querySelector(`.layer-item[data-index="${index}"]`);

            if (layerItem) {
                const visibilityIcon = layerItem.querySelector('.visible, .hidden');
                const layerName = layerItem.querySelector('span:not(.visible):not(.hidden)');
                const deleteButton = layerItem.querySelector('button');

                visibilityIcon.className = layer.visible ? 'visible' : 'hidden';
                visibilityIcon.textContent = layer.visible ? '👁️' : '🙈';

                layerName.textContent = `Слой ${index + 1}`;

                deleteButton.onclick = () => deleteLayer(index);
            } else {
                layerItem = document.createElement('div');
                layerItem.className = 'layer-item';
                layerItem.dataset.index = index;

                const visibilityIcon = document.createElement('span');
                visibilityIcon.className = layer.visible ? 'visible' : 'hidden';
                visibilityIcon.textContent = layer.visible ? '👁️' : '🙈';
                visibilityIcon.addEventListener('click', () => toggleLayerVisibility(index));

                const layerName = document.createElement('span');
                layerName.textContent = `Слой ${index + 1}`;

                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Удалить';
                deleteButton.addEventListener('click', () => deleteLayer(index));

                layerItem.appendChild(visibilityIcon);
                layerItem.appendChild(layerName);
                layerItem.appendChild(deleteButton);

                container.appendChild(layerItem);
            }

            if (index === activeLayerIndex) {
                layerItem.classList.add('active');
            } else {
                layerItem.classList.remove('active');
            }
        });

        while (container.children.length > layers.length) {
            container.removeChild(container.lastChild);
        }
    }

    function deleteLayer(index) {
        if (index >= 0 && index < layers.length) {
            const layerToRemove = layers[index];

            layers.splice(index, 1);
    
            document.getElementById('canvas-container').removeChild(layerToRemove.canvas);

            if (activeLayerIndex === index) {
                setActiveLayer(Math.max(0, layers.length - 1));
            }

            updateLayerPanel();
            redrawCanvas();
        }
    }

    function toggleLayerVisibility(index) {
        if (index >= 0 && index < layers.length) {
            layers[index].visible = !layers[index].visible;
    
            const layerItem = document.querySelector(`.layer-item[data-index="${index}"]`);
            if (layerItem) {
                const visibilityIcon = layerItem.querySelector('.visible, .hidden');

                visibilityIcon.className = layers[index].visible ? 'visible' : 'hidden';
                visibilityIcon.textContent = layers[index].visible ? '👁️' : '🙈';
            }
            redrawCanvas();
        }
    }

    function setLayerOpacity(index, opacity) {
        if (index >= 0 && index < layers.length) {
            layers[index].opacity = opacity;
            redrawCanvas();
        }
    }

    document.getElementById('add-layer').addEventListener('click', createNewLayer);

    let isSelectings = false;
    let startsX, startsY, endsX, endsY;

    function getMousePositions(e) {
        const rect = canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }

    canvas.addEventListener('mousedown', (e) => {
        const pos = getMousePositions(e);
        if (currentTool === 'select') {
            isSelectings = true;
            startsX = pos.x;
            startsY = pos.y;
            endsX = pos.x;
            endsY = pos.y;

            clearSelectionOutline();
        }
    });

    canvas.addEventListener('mousemove', (e) => {
        if (!isSelectings) return;
        const pos = getMousePositions(e);
        endsX = pos.x;
        endsY = pos.y;

        drawSelectionRectangles();
    });

    canvas.addEventListener('mouseup', () => {
        if (!isSelectings) return;
        isSelectings = false;

        finalizeSelections();
    });

    function drawSelectionRectangles() {
        clearSelectionOutline();

        ctx.strokeStyle = 'rgba(0, 0, 0, 0)';
        ctx.setLineDash([5, 5]);
        ctx.strokeRect(
            Math.min(startsX, endsX),
            Math.min(startsY, endsY),
            Math.abs(endsX - startsX),
            Math.abs(endsY - startsY)
        );
    }

    function clearSelectionOutline() {
        const tempCanvas = document.createElement('canvas');
        const tempCtx = tempCanvas.getContext('2d');

        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;

        tempCtx.drawImage(canvas, 0, 0);

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.drawImage(tempCanvas, 0, 0);
    }

    function finalizeSelections() {
        selectedArea = {
            startsX: Math.min(startsX, endsX),
            startsY: Math.min(startsY, endsY),
            width: Math.abs(endsX - startsX),
            height: Math.abs(endsY - startsY)
        };

        console.log("Выделенная область:", selectedArea);

        clearSelectionOutline();
    }

    function cutSelection() {
        if (!selectedArea) {
            alert("Сначала выделите область!");
            return;
        }

        const clipboard = document.createElement('canvas');
        const ctxClipboard = clipboard.getContext('2d');

        const width = Math.abs(endsX - startsX);
        const height = Math.abs(endsY - startsY);
    
        clipboard.width = width;
        clipboard.height = height;

        ctxClipboard.drawImage(
            canvas,
            Math.min(startsX, endsX),
            Math.min(startsY, endsY),
            width,
            height,
            0,
            0,
            width,
            height
        );

        window.clipboardData = clipboard;
    
        clearSelectedArea();
        saveState();
    }

    function clearSelectedArea() {
        const width = Math.abs(endsX - startsX);
        const height = Math.abs(endsY - startsY);

        ctx.clearRect(
            Math.min(startsX, endsX),
            Math.min(startsY, endsY),
            width,
            height
        );
    }
    
    function copySelection() {
        if (!selectedArea) {
            alert("Сначала выделите область!");
            return;
        }

        const clipboard = document.createElement('canvas');
        const ctxClipboard = clipboard.getContext('2d');

        const width = Math.abs(endsX - startsX);
        const height = Math.abs(endsY - startsY);

        clipboard.width = width;
        clipboard.height = height;

        ctxClipboard.drawImage(
            canvas,
            Math.min(startsX, endsX),
            Math.min(startsY, endsY),
            width,
            height,
            0,
            0,
            width,
            height
        );

        window.clipboardData = clipboard;
    }
    
    function pasteFromClipboard() {
        if (!window.clipboardData) {
            alert("Буфер обмена пуст!");
            return;
        }

        const clipboardCanvas = window.clipboardData;
        const clipboardWidth = clipboardCanvas.width;
        const clipboardHeight = clipboardCanvas.height;

        const newLayerCanvas = document.createElement('canvas');
        const newLayerCtx = newLayerCanvas.getContext('2d');

        newLayerCanvas.width = canvas.width;
        newLayerCanvas.height = canvas.height;

        function getMousePosition(event) {
            const rect = canvas.getBoundingClientRect();
            return {
                x: event.clientX - rect.left,
                y: event.clientY - rect.top
            };
        }

        let pasteX, pasteY;
        let isMovingPasted = false;
        let offsetX, offsetY;

        function waitForPastePosition() {
            return new Promise((resolve) => {
                const mouseMoveHandler = (e) => {
                    const pos = getMousePosition(e);
                    pasteX = pos.x - clipboardWidth / 2;
                    pasteY = pos.y - clipboardHeight / 2;
                };

                const mouseDownHandler = (e) => {
                    const pos = getMousePosition(e);
                    pasteX = pos.x - clipboardWidth / 2;
                    pasteY = pos.y - clipboardHeight / 2;

                    newLayerCtx.drawImage(clipboardCanvas, pasteX, pasteY);
                    ctx.drawImage(newLayerCanvas, 0, 0);

                    canvas.removeEventListener('mousemove', mouseMoveHandler);
                    canvas.removeEventListener('mousedown', mouseDownHandler);
                    resolve();
                };

                canvas.addEventListener('mousemove', mouseMoveHandler);
                canvas.addEventListener('mousedown', mouseDownHandler);
            });
        }

        waitForPastePosition().then(() => {
            canvas.addEventListener('mousedown', (e) => {
                const pos = getMousePosition(e);

                if (
                    pos.x >= pasteX &&
                    pos.x <= pasteX + clipboardWidth &&
                    pos.y >= pasteY &&
                    pos.y <= pasteY + clipboardHeight
                ) {
                    isMovingPasted = true;
                    offsetX = pos.x - pasteX;
                    offsetY = pos.y - pasteY;
                }
            });

            canvas.addEventListener('mousemove', (e) => {
                if (!isMovingPasted) return;
    
                const pos = getMousePosition(e);
                pasteX = pos.x - offsetX;
                pasteY = pos.y - offsetY;

                ctx.clearRect(0, 0, canvas.width, canvas.height);
                ctx.drawImage(newLayerCanvas, pasteX, pasteY);
            });

            canvas.addEventListener('mouseup', () => {
                isMovingPasted = false;
                saveState();
            });
        });
    }

    document.getElementById('cut').addEventListener('click', cutSelection);
    document.getElementById('copy').addEventListener('click', copySelection);
    document.getElementById('paste').addEventListener('click', pasteFromClipboard);
    document.getElementById('select-tool').addEventListener('click', () => {
        currentTool = 'select';
    });

    document.addEventListener('keydown', (e) => {
        const isCtrlPressed = e.ctrlKey || e.metaKey;

        if (isCtrlPressed) {
            switch (e.key.toLowerCase()) {
                case 'c':
                    e.preventDefault();
                    copySelection();
                    break;
                case 'x':
                    e.preventDefault();
                    cutSelection();
                    break;
                case 'v':
                    e.preventDefault();
                    pasteFromClipboard();
                    break;
                default:
                    break;
            }
        }
    });

    function downloadCanvasImage(format = 'png') {
        const canvas = document.getElementById('drawing-canvas');
        if (!canvas) {
            alert('Холст не найден!');
            return;
        }

        let mimeType;
        let fileExtension;
        switch (format.toLowerCase()) {
            case 'png':
                mimeType = 'image/png';
                fileExtension = '.png';
                break;
            case 'jpeg':
            case 'jpg':
                mimeType = 'image/jpeg';
                fileExtension = '.jpg';
                break;
            case 'webp':
                mimeType = 'image/webp';
                fileExtension = '.webp';
                break;
            default:
                mimeType = 'image/png';
                fileExtension = '.png';
        }
        
        try {
            const dataURL = canvas.toDataURL(mimeType);

            const link = document.createElement('a');
            link.href = dataURL;
            link.download = `image${fileExtension}`;

            document.body.appendChild(link);
            link.click();

            document.body.removeChild(link);
        } catch (error) {
            console.error('Ошибка при скачивании изображения:', error);
            alert('Не удалось скачать изображение. Пожалуйста, попробуйте снова.');
        }
    }

    document.getElementById('download').addEventListener('click', () => {
        const format = prompt('Выберите формат (png, jpeg, webp):', 'png').trim().toLowerCase();
        if (['png', 'jpeg', 'jpg', 'webp'].includes(format)) {
            downloadCanvasImage(format);
        } else {
            alert('Неверный формат. Изображение будет сохранено в формате PNG.');
            downloadCanvasImage('png');
        }
    });
    
    document.getElementById('save-draft').addEventListener('click', async () => {
        try {
            const title = prompt("Введите название рисунка:", "Мой рисунок");
            if (!title) return alert("Название рисунка обязательно!");

            const author = prompt("Введите автора рисунка:", "Неизвестный автор");
            if (!author) return alert("Автор рисунка обязателен!");

            const userId = await getUserId();
            if (!userId) throw new Error("Не удалось получить userId");

            const formData = new FormData();
            formData.append('userId', userId);
            formData.append('title', title);
            formData.append('author', author);

            canvas.toBlob((canvasBlob) => {
                if (!canvasBlob) throw new Error("Не удалось создать Blob из холста");

                formData.append('canvasFile', canvasBlob, 'canvas.png');
                
                fetch('/api/drafts/save?folder=drafts', {
                    method: 'POST',
                    body: formData,
                })
                .then(response => response.json())
                .then(result => {
                    if (result.redirect) {
                        window.location.href = result.redirect;
                    } else {
                        throw new Error(result.message || "Ошибка при сохранении черновика.");
                    }
                })
                .catch(error => {
                    console.error("Ошибка:", error);
                    alert("Не удалось сохранить черновик. Пожалуйста, попробуйте позже.");
                });
            }, 'image/png'); 
        
            clearCanvas();

        } catch (error) {
            console.error("Ошибка:", error);
            alert("Не удалось сохранить черновик. Пожалуйста, попробуйте позже.");
        }
    });

    function clearCanvas() {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    document.getElementById('go-to-drafts').onclick = () => {
        window.location.href = '/drafts';
    };
 
    async function getUserId() {
        try {
            const response = await fetch('/api/user');
            if (!response.ok) {
                throw new Error('Не удалось получить данные пользователя');
            }
            const user = await response.json();
            console.log("User ID from /api/user:", user._id);

            return user._id;
        } catch (error) {
            console.error('Ошибка при получении ID пользователя:', error);
            return null;
        }
    }

    const canvasDataInput = document.getElementById('canvasData');

    const canvasData = canvasDataInput.value;

    if (canvasData) {
        const img = new Image();
        img.onload = () => {
            ctx.drawImage(img, 0, 0);
        };
        img.src = canvasData;
    }

    async function loadCanvasFromFile(filePath) {
        try {
            const response = await fetch(`/api/drafts/load-canvas?filePath=${encodeURIComponent(filePath)}`);
            if (!response.ok) {
                throw new Error('Не удалось загрузить данные холста');
            }
            const blob = await response.blob();

            const img = new Image();
            img.onload = () => {
                const ctx = canvas.getContext('2d');

                ctx.drawImage(img, 0, 0);
            };
            img.src = URL.createObjectURL(blob);
    
        } catch (error) {
            console.error('Ошибка при загрузке данных холста:', error);
            alert('Не удалось загрузить данные холста. Пожалуйста, попробуйте позже.');
        }
    }

    async function loadDraft(draftId) {
        try {
            const response = await fetch(`/api/drafts/${draftId}`);
            if (!response.ok) {
                throw new Error('Не удалось загрузить черновик');
            }
            const draft = await response.json();

            await loadCanvasFromFile(draft.canvasFilePath);

            window.location.href = '/drawing_board';
        } catch (error) {
            console.error('Ошибка при загрузке черновика:', error);
            alert('Не удалось загрузить черновик. Пожалуйста, попробуйте позже.');
        }
    }
      
});

document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const draftId = params.get('draftId');

    if (!draftId) {
        console.error('Отсутствует ID черновика');
        return;
    }

    const canvas = document.getElementById('drawing-canvas');
    const ctx = canvas.getContext('2d');

    try {
        const response = await fetch(`/api/drafts/${draftId}`);
        if (!response.ok) {
            throw new Error(`Ошибка загрузки черновика: ${response.statusText}`);
        }

        const data = await response.json();
        const pngFilePath = data.pngFilePath;

        console.log('PNG File Path:', pngFilePath);

        const img = new Image();
        img.onload = () => {
            ctx.drawImage(img, 0, 0);
        };
        img.onerror = (err) => {
            console.error("Ошибка загрузки изображения:", err);
            alert("Не удалось загрузить изображение.");
        };

        img.src = pngFilePath;

    } catch (error) {
        console.error('Ошибка при загрузке черновика:', error);
        alert('Не удалось загрузить черновик. Пожалуйста, попробуйте позже.');
    }
});