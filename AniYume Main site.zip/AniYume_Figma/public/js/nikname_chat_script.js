let socket = null;
let currentChatId = null;
let currentCompanionId = null;
let currentCompanionName = '';
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let peerConnection = null;
let localStream = null;
let isInCall = false;

let isAudioCallActive = false;
let audioCallStream = null;
let audioPeerConnection = null;
let isMicMuted = false;

let incomingCallData = null;
let isCallModalOpen = false;

let outgoingCallTimeout = null;
let isOutgoingCall = false;
let currentCallTargetId = null;

// Переменные для видео-звонка
let videoCallStream = null;
let videoPeerConnection = null;
let isVideoCallActive = false;
let isVideoMicMuted = false;
let isVideoCamOff = false;
let incomingVideoCallData = null;
let isVideoCallModalOpen = false;
let isOutgoingVideoCall = false;
let videoCallTimeout = null;
let currentVideoCallTargetId = null;

// Конфигурация WebRTC
const configuration = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
    ]
};

// Инициализация Socket.IO
function initSocket() {
    socket = io();
    
    socket.on('connect', () => {
        console.log('Socket.IO подключен');
        const userId = window.currentUserId;
        console.log('UserId для подключения:', userId);
        if (userId && userId !== '') {
            socket.emit('user connected', userId);
        } else {
            console.error('UserId не найден!');
        }
        loadChatList();
    });
    
    socket.on('new-message', (message) => {
        console.log('Получено новое сообщение:', message);
        if (currentChatId) {
            displayMessage(message, message.senderId === window.currentUserId);
        }
        loadChatList();
    });
    
    socket.on('chat-list-update', () => {
        loadChatList();
    });
    
    socket.on('user-typing', (data) => {
        if (data.isTyping) {
            document.getElementById('typing-indicator').style.display = 'block';
        } else {
            document.getElementById('typing-indicator').style.display = 'none';
        }
    });
    
    socket.on('messages-read', (data) => {
        loadChatList();
    });
    
    socket.on('call-signal', async (data) => {
        if (data.signal.type === 'offer') {
            await handleOffer(data);
        } else if (data.signal.type === 'answer') {
            await handleAnswer(data);
        } else if (data.signal.candidate) {
            await handleCandidate(data);
        }
    });
    
    socket.on('call-ended', () => {
        endCall();
        Toastify({ text: 'Собеседник завершил звонок', duration: 3000 }).showToast();
    });
    
    socket.on('audio-call-signal', async (data) => {
    console.log('Получен аудио-сигнал типа:', data.signal?.type);
    
    if (data.signal.type === 'offer') {
        if (!isAudioCallActive && !incomingCallData) {
            incomingCallData = {
                from: data.from,
                fromUserId: data.fromUserId,
                offer: data.signal
            };
            
            currentCallTargetId = data.from;
            
            try {
                const response = await fetch(`/api/chat/user-info/${data.from}`);
                const userInfo = await response.json();
                const modal = document.getElementById('audio-call-modal');
                document.getElementById('audio-call-partner-name').textContent = userInfo.username;
                document.getElementById('incoming-call-buttons').style.display = 'flex';
                document.getElementById('active-call-buttons').style.display = 'none';
                document.getElementById('call-status').textContent = 'Входящий звонок...';
                modal.style.display = 'flex';
                isCallModalOpen = true;
                isOutgoingCall = false;
            } catch (err) {
                console.error(err);
            }
        }
    }else if (data.signal.type === 'answer') {
    if (audioPeerConnection) {
        await audioPeerConnection.setRemoteDescription(new RTCSessionDescription(data.signal));
        document.getElementById('active-call-buttons').style.display = 'flex';
        document.getElementById('call-status').textContent = 'В звонке';
        document.getElementById('call-status').style.color = '#4caf50';
        
        const cancelBtn = document.getElementById('cancel-call-btn');
        const endBtn = document.getElementById('end-call-btn');
        if (cancelBtn) cancelBtn.style.display = 'none';
        if (endBtn) endBtn.style.display = 'inline-flex';
    }
} else if (data.signal.candidate) {
        if (audioPeerConnection) {
            await audioPeerConnection.addIceCandidate(new RTCIceCandidate(data.signal.candidate));
        }
    }
});
    
    socket.on('audio-call-ended', () => {
        if (isAudioCallActive) {
            Toastify({ text: 'Собеседник завершил звонок', duration: 3000 }).showToast();
            endAudioCall();
        }
    });
    
    socket.on('audio-call-rejected', () => {
        if (isAudioCallActive || isCallModalOpen) {
            Toastify({ text: 'Собеседник отклонил звонок', duration: 3000 }).showToast();
            endAudioCall();
        }
    });
    
    socket.on('incoming-audio-call', async (data) => {
    console.log('Входящий звонок от:', data.fromName);
    
    incomingCallData = {
        from: data.from,
        fromUserId: data.fromUserId,
        offer: data.offer
    };
    
    const modal = document.getElementById('audio-call-modal');
    const partnerNameSpan = document.getElementById('audio-call-partner-name');
    partnerNameSpan.textContent = data.fromName;
    document.getElementById('call-status').textContent = 'Входящий звонок...';
    document.getElementById('call-status').style.color = '#ff9800';
    document.getElementById('incoming-call-buttons').style.display = 'flex';
    document.getElementById('active-call-buttons').style.display = 'none';
    
    const cancelBtn = document.getElementById('cancel-call-btn');
    if (cancelBtn) cancelBtn.style.display = 'none';
    
    modal.style.display = 'flex';
    isCallModalOpen = true;
    isOutgoingCall = false;
});
    
    socket.on('audio-call-cancelled', () => {
    if (isCallModalOpen && !isAudioCallActive) {
        Toastify({ text: 'Собеседник отменил звонок', duration: 3000 }).showToast();
        endAudioCall();
    }
});
    
    // Обработчики видео-звонков
socket.on('video-call-signal', async (data) => {
    console.log('Получен видео-сигнал типа:', data.signal?.type);
    
    if (data.signal.type === 'offer') {
        if (!isVideoCallActive && !incomingVideoCallData) {
            incomingVideoCallData = {
                from: data.from,
                fromUserId: data.fromUserId,
                offer: data.signal
            };
            currentVideoCallTargetId = data.from;
            
            try {
                const response = await fetch(`/api/chat/user-info/${data.from}`);
                const userInfo = await response.json();
                const modal = document.getElementById('video-call-modal');
                document.getElementById('video-incoming-buttons').style.display = 'flex';
                document.getElementById('video-active-buttons').style.display = 'none';
                modal.style.display = 'flex';
                isVideoCallModalOpen = true;
            } catch (err) {
                console.error(err);
            }
        }
    } else if (data.signal.type === 'answer') {
        if (videoPeerConnection) {
            await videoPeerConnection.setRemoteDescription(new RTCSessionDescription(data.signal));
            const endBtn = document.getElementById('end-video-call-btn');
            if (endBtn) endBtn.style.display = 'inline-flex';
        }
    } else if (data.signal.candidate) {
        if (videoPeerConnection) {
            await videoPeerConnection.addIceCandidate(new RTCIceCandidate(data.signal.candidate));
        }
    }
});

socket.on('video-call-ended', () => {
    if (isVideoCallActive) {
        Toastify({ text: 'Собеседник завершил видео-звонок', duration: 3000 }).showToast();
        endVideoCall();
    }
});

socket.on('video-call-rejected', () => {
    if (isVideoCallActive || isVideoCallModalOpen) {
        Toastify({ text: 'Собеседник отклонил видео-звонок', duration: 3000 }).showToast();
        endVideoCall();
    }
});

socket.on('video-call-cancelled', () => {
    if (isVideoCallModalOpen && !isVideoCallActive) {
        Toastify({ text: 'Собеседник отменил видео-звонок', duration: 3000 }).showToast();
        endVideoCall();
    }
});
    
    socket.on('incoming-video-call', async (data) => {
    console.log('Входящий видео-звонок от:', data.fromName);
    
    incomingVideoCallData = {
        from: data.from,
        fromUserId: data.fromUserId,
        offer: data.offer
    };
    currentVideoCallTargetId = data.from;
    
    const modal = document.getElementById('video-call-modal');
    document.getElementById('video-incoming-buttons').style.display = 'flex';
    document.getElementById('video-active-buttons').style.display = 'none';
    modal.style.display = 'flex';
    isVideoCallModalOpen = true;
});
    
    socket.on('message-deleted', (data) => {
    console.log('Сообщение удалено:', data.messageId);
    
    const messageElement = document.querySelector(`.message[data-message-id="${data.messageId}"]`);
    if (messageElement) {
        const currentUserId = window.currentUserId;
        messageElement.innerHTML = `<div class="deleted-message"><em>Сообщение удалено</em></div>`;
        messageElement.classList.add('deleted');
    }
    
    loadChatList();
});
}

async function handleAudioOffer(data) {
    console.log('Входящий аудио-звонок от:', data.from);
    
    incomingCallData = {
        from: data.from,
        signal: data.signal
    };
    
    let callerName = 'Собеседник';
    try {
        const response = await fetch(`/api/chat/user-info/${data.from}`);
        const userInfo = await response.json();
        callerName = userInfo.username || 'Собеседник';
    } catch (err) {
        console.error('Ошибка получения имени звонящего:', err);
    }
    
    const modal = document.getElementById('audio-call-modal');
    const partnerNameSpan = document.getElementById('audio-call-partner-name');
    partnerNameSpan.textContent = callerName;
    document.getElementById('call-status').textContent = 'Входящий звонок...';
    document.getElementById('call-status').style.color = '#ff9800';
    
    document.getElementById('incoming-call-buttons').style.display = 'flex';
    document.getElementById('active-call-buttons').style.display = 'none';
    
    modal.style.display = 'flex';
    isCallModalOpen = true;
}

// Принять входящий звонок
async function acceptIncomingCall() {
    if (!incomingCallData) return;
    
    currentCallTargetId = incomingCallData.from;
    
    document.getElementById('incoming-call-buttons').style.display = 'none';
    document.getElementById('active-call-buttons').style.display = 'flex';
    document.getElementById('call-status').textContent = 'Соединение...';
    document.getElementById('call-status').style.color = '#ff9800';
    
    const cancelBtn = document.getElementById('cancel-call-btn');
    const endBtn = document.getElementById('end-call-btn');
    if (cancelBtn) cancelBtn.style.display = 'none';
    if (endBtn) endBtn.style.display = 'none';
    
    currentCompanionId = incomingCallData.fromUserId;
    currentCompanionName = document.getElementById('audio-call-partner-name').textContent;
    
    try {
        audioCallStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        audioPeerConnection = new RTCPeerConnection(configuration);
        
        audioCallStream.getTracks().forEach(track => {
            audioPeerConnection.addTrack(track, audioCallStream);
        });
        
        audioPeerConnection.ontrack = (event) => {
            const audioElement = new Audio();
            audioElement.srcObject = event.streams[0];
            audioElement.play();
            document.getElementById('call-status').textContent = 'В звонке';
            document.getElementById('call-status').style.color = '#4caf50';
            if (endBtn) endBtn.style.display = 'inline-flex';
        };
        
        audioPeerConnection.onicecandidate = (event) => {
            if (event.candidate && currentCallTargetId) {
                socket.emit('audio-call-signal', {
                    target: currentCallTargetId,
                    signal: { candidate: event.candidate }
                });
            }
        };
        
        audioPeerConnection.onconnectionstatechange = () => {
            if (audioPeerConnection.connectionState === 'connected') {
                document.getElementById('call-status').textContent = 'В звонке';
                document.getElementById('call-status').style.color = '#4caf50';
                if (endBtn) endBtn.style.display = 'inline-flex';
            } else if (audioPeerConnection.connectionState === 'failed') {
                document.getElementById('call-status').textContent = 'Ошибка соединения';
                document.getElementById('call-status').style.color = '#f44336';
                setTimeout(() => endAudioCall(), 2000);
            }
        };
        
        await audioPeerConnection.setRemoteDescription(new RTCSessionDescription(incomingCallData.offer));
        
        const answer = await audioPeerConnection.createAnswer();
        await audioPeerConnection.setLocalDescription(answer);
        
        socket.emit('audio-call-signal', {
            target: currentCallTargetId,
            signal: audioPeerConnection.localDescription
        });
        
        isAudioCallActive = true;
        incomingCallData = null;
        
    } catch (err) {
        console.error('Ошибка принятия звонка:', err);
        Toastify({ text: 'Не удалось принять звонок', backgroundColor: '#ff4444' }).showToast();
        endAudioCall();
    }
}

function rejectIncomingCall() {
    if (incomingCallData) {
        socket.emit('audio-call-rejected', { target: incomingCallData.from });
    }
    endAudioCall();
}

async function handleAudioAnswer(data) {
    if (audioPeerConnection) {
        await audioPeerConnection.setRemoteDescription(new RTCSessionDescription(data.signal));
    }
}

async function handleAudioCandidate(data) {
    if (audioPeerConnection) {
        await audioPeerConnection.addIceCandidate(new RTCIceCandidate(data.signal.candidate));
    }
}

// Поиск пользователей
async function searchUsers() {
    const query = document.getElementById('search-query').value;
    if (query.length < 2) return;
    
    try {
        const response = await fetch(`/api/chat/search?q=${encodeURIComponent(query)}`);
        const users = await response.json();
        displayResults(users);
    } catch (err) {
        console.error(err);
        Toastify({ text: 'Ошибка поиска', backgroundColor: '#ff4444' }).showToast();
    }
}

function displayResults(users) {
    const resultsDiv = document.getElementById('search-results');
    resultsDiv.innerHTML = '';
    
    if (users.length === 0) {
        resultsDiv.innerHTML = '<p>Пользователи не найдены.</p>';
        return;
    }
    
    const ul = document.createElement('ul');
    users.forEach(user => {
        const avatarUrl = `/api/avatar/${user._id}`;
        
        const li = document.createElement('li');
        li.innerHTML = `
            <img src="${avatarUrl}" class="search-avatar" onerror="this.src='https://i.ibb.co/sJ5Bdp8d/default.jpg'">
            <span>${escapeHtml(user.username)}</span>
            <button onclick="startChat('${user._id}', '${escapeHtml(user.username)}')">Написать</button>
        `;
        ul.appendChild(li);
    });
    resultsDiv.appendChild(ul);
}

// Загрузка списка чатов
async function loadChatList() {
    try {
        const response = await fetch('/api/chat/list');
        const chats = await response.json();
        
        const container = document.getElementById('chat-list');
        if (!container) return;
        
        if (chats.length === 0) {
            container.innerHTML = '<p style="text-align:center;color:#999;">У вас пока нет чатов</p>';
            return;
        }
        
        container.innerHTML = chats.map(chat => {
            const avatarUrl = chat.companionAvatar || 'https://i.ibb.co/sJ5Bdp8d/default.jpg';
            
            return `
                <div class="chat-list-item" onclick="openChat('${chat.chatId}', '${chat.companionId}', '${escapeHtml(chat.companionName)}')">
                    <img src="${avatarUrl}" class="chat-list-avatar" onerror="this.src='https://i.ibb.co/sJ5Bdp8d/default.jpg'">
                    <div class="chat-list-info">
                        <div class="chat-list-name">${escapeHtml(chat.companionName)}</div>
                        <div class="chat-list-last-message">${escapeHtml(chat.lastMessage || 'Нет сообщений')}</div>
                    </div>
                    <div class="chat-list-time">${formatTime(chat.lastMessageTime)}</div>
                    ${chat.unreadCount > 0 ? `<span class="chat-list-unread">${chat.unreadCount}</span>` : ''}
                    <button class="delete-chat-btn" onclick="event.stopPropagation(); deleteChat('${chat.chatId}')"><i class="fas fa-trash"></i></button>
                </div>
            `;
        }).join('');
    } catch (err) {
        console.error('Ошибка загрузки чатов:', err);
    }
}

// Начать новый чат
async function startChat(companionId, companionName) {
    try {
        const response = await fetch('/api/chat/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ companionId })
        });
        const data = await response.json();
        if (data.success) {
            openChat(data.chatId, companionId, companionName);
            loadChatList();
        }
    } catch (err) {
        console.error(err);
        Toastify({ text: 'Ошибка создания чата', backgroundColor: '#ff4444' }).showToast();
    }
}

// Открыть чат
async function openChat(chatId, companionId, companionName) {
    currentChatId = chatId;
    currentCompanionId = companionId;
    currentCompanionName = companionName;
    
    document.getElementById('chat-partner-name').textContent = companionName;
    document.getElementById('chat-area').style.display = 'block';
    document.getElementById('chat-list-section').style.display = 'none';
    document.getElementById('search-results').innerHTML = '';
    document.getElementById('search-query').value = '';
    
    const avatarImg = document.getElementById('chat-avatar');
    avatarImg.src = `/api/avatar/${companionId}`;
    avatarImg.onerror = function() { this.src = 'https://i.ibb.co/sJ5Bdp8d/default.jpg'; };
    
    socket.emit('join-chat', chatId);
    
    try {
        const response = await fetch(`/api/chat/history/${chatId}`);
        const messages = await response.json();
        const messageLog = document.getElementById('message-log');
        messageLog.innerHTML = '';
        const currentUserId = window.currentUserId;
        messages.forEach(msg => displayMessage(msg, msg.senderId === currentUserId));
        messageLog.scrollTop = messageLog.scrollHeight;
    } catch (err) {
        console.error(err);
    }
}

function closeChat() {
    if (currentChatId) {
        socket.emit('leave-chat', currentChatId);
    }
    currentChatId = null;
    currentCompanionId = null;
    document.getElementById('chat-area').style.display = 'none';
    document.getElementById('chat-list-section').style.display = 'block';
    loadChatList();
}

// Отображение сообщения
function displayMessage(message, isOutgoing) {
    const messageLog = document.getElementById('message-log');
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', isOutgoing ? 'outgoing-message' : 'incoming-message');
    messageDiv.setAttribute('data-message-id', message._id);
    
    let content = '';
    const time = new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const currentUserId = window.currentUserId;
    if (message.deletedFor && message.deletedFor.includes(currentUserId)) {
        content = `<div class="deleted-message"><em>Сообщение удалено</em></div>`;
    } else {
        switch(message.type) {
            case 'text':
                content = `<div>${escapeHtml(message.content)}</div><div class="message-time">${time}</div>`;
                break;
            case 'image':
                content = `<div><img src="${message.content}" class="message-image" onclick="window.open(this.src)"></div><div class="message-time">${time}</div>`;
                break;
            case 'video':
                content = `<div><video src="${message.content}" controls class="message-video"></video></div><div class="message-time">${time}</div>`;
                break;
            case 'audio':
                content = `<div><audio src="${message.content}" controls class="message-audio"></audio></div><div class="message-time">${time}</div>`;
                break;
            case 'file':
                content = `<div><a href="${message.content}" download="${message.fileName}" class="message-file"><i class="fas fa-file"></i> ${message.fileName}</a></div><div class="message-time">${time}</div>`;
                break;
            default:
                content = `<div>${escapeHtml(message.content)}</div><div class="message-time">${time}</div>`;
        }
    }
    
    if (!message.deletedFor || !message.deletedFor.includes(currentUserId)) {
        content += `<button class="delete-message-btn" onclick="deleteMessage('${message._id}')" title="Удалить сообщение"><i class="fas fa-trash-alt"></i></button>`;
    }
    
    messageDiv.innerHTML = content;
    messageLog.appendChild(messageDiv);
    messageLog.scrollTop = messageLog.scrollHeight;
}

// Удаление сообщения
function deleteMessage(messageId) {
    if (!currentChatId) return;
    
    if (confirm('Удалить это сообщение? Оно исчезнет только у вас.')) {
        socket.emit('delete-message', {
            chatId: currentChatId,
            messageId: messageId
        });
    }
}

// Отправка текстового сообщения
function sendMessage() {
    const input = document.getElementById('message-input');
    const message = input.value.trim();
    console.log('sendMessage вызван, message:', message, 'currentChatId:', currentChatId);
    
    if (!message || !currentChatId) {
        console.log('Условие не выполнено');
        return;
    }
    
    console.log('Отправка сообщения через socket');
    socket.emit('send-message', {
        chatId: currentChatId,
        message: message,
        type: 'text'
    });
    
    input.value = '';
    socket.emit('typing-stop', currentChatId);
}

// Отправка файла
async function attachFile() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,video/*,application/*';
    input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            const response = await fetch('/api/chat/upload', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            if (data.success) {
                socket.emit('send-message', {
                    chatId: currentChatId,
                    message: data.fileUrl,
                    type: data.fileType,
                    fileName: file.name,
                    fileSize: file.size
                });
            }
        } catch (err) {
            console.error(err);
            Toastify({ text: 'Ошибка загрузки файла', backgroundColor: '#ff4444' }).showToast();
        }
    };
    input.click();
}

// Запись аудио-сообщения
let mediaStream = null;
let audioRecorder = null;

async function startRecording() {
    try {
        mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioRecorder = new MediaRecorder(mediaStream);
        audioChunks = [];
        
        audioRecorder.ondataavailable = (e) => audioChunks.push(e.data);
        audioRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            const formData = new FormData();
            formData.append('audio', audioBlob, 'voice-message.webm');
            
            const response = await fetch('/api/chat/upload-audio', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();
            if (data.success) {
                socket.emit('send-message', {
                    chatId: currentChatId,
                    message: data.fileUrl,
                    type: 'audio',
                    duration: data.duration
                });
            }
            
            mediaStream.getTracks().forEach(track => track.stop());
            document.getElementById('record-audio-btn').innerHTML = '<i class="fas fa-microphone"></i>';
            document.getElementById('record-audio-btn').style.background = '';
            isRecording = false;
        };
        
        audioRecorder.start();
        document.getElementById('record-audio-btn').innerHTML = '<i class="fas fa-stop"></i>';
        document.getElementById('record-audio-btn').style.background = '#ff4444';
        isRecording = true;
        
        setTimeout(() => {
            if (audioRecorder && audioRecorder.state === 'recording') {
                stopRecording();
            }
        }, 60000);
    } catch (err) {
        console.error(err);
        Toastify({ text: 'Не удалось получить доступ к микрофону', backgroundColor: '#ff4444' }).showToast();
    }
}

function stopRecording() {
    if (audioRecorder && audioRecorder.state === 'recording') {
        audioRecorder.stop();
    }
}

//========АУДО-ЗВОНОК

// Исходящий аудио-звонок
async function startAudioCall() {
    if (!currentCompanionId) {
        Toastify({ text: 'Собеседник не выбран', backgroundColor: '#ff4444' }).showToast();
        return;
    }
    
    try {
        const response = await fetch(`/api/chat/get-socket-id/${currentCompanionId}`);
        const data = await response.json();
        
        if (!data.socketId) {
            Toastify({ text: 'Собеседник не в сети', backgroundColor: '#ff4444' }).showToast();
            return;
        }
        
        currentCallTargetId = data.socketId;
        
        const modal = document.getElementById('audio-call-modal');
        const partnerNameSpan = document.getElementById('audio-call-partner-name');
        partnerNameSpan.textContent = currentCompanionName;
        document.getElementById('incoming-call-buttons').style.display = 'none';
        document.getElementById('active-call-buttons').style.display = 'flex';
        document.getElementById('call-status').textContent = 'Ожидание ответа...';
        document.getElementById('call-status').style.color = '#ff9800';
        
        const cancelBtn = document.getElementById('cancel-call-btn');
        const endBtn = document.getElementById('end-call-btn');
        if (cancelBtn) cancelBtn.style.display = 'inline-flex';
        if (endBtn) endBtn.style.display = 'none';
        
        modal.style.display = 'flex';
        isCallModalOpen = true;
        isOutgoingCall = true;
        
        audioCallStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        audioPeerConnection = new RTCPeerConnection(configuration);
        
        audioCallStream.getTracks().forEach(track => {
            audioPeerConnection.addTrack(track, audioCallStream);
        });
        
        audioPeerConnection.ontrack = (event) => {
            const audioElement = new Audio();
            audioElement.srcObject = event.streams[0];
            audioElement.play();
            document.getElementById('call-status').textContent = 'В звонке';
            document.getElementById('call-status').style.color = '#4caf50';
            if (cancelBtn) cancelBtn.style.display = 'none';
            if (endBtn) endBtn.style.display = 'inline-flex';
        };
        
        audioPeerConnection.onicecandidate = (event) => {
            if (event.candidate && currentCallTargetId) {
                socket.emit('audio-call-signal', {
                    target: currentCallTargetId,
                    signal: { candidate: event.candidate }
                });
            }
        };
        
        audioPeerConnection.onconnectionstatechange = () => {
            if (audioPeerConnection.connectionState === 'connected') {
                document.getElementById('call-status').textContent = 'В звонке';
                document.getElementById('call-status').style.color = '#4caf50';
                if (cancelBtn) cancelBtn.style.display = 'none';
                if (endBtn) endBtn.style.display = 'inline-flex';
                if (outgoingCallTimeout) clearTimeout(outgoingCallTimeout);
            } else if (audioPeerConnection.connectionState === 'disconnected') {
                document.getElementById('call-status').textContent = 'Соединение потеряно';
                document.getElementById('call-status').style.color = '#ff9800';
            } else if (audioPeerConnection.connectionState === 'failed') {
                document.getElementById('call-status').textContent = 'Ошибка соединения';
                document.getElementById('call-status').style.color = '#f44336';
                setTimeout(() => endAudioCall(), 2000);
            }
        };
        
        const offer = await audioPeerConnection.createOffer();
        await audioPeerConnection.setLocalDescription(offer);
        
        socket.emit('request-audio-call', {
            targetUserId: currentCompanionId,
            targetSocketId: data.socketId,
            offer: offer
        });
        
        isAudioCallActive = true;
        
        outgoingCallTimeout = setTimeout(() => {
            if (isOutgoingCall && isCallModalOpen && !isAudioCallActive) {
                Toastify({ text: 'Собеседник не ответил', duration: 3000 }).showToast();
                endAudioCall();
            }
        }, 30000);
        
    } catch (err) {
        console.error(err);
        Toastify({ text: 'Ошибка при звонке', backgroundColor: '#ff4444' }).showToast();
        endAudioCall();
    }
}

// Завершить аудио-звонок
function endAudioCall() {
    if (outgoingCallTimeout) {
        clearTimeout(outgoingCallTimeout);
        outgoingCallTimeout = null;
    }
    
    if (audioPeerConnection) {
        audioPeerConnection.close();
        audioPeerConnection = null;
    }
    if (audioCallStream) {
        audioCallStream.getTracks().forEach(track => track.stop());
        audioCallStream = null;
    }
    if (currentCallTargetId && isAudioCallActive) {
        socket.emit('audio-call-ended', { target: currentCallTargetId });
    }
    document.getElementById('audio-call-modal').style.display = 'none';
    document.getElementById('incoming-call-buttons').style.display = 'none';
    document.getElementById('active-call-buttons').style.display = 'none';
    isAudioCallActive = false;
    isMicMuted = false;
    isCallModalOpen = false;
    isOutgoingCall = false;
    incomingCallData = null;
    currentCallTargetId = null;
}

// Отменить исходящий звонок
function cancelOutgoingCall() {
    if (isOutgoingCall && currentCallTargetId) {
        socket.emit('audio-call-cancelled', { target: currentCallTargetId });
        endAudioCall();
        Toastify({ text: 'Звонок отменён', duration: 2000 }).showToast();
    }
}

// Переключение микрофона в аудио-звонке
function toggleMicAudio() {
    if (audioCallStream) {
        const audioTrack = audioCallStream.getAudioTracks()[0];
        if (audioTrack) {
            isMicMuted = !isMicMuted;
            audioTrack.enabled = !isMicMuted;
            const btn = document.getElementById('toggle-mic-audio');
            if (isMicMuted) {
                btn.innerHTML = '<i class="fas fa-microphone-slash"></i> Вкл. микрофон';
                btn.style.background = '#dc3545';
            } else {
                btn.innerHTML = '<i class="fas fa-microphone"></i> Выкл. микрофон';
                btn.style.background = '#4caf50';
            }
        }
    }
}

//======ВИДЕО-ЗВОНОК
// Исходящий видео-звонок
async function startVideoCall() {
    if (!currentCompanionId) {
        Toastify({ text: 'Собеседник не выбран', backgroundColor: '#ff4444' }).showToast();
        return;
    }
    
    try {
        const response = await fetch(`/api/chat/get-socket-id/${currentCompanionId}`);
        const data = await response.json();
        
        if (!data.socketId) {
            Toastify({ text: 'Собеседник не в сети', backgroundColor: '#ff4444' }).showToast();
            return;
        }
        
        currentVideoCallTargetId = data.socketId;
        
        const modal = document.getElementById('video-call-modal');
        document.getElementById('video-incoming-buttons').style.display = 'none';
        document.getElementById('video-active-buttons').style.display = 'flex';
        
        const cancelBtn = document.getElementById('cancel-video-call-btn');
        const endBtn = document.getElementById('end-video-call-btn');
        if (cancelBtn) cancelBtn.style.display = 'inline-flex';
        if (endBtn) endBtn.style.display = 'none';
        
        modal.style.display = 'flex';
        isVideoCallModalOpen = true;
        isOutgoingVideoCall = true;
        
        videoCallStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById('local-video-call').srcObject = videoCallStream;
        
        videoPeerConnection = new RTCPeerConnection(configuration);
        
        videoCallStream.getTracks().forEach(track => {
            videoPeerConnection.addTrack(track, videoCallStream);
        });
        
        videoPeerConnection.ontrack = (event) => {
            if (event.streams && event.streams[0]) {
                document.getElementById('remote-video-call').srcObject = event.streams[0];
            }
        };
        
        videoPeerConnection.onicecandidate = (event) => {
            if (event.candidate && currentVideoCallTargetId) {
                socket.emit('video-call-signal', {
                    target: currentVideoCallTargetId,
                    signal: { candidate: event.candidate }
                });
            }
        };
        
        videoPeerConnection.onconnectionstatechange = () => {
            if (videoPeerConnection.connectionState === 'connected') {
                if (cancelBtn) cancelBtn.style.display = 'none';
                if (endBtn) endBtn.style.display = 'inline-flex';
                if (videoCallTimeout) clearTimeout(videoCallTimeout);
            }
        };
        
        const offer = await videoPeerConnection.createOffer();
        await videoPeerConnection.setLocalDescription(offer);
        
        socket.emit('request-video-call', {
            targetUserId: currentCompanionId,
            targetSocketId: data.socketId,
            offer: offer
        });
        
        isVideoCallActive = true;
        
        videoCallTimeout = setTimeout(() => {
            if (isOutgoingVideoCall && isVideoCallModalOpen && !isVideoCallActive) {
                Toastify({ text: 'Собеседник не ответил', duration: 3000 }).showToast();
                endVideoCall();
            }
        }, 30000);
        
    } catch (err) {
        console.error(err);
        Toastify({ text: 'Ошибка при видео-звонке', backgroundColor: '#ff4444' }).showToast();
        endVideoCall();
    }
}

// Принять входящий видео-звонок
async function acceptIncomingVideoCall() {
    if (!incomingVideoCallData) return;
    
    currentVideoCallTargetId = incomingVideoCallData.from;
    
    document.getElementById('video-incoming-buttons').style.display = 'none';
    document.getElementById('video-active-buttons').style.display = 'flex';
    
    const endBtn = document.getElementById('end-video-call-btn');
    if (endBtn) endBtn.style.display = 'none';
    
    try {
        videoCallStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById('local-video-call').srcObject = videoCallStream;
        
        videoPeerConnection = new RTCPeerConnection(configuration);
        
        videoCallStream.getTracks().forEach(track => {
            videoPeerConnection.addTrack(track, videoCallStream);
        });
        
        videoPeerConnection.ontrack = (event) => {
            if (event.streams && event.streams[0]) {
                document.getElementById('remote-video-call').srcObject = event.streams[0];
            }
        };
        
        videoPeerConnection.onicecandidate = (event) => {
            if (event.candidate && currentVideoCallTargetId) {
                socket.emit('video-call-signal', {
                    target: currentVideoCallTargetId,
                    signal: { candidate: event.candidate }
                });
            }
        };
        
        videoPeerConnection.onconnectionstatechange = () => {
            if (videoPeerConnection.connectionState === 'connected') {
                if (endBtn) endBtn.style.display = 'inline-flex';
            }
        };
        
        await videoPeerConnection.setRemoteDescription(new RTCSessionDescription(incomingVideoCallData.offer));
        
        const answer = await videoPeerConnection.createAnswer();
        await videoPeerConnection.setLocalDescription(answer);
        
        socket.emit('video-call-signal', {
            target: currentVideoCallTargetId,
            signal: videoPeerConnection.localDescription
        });
        
        isVideoCallActive = true;
        incomingVideoCallData = null;
        
    } catch (err) {
        console.error('Ошибка принятия видео-звонка:', err);
        Toastify({ text: 'Не удалось принять звонок', backgroundColor: '#ff4444' }).showToast();
        endVideoCall();
    }
}

function rejectIncomingVideoCall() {
    if (incomingVideoCallData) {
        socket.emit('video-call-rejected', { target: incomingVideoCallData.from });
    }
    endVideoCall();
}

function cancelOutgoingVideoCall() {
    if (isOutgoingVideoCall && currentVideoCallTargetId) {
        socket.emit('video-call-cancelled', { target: currentVideoCallTargetId });
        endVideoCall();
        Toastify({ text: 'Видео-звонок отменён', duration: 2000 }).showToast();
    }
}

// Завершить видео-звонок
function endVideoCall() {
    if (videoCallTimeout) {
        clearTimeout(videoCallTimeout);
        videoCallTimeout = null;
    }
    
    if (videoPeerConnection) {
        videoPeerConnection.close();
        videoPeerConnection = null;
    }
    if (videoCallStream) {
        videoCallStream.getTracks().forEach(track => track.stop());
        videoCallStream = null;
    }
    if (currentVideoCallTargetId && isVideoCallActive) {
        socket.emit('video-call-ended', { target: currentVideoCallTargetId });
    }
    document.getElementById('video-call-modal').style.display = 'none';
    document.getElementById('remote-video-call').srcObject = null;
    document.getElementById('local-video-call').srcObject = null;
    isVideoCallActive = false;
    isVideoMicMuted = false;
    isVideoCamOff = false;
    isVideoCallModalOpen = false;
    isOutgoingVideoCall = false;
    incomingVideoCallData = null;
    currentVideoCallTargetId = null;
}

// Переключение микрофона в видео-звонке
function toggleVideoMic() {
    if (videoCallStream) {
        const audioTrack = videoCallStream.getAudioTracks()[0];
        if (audioTrack) {
            isVideoMicMuted = !isVideoMicMuted;
            audioTrack.enabled = !isVideoMicMuted;
            const btn = document.getElementById('toggle-video-mic');
            if (isVideoMicMuted) {
                btn.innerHTML = '<i class="fas fa-microphone-slash"></i> Вкл. микрофон';
                btn.style.background = '#dc3545';
            } else {
                btn.innerHTML = '<i class="fas fa-microphone"></i> Выкл. микрофон';
                btn.style.background = '#4caf50';
            }
        }
    }
}

// Переключение камеры в видео-звонке
function toggleVideoCam() {
    if (videoCallStream) {
        const videoTrack = videoCallStream.getVideoTracks()[0];
        if (videoTrack) {
            isVideoCamOff = !isVideoCamOff;
            videoTrack.enabled = !isVideoCamOff;
            const btn = document.getElementById('toggle-video-cam');
            if (isVideoCamOff) {
                btn.innerHTML = '<i class="fas fa-video-slash"></i> Вкл. камеру';
                btn.style.background = '#dc3545';
            } else {
                btn.innerHTML = '<i class="fas fa-video"></i> Выкл. камеру';
                btn.style.background = '#2196f3';
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const recordBtn = document.getElementById('record-audio-btn');
    if (recordBtn) {
        recordBtn.addEventListener('click', () => {
            if (isRecording) {
                stopRecording();
            } else {
                startRecording();
            }
        });
    }
});

// Удаление чата
async function deleteChat(chatId) {
    if (confirm('Удалить чат? Он останется у собеседника.')) {
        try {
            await fetch(`/api/chat/${chatId}`, { method: 'DELETE' });
            if (currentChatId === chatId) {
                closeChat();
            }
            loadChatList();
        } catch (err) {
            console.error(err);
        }
    }
}

function deleteCurrentChat() {
    if (currentChatId) {
        deleteChat(currentChatId);
    }
}

let typingTimeout;
document.addEventListener('DOMContentLoaded', () => {
    const messageInput = document.getElementById('message-input');
    if (messageInput) {
        messageInput.addEventListener('input', () => {
            if (currentChatId) {
                socket.emit('typing-start', currentChatId);
                clearTimeout(typingTimeout);
                typingTimeout = setTimeout(() => {
                    socket.emit('typing-stop', currentChatId);
                }, 1000);
            }
        });
    }
});

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function formatTime(date) {
    if (!date) return '';
    const d = new Date(date);
    const now = new Date();
    if (d.toDateString() === now.toDateString()) {
        return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return d.toLocaleDateString();
}

function goBack() {
    window.location.href = '/chats';
}

document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM загружен, currentUserId:', window.currentUserId);
    initSocket();
});