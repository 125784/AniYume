document.addEventListener('DOMContentLoaded', () => {
    const confirmationOverlay = document.getElementById('confirmation');
    const confirmButton = document.getElementById('confirm-button');
    const cancelButton = document.getElementById('cancel-button');
    const waitingScreen = document.getElementById('waiting');
    const videoArea = document.getElementById('video-area');
    const endCallButton = document.getElementById('end-call-button');
    const addUserButton = document.getElementById('add-user-button');
    const blockUserButton = document.getElementById('block-user-button');
    const reportUserButton = document.getElementById('report-user-button');
    const localVideo = document.getElementById('localVideo');
    const remoteVideo = document.getElementById('remoteVideo');
    const statusText = document.getElementById('status-text');
    const sendMessageButton = document.getElementById('send-message-button');
    const messageText = document.getElementById('message-text');
    const messagesList = document.getElementById('messages');

    function addMessageToChat(message, isLocalUser = true) {
        const messageItem = document.createElement('li');
        messageItem.textContent = message;
        messageItem.classList.add(isLocalUser ? 'local-message' : 'remote-message');
        messagesList.appendChild(messageItem);
        messagesList.scrollTop = messagesList.scrollHeight; 
    }

    function startLocalVideo() {
        localVideo.textContent = "Local Video"; 
        localVideo.style.backgroundColor = '#777';
    }

    function startCall() {
        waitingScreen.classList.remove('hidden'); 
        confirmationOverlay.classList.add('hidden'); 

        setTimeout(() => { 
            waitingScreen.classList.add('hidden');
            videoArea.classList.remove('hidden');

            remoteVideo.textContent = "Remote Video"; 
            remoteVideo.style.backgroundColor = '#558B2F';

            statusText.textContent = 'Connected'; 
        }, 3000);
    }

    confirmButton.addEventListener('click', () => {
        startLocalVideo();
        startCall();
    });

    cancelButton.addEventListener('click', () => {
        alert('Call cancelled');
    });

    endCallButton.addEventListener('click', () => {
        videoArea.classList.add('hidden');
        confirmationOverlay.classList.remove('hidden');
        remoteVideo.textContent = ""; 
        localVideo.textContent = "";
        statusText.textContent = 'Online';
        remoteVideo.style.backgroundColor = '';
        localVideo.style.backgroundColor = '';
    });
    
    addUserButton.addEventListener('click', () => {
        socket.emit('requestAddRandomUser'); 
    });

    socket.on('userAddedToChat', (data) => {
        const newUserId = data.userId;
        const newUserName = data.userName;

        // Добавление нового видео-блока в UI
        const newUserVideo = document.createElement('div');
        newUserVideo.textContent = newUserName + " Video";
        newUserVideo.style.backgroundColor = '#90CAF9';
        newUserVideo.style.width = '200px';
        newUserVideo.style.height = '150px';

        videoArea.appendChild(newUserVideo);
    });

    socket.on('noAvailableUsers', () => {
      alert("Нет доступных пользователей для добавления в чат.");
    });

    blockUserButton.addEventListener('click', () => {
        alert('User blocked');
    });

    reportUserButton.addEventListener('click', () => {
        alert('User reported');
    });

    sendMessageButton.addEventListener('click', () => {
        const message = messageText.value.trim();
        if (message) {
            addMessageToChat(message);
            messageText.value = '';
        }
    });

    messageText.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') {
            sendMessageButton.click();
            event.preventDefault();
        }
    });

    confirmationOverlay.classList.remove('hidden');
});

function goBack() {
    window.location.href = '/chats';
}