document.addEventListener('DOMContentLoaded', () => {
    // Элементы интерфейса
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const statusDisplay = document.getElementById('status');
    const companionNameDisplay = document.getElementById('companionName');

    const endChatButton = document.getElementById('endChatButton');
    const nextChatButton = document.getElementById('nextChatButton');
    const confirmButton = document.getElementById('confirm-button');
    const confirmationOverlay = document.getElementById('confirmation');

    let socket;
    let companionSocketId = null;
    let isSearching = false;  // Флаг, чтобы не дублировать поиск

    if (!user || !user._id) {
        console.error("User information is missing!");
        statusDisplay.textContent = "Ошибка авторизации";
        return;
    }

    socket = io();
    socket.emit('user connected', user._id);

    function startSearching() {
        if (isSearching) return;
        isSearching = true;
        
        console.log("Запрос поиска собеседника...");
        statusDisplay.textContent = "Поиск собеседника...";
        socket.emit('requestRandomTextChat');
    }

    function stopSearching() {
        isSearching = false;
    }

    function resetChatUI() {
        companionSocketId = null;
        stopSearching();
        chatMessages.innerHTML = '';
        companionNameDisplay.textContent = "Поиск собеседника...";
        statusDisplay.textContent = "Ожидание...";
    }

    confirmButton.addEventListener('click', () => {
        confirmationOverlay.style.display = 'none';
        statusDisplay.textContent = "Подготовка...";
        setTimeout(() => {
            startSearching();
        }, 500);
    });

    socket.on('textChatMatchFound', (data) => {
        console.log("Собеседник найден:", data);
        companionSocketId = data.socketId;
        stopSearching();
        statusDisplay.textContent = "Онлайн";
        companionNameDisplay.textContent = data.companionName;
        addMessage(`Вы подключены к пользователю ${data.companionName}`, 'system');
    });

    socket.on('textChatMatchNotFound', () => {
        console.log("В очереди никого нет, повтор через 2 секунды...");
        statusDisplay.textContent = "В очереди никого нет. Ждем...";
        
        // Сбрасываем флаг и продолжаем поиск
        isSearching = false;
        
        setTimeout(() => {
            if (!companionSocketId) {
                startSearching();
            }
        }, 2000);
    });

    socket.on('companionDisconnected', () => {
        addMessage("Собеседник покинул чат.", "system");
        companionSocketId = null;
        stopSearching();
        statusDisplay.textContent = "Собеседник отключился";
        companionNameDisplay.textContent = "Поиск собеседника...";
        
        // Автоматически начинаем поиск нового собеседника
        setTimeout(() => {
            if (!companionSocketId) {
                startSearching();
            }
        }, 2000);
    });

    function addMessage(text, type) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', type);
        messageDiv.innerText = text;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    socket.on('message', (data) => {
        addMessage(data.text, 'received');
    });

    sendButton.addEventListener('click', () => {
    const text = messageInput.value.trim();
    if (text && companionSocketId) {
        console.log(`Отправка сообщения собеседнику ${companionSocketId}: ${text}`);
        addMessage(text, 'sent');
        socket.emit('message', {
            text: text,
            toSocketId: companionSocketId
        });
        messageInput.value = '';
    } else {
        console.log('Не могу отправить: нет текста или companionSocketId =', companionSocketId);
    }
});

    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendButton.click();
    });

    endChatButton.addEventListener('click', () => {
        if (confirm("Завершить этот чат?")) {
            socket.emit('leaveTextChat');
            socket.disconnect();
            window.location.href = '/chats';
        }
    });

    nextChatButton.addEventListener('click', () => {
        if (companionSocketId) {
            if (confirm("Вы точно хотите покинуть текущий чат и найти следующего собеседника?")) {
                proceedToNext();
            }
        } else {
            proceedToNext();
        }
    });

    function proceedToNext() {
        companionSocketId = null;
        socket.emit('leaveTextChat');
        resetChatUI();
        startSearching();
    }
});

function goBack() {
    window.location.href = '/chats';
}