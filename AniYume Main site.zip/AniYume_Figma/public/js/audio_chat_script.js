document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    const statusText = document.getElementById('statusText');
    const confirmationArea = document.getElementById('confirmationArea');
    const chatArea = document.getElementById('chatArea');
    const partnerName = document.getElementById('partnerName');
    const partnerStatus = document.getElementById('partnerStatus');
    const partnerAvatar = document.getElementById('partnerAvatar');
    const micToggleButton = document.getElementById('micToggleButton');

    let micEnabled = false;
    let currentCompanionSocketId = null;

    confirmationArea.style.display = 'none';

    const userId = localStorage.getItem('userId'); 
    socket.emit('user connected', userId);

    startAudioSearch();

    function startAudioSearch() {
        statusText.textContent = 'В поиске собеседника (Аудио)...';
        chatArea.style.display = 'none';
        confirmationArea.style.display = 'none';
        socket.emit('requestRandomAudioChat'); 
    }

    socket.on('audioChatMatchFound', (data) => {
        statusText.textContent = 'Собеседник найден! Подтвердите готовность.';
        confirmationArea.style.display = 'block';

        window.tempPartnerData = data; 
    });

    socket.on('audioChatMatchNotFound', () => {
        setTimeout(() => {
            socket.emit('requestRandomAudioChat');
        }, 5000);
    });

    socket.on('companionDisconnected', () => {
        alert('Собеседник покинул чат');
        currentCompanionSocketId = null;
        startAudioSearch();
    });

    window.confirmReady = () => {
        confirmationArea.style.display = 'none';
        statusText.textContent = 'Вы в аудио-чате!';
        chatArea.style.display = 'block';

        const data = window.tempPartnerData;
        if (data) {
            currentCompanionSocketId = data.socketId;
            partnerName.textContent = data.companionName;
            partnerStatus.textContent = 'В сети';
            console.log("Соединение установлено с:", currentCompanionSocketId);
        }
    };

    window.findNext = () => {
        if (confirm("Перейти к следующему собеседнику?")) {
            socket.emit('leaveAudioChat');
            startAudioSearch();
        }
    };

    window.toggleMic = () => {
        micEnabled = !micEnabled;
        updateMicButton();
    };

    function updateMicButton() {
        if (micEnabled) {
            micToggleButton.innerHTML = '<i class="fas fa-microphone"></i> Выключить Микрофон';
            micToggleButton.classList.add('active');
        } else {
            micToggleButton.innerHTML = '<i class="fas fa-microphone-slash"></i> Включить Микрофон';
            micToggleButton.classList.remove('active');
        }
    }

    window.endChat = () => {
        socket.emit('leaveAudioChat');
        goBack();
    };

    window.cancelSearch = () => {
        socket.emit('leaveAudioChat');
        goBack();
    };

    window.reportUser = () => {
        let reason = prompt("Укажите причину жалобы:");
        if (reason && currentCompanionSocketId) {
            socket.emit('report_user', { targetId: currentCompanionSocketId, reason });
            alert('Жалоба отправлена.');
            window.findNext();
        }
    };
});

function goBack() {
    window.location.href = '/chats';
}