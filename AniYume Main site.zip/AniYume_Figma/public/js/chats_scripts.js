function startTextChat() {
    window.location.href = '/text_random_chat'; 
}

function startAudioChat() {
    window.location.href = '/audio_random_chat'; 
}

function startVideoChat() {
    window.location.href = '/video_random_chat'; 
}

function searchUser() {
     window.location.href = '/nikname_chat';
}

const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.chat-card').forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = 'all 0.6s ease';
    observer.observe(card);
});